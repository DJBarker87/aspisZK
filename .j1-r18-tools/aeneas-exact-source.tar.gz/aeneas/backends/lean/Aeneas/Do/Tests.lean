import Aeneas.Do.Elab
import Aeneas.Do.Delab
import Aeneas.Std

namespace Do
namespace Tests

open Aeneas Std Result ControlFlow Error

def test1 : Result Nat := do
  ok 42
/--
info: def Do.Tests.test1 : Result ℕ :=
ok 42
-/
#guard_msgs in
#print test1

def test2 : Result Nat := do
  let x ← ok 1
  ok x
/--
info: def Do.Tests.test2 : Result ℕ :=
do
  let x ← ok 1
  ok x
-/
#guard_msgs in
#print test2

def test3 : Result Nat := do
  let x ← ok 1
  let y ← ok 2
  ok (x + y)
/--
info: def Do.Tests.test3 : Result ℕ :=
do
  let x ← ok 1
  let y ← ok 2
  ok (x + y)
-/
#guard_msgs in
#print test3

def test4 : Result Nat := do
  let x : Nat ← ok 1
  ok (x + 1)
/--
info: def Do.Tests.test4 : Result ℕ :=
do
  let x ← ok 1
  ok (x + 1)
-/
#guard_msgs in
#print test4

def test5 : Result Nat := do
  let x := 1
  ok (x + 2)
/--
info: def Do.Tests.test5 : Result ℕ :=
have x := 1;
ok (x + 2)
-/
#guard_msgs in
#print test5

def test6 : Result Nat := do
  let x : Nat := 1
  let y ← ok 2
  ok (x + y)
/--
info: def Do.Tests.test6 : Result ℕ :=
have x := 1;
do
let y ← ok 2
ok (x + y)
-/
#guard_msgs in
#print test6

def test7 : Result Nat := do
  let x ← ok 1
  if x > 0 then ok x else ok 0
/--
info: def Do.Tests.test7 : Result ℕ :=
do
  let x ← ok 1
  if x > 0 then ok x else ok 0
-/
#guard_msgs in
#print test7

def test8 : Result Nat := do
  let x ← ok 1
  if x > 0 then ok 10 else ok 20
/--
info: def Do.Tests.test8 : Result ℕ :=
do
  let x ← ok 1
  if x > 0 then ok 10 else ok 20
-/
#guard_msgs in
#print test8

def test9 : Result Nat := do
  let x ← ok 2
  let y ← do
    if x > 1 then ok 1 else ok 0
  ok y
/--
info: def Do.Tests.test9 : Result ℕ :=
do
  let x ← ok 2
  let y ← if x > 1 then ok 1 else ok 0
  ok y
-/
#guard_msgs in
#print test9

def test10 : Result Nat := do
  let x ← ok 2
  let y ← if x > 1 then ok 1 else ok 0
  ok y
/--
info: def Do.Tests.test10 : Result ℕ :=
do
  let x ← ok 2
  let y ← if x > 1 then ok 1 else ok 0
  ok y
-/
#guard_msgs in
#print test10

def test11_body (max i : Nat) : Result (ControlFlow Nat Nat) :=
  if i < max then ok (ControlFlow.cont (i + 1))
  else ok (ControlFlow.done i)

def test11 : Result Nat := do
  let max ← ok 10
  loop (test11_body max) 0
/--
info: def Do.Tests.test11 : Result ℕ :=
do
  let max ← ok 10
  loop (test11_body max) 0
-/
#guard_msgs in
#print test11

def test12 : Result Nat := do
  let (a, b) ← ok (1, 2)
  ok (a + b)
/--
info: def Do.Tests.test12 : Result ℕ :=
do
  let (a, b) ← ok (1, 2)
  ok (a + b)
-/
#guard_msgs in
#print test12

def test13 : Result Nat := do
  let (_, b) ← ok (1, 2)
  ok b
/--
info: def Do.Tests.test13 : Result ℕ :=
do
  let (_, b) ← ok (1, 2)
  ok b
-/
#guard_msgs in
#print test13

def test14 : Result Nat := do
  let (a, b) := (1, 2)
  ok (a + b)
/--
info: def Do.Tests.test14 : Result ℕ :=
let (a, b) := (1, 2)
ok (a + b)
-/
#guard_msgs in
#print test14

def test15 : Result Nat := do
  let x ← ok 1
  match x with
  | 0 => ok 10
  | _ => ok 20
/--
info: def Do.Tests.test15 : Result ℕ :=
do
  let x ← ok 1
  match x with
    | 0 => ok 10
    | x => ok 20
-/
#guard_msgs in
#print test15

def test16 : Result Nat := do
  let x ← ok 1
  let y ← match x with
    | 0 => ok 10
    | _ => ok 20
  ok (y + 1)
/--
info: def Do.Tests.test16 : Result ℕ :=
do
  let x ← ok 1
  let y ←
    match x with
      | 0 => ok 10
      | x => ok 20
  ok (y + 1)
-/
#guard_msgs in
#print test16

def massert_test : Result Unit := do
  let s ←
    lift (Array.to_slice
      (Array.make 5#usize [ 0#u32, 1#u32, 2#u32, 3#u32, 4#u32 ]))
  let i ← core.slice.Slice.iter s
  let it ← core.iter.traits.iterator.Iterator.step_by.default i 1#usize
  let (o, it1) ←
    core.iter.adapters.step_by.IteratorStepBy.next
      (core.iter.traits.iterator.IteratorSliceIter Std.U32) it
  let i1 ← core.option.Option.unwrap o
  massert (i1 = 0#u32)
  let (o1, it2) ←
    core.iter.adapters.step_by.IteratorStepBy.next
      (core.iter.traits.iterator.IteratorSliceIter Std.U32) it1
  let i2 ← core.option.Option.unwrap o1
  massert (i2 = 1#u32)
/--
info: def Do.Tests.massert_test : Result Unit :=
do
  let s ← lift (Array.make 5#usize [0#u32, 1#u32, 2#u32, 3#u32, 4#u32] massert_test._proof_7).to_slice
  let i ← core.slice.Slice.iter s
  let it ← core.iter.traits.iterator.Iterator.step_by.default i 1#usize
  let (o, it1) ← core.iter.adapters.step_by.IteratorStepBy.next (core.iter.traits.iterator.IteratorSliceIter U32) it
  let i1 ← core.option.Option.unwrap o
  massert (i1 = 0#u32)
  let (o1, it2) ← core.iter.adapters.step_by.IteratorStepBy.next (core.iter.traits.iterator.IteratorSliceIter U32) it1
  let i2 ← core.option.Option.unwrap o1
  massert (i2 = 1#u32)
-/
#guard_msgs in
#print massert_test

def bool_test (x : Bool) : Result Bool := do
  let b ← ok x
  if b
  then ok true
  else ok false
/--
info: def Do.Tests.bool_test : Bool → Result Bool :=
fun x => do
  let b ← ok x
  if b = true then ok true else ok false
-/
#guard_msgs in
#print bool_test

opaque core.mem.drop {T : Type} : T → Result Unit

def do_nested_test (b1 : Bool) : Result Unit := do
  let _ ←
    if b1
    then ok (true, 2#u32)
    else ok (false, 0#u32)
  ok ()
/--
info: def Do.Tests.do_nested_test : Bool → Result Unit :=
fun b1 => do
  let _ ← if b1 = true then ok (true, 2#u32) else ok (false, 0#u32)
  ok ()
-/
#guard_msgs in
#print do_nested_test

def if_then_add_test (b : Bool) (x : Std.U32) : Result Std.U32 := do
  let y ← if b then ok 1#u32 else ok 0#u32
  x + y
/--
info: def Do.Tests.if_then_add_test : Bool → U32 → Result U32 :=
fun b x => do
  let y ← if b = true then ok 1#u32 else ok 0#u32
  x + y
-/
#guard_msgs in
#print if_then_add_test

def match_add_test (a : Std.U32) (x : Std.U32) : Result Std.U32 := do
  let y ←
    match a with
    | 0#uscalar => ok 0#u32
    | 1#uscalar => ok 1#u32
    | _ => ok 2#u32
  x + y
/--
info: def Do.Tests.match_add_test : U32 → U32 → Result U32 :=
fun a x => do
  let y ←
    match a with
      | 0#32#uscalar => ok 0#u32
      | 1#32#uscalar => ok 1#u32
      | x => ok 2#u32
  x + y
-/
#guard_msgs in
#print match_add_test

def make2nats (x y : Nat) : Result (Nat × Nat) := do
  ok (x, y)

def make3nats (x y z : Nat) : Result ((Nat × Nat) × Nat) := do
  ok ((x, y), z)

def make4nats (x y z w : Nat) : Result ((Nat × Nat) × (Nat × Nat)) := do
  ok ((x, y), z, w)

def nested_pat_test : Result Nat := do
  let (a, b) ← make2nats 1 2
  let ((c, d), e) ← make3nats 3 4 5
  let ((f, g), (h, i)) ← make4nats 6 7 8 9
  ok (a + b + c + d + e + f + g + h + i)
/--
info: def Do.Tests.nested_pat_test : Result ℕ :=
do
  let (a, b) ← make2nats 1 2
  let ((c, d), e) ← make3nats 3 4 5
  let ((f, g), (h, i)) ← make4nats 6 7 8 9
  ok (a + b + c + d + e + f + g + h + i)
-/
#guard_msgs in
#print nested_pat_test

structure TwoNatsWrapped where
  x : Nat
  y : Nat

structure FourNatsWrapped where
  z : TwoNatsWrapped
  w : TwoNatsWrapped

def make2natswrapped (x y : Nat) : Result TwoNatsWrapped := do
  ok { x, y }

def make4natswrapped (w₁ w₂ : TwoNatsWrapped) : Result FourNatsWrapped := do
  ok ⟨w₁, w₂⟩

def nested_wrapped_pat_test : Result Nat := do
  let w₁ ← make2natswrapped 1 2
  let w₂ ← make2natswrapped 3 4
  let ⟨⟨x, y⟩, ⟨z, w⟩⟩ ← make4natswrapped w₁ w₂
  ok (x + y + z + w)
/--
info: def Do.Tests.nested_wrapped_pat_test : Result ℕ :=
do
  let w₁ ← make2natswrapped 1 2
  let w₂ ← make2natswrapped 3 4
  let ⟨⟨x, y⟩, ⟨z, w⟩⟩ ← make4natswrapped w₁ w₂
  ok (x + y + z + w)
-/
#guard_msgs in
#print nested_wrapped_pat_test

def big_pat_test : Result Nat := do
  let (x, y, z, w) := (1,2,3,4)
  let (a, b, c, d) ← ok (5, 6, 7, 8)
  ok (x + y + z + w + a + b + c + d)
/--
info: def Do.Tests.big_pat_test : Result ℕ :=
let (x, y, z, w) := (1, 2, 3, 4)
do
let (a, b, c, d) ← ok (5, 6, 7, 8)
ok (x + y + z + w + a + b + c + d)
-/
#guard_msgs in
#print big_pat_test

structure Wrapper (T : Type) where
  x : T

def make_wrapper {T : Type} (x : T) :
  Result ((Wrapper T) × (Wrapper T → Wrapper T)) := do
  ok ({ x }, fun w => w)

def universe_test {T : Type} (w : Wrapper T) :
  Result ((Wrapper T) × (Wrapper T → Wrapper T)) := do
  let (inner, back) ← make_wrapper w.x
  let back2 := fun w1 => back { w with x := w1.x }
  ok (inner, back2)
/--
info: def Do.Tests.universe_test : {T : Type} → Wrapper T → Result (Wrapper T × (Wrapper T → Wrapper T)) :=
fun {T} w => do
  let (inner, back) ← make_wrapper w.x
  have back2 : Wrapper T → Wrapper T := fun w1 => back { x := w1.x }
  ok (inner, back2)
-/
#guard_msgs in
#print universe_test

def make_pair {T : Type} (x y : T) :
  Result (T × T × (T → List T) × (T → List T)) := do
  ok (x, y, fun t => [t], fun t => [t])

def universe_tuple_test {T : Type} (x y : T) :
  Result ((T × T) × ((T × T) → (List T × List T))) := do
  let (a, b, back, back1) ← make_pair x y
  let back2 :=
    fun p =>
      let (t1, t2) := p
      (back t1, back1 t2)
  ok ((a, b), back2)
/--
info: def Do.Tests.universe_tuple_test : {T : Type} → T → T → Result ((T × T) × (T × T → List T × List T)) :=
fun {T} x y => do
  let (a, b, back, back1) ← make_pair x y
  have back2 : T × T → List T × List T := fun p =>
    match p with
    | (t1, t2) => (back t1, back1 t2)
  ok ((a, b), back2)
-/
#guard_msgs in
#print universe_tuple_test

def get_and_update (xs : alloc.vec.Vec U32) (i : Usize) :
  Result (U32 × (U32 → alloc.vec.Vec U32)) := do
  let x ← alloc.vec.Vec.index (core.slice.index.SliceIndexUsizeSlice U32) xs i
  ok (x, fun _v => xs)

def mono_loop_test (xs : alloc.vec.Vec U32) (i : Usize) :
  Result (alloc.vec.Vec U32) := do
  let i1 := alloc.vec.Vec.len xs
  if i < i1
  then
    let (_, update_back) ← get_and_update xs i
    let i2 ← i + 1#usize
    let xs1 := update_back 0#u32
    mono_loop_test xs1 i2
  else ok xs
partial_fixpoint
/--
info: @[irreducible] def Do.Tests.mono_loop_test : alloc.vec.Vec U32 → Usize → Result (alloc.vec.Vec U32) :=
Lean.Order.fix
  (fun f xs i =>
    let i1 := xs.len;
    if i < i1 then do
      let (_, update_back) ← get_and_update xs i
      let i2 ← i + 1#usize
      let xs1 : alloc.vec.Vec U32 := update_back 0#u32
      f xs1 i2
    else ok xs)
  mono_loop_test._proof_1
-/
#guard_msgs in
#print mono_loop_test

def doIf_pat_test (b : Bool) : Result (Nat × Nat) := do
  let (x, y) ←
    if b then ok (1, 2) else ok (3, 4)
  ok (x, y)
/--
info: def Do.Tests.doIf_pat_test : Bool → Result (ℕ × ℕ) :=
fun b => do
  let (x, y) ← if b = true then ok (1, 2) else ok (3, 4)
  ok (x, y)
-/
#guard_msgs in
#print doIf_pat_test

def match_pat_test (n : Nat) : Result (Nat × Nat) := do
  let (x, y) ←
    match n with
    | 0 => ok (1, 2)
    | _ => ok (3, 4)
  ok (x, y)
/--
info: def Do.Tests.match_pat_test : ℕ → Result (ℕ × ℕ) :=
fun n => do
  let (x, y) ←
    match n with
      | 0 => ok (1, 2)
      | x => ok (3, 4)
  ok (x, y)
-/
#guard_msgs in
#print match_pat_test

def else_if_test (x y : Nat) : Result Ordering := do
  if x < y
  then ok Ordering.lt
  else if x = y
  then ok Ordering.eq
  else ok Ordering.gt
/--
info: def Do.Tests.else_if_test : ℕ → ℕ → Result Ordering :=
fun x y => if x < y then ok Ordering.lt else if x = y then ok Ordering.eq else ok Ordering.gt
-/
#guard_msgs in
#print else_if_test

inductive Wrap where
  | mk : Nat → Wrap

def anon_ctor_test (w : Wrap) : Result Nat := do
  let ⟨ n ⟩ := w
  ok (n + 1)
/--
info: def Do.Tests.anon_ctor_test : Wrap → Result ℕ :=
fun w =>
  let ⟨n⟩ := w
  ok (n + 1)
-/
#guard_msgs in
#print anon_ctor_test

def anon_ctor_monadic_test (w : Wrap) : Result Nat := do
  let ⟨ n ⟩ ← ok w
  ok (n + 1)
/--
info: def Do.Tests.anon_ctor_monadic_test : Wrap → Result ℕ :=
fun w => do
  let ⟨n⟩ ← ok w
  ok (n + 1)
-/
#guard_msgs in
#print anon_ctor_monadic_test

structure ExBox (Inst : Type → Type) where
  ty : Type
  inst : Inst ty
  val : ty

structure Into2 (Self : Type) (T : Type) where
  into : Self → Result T

def exbox_lambda_test {V T W : Type}
    (inst1 : Into2 T V) (inst2 : Into2 W V)
    (b : Bool) (x : T) (y : W) :
    Result (ExBox (fun _dyn => Into2 _dyn V)) := do
  if b
  then ok (ExBox.mk _ inst1 x)
  else ok (ExBox.mk _ inst2 y)
/--
info: def Do.Tests.exbox_lambda_test : {V T W : Type} →
  Into2 T V → Into2 W V → Bool → T → W → Result (ExBox fun _dyn => Into2 _dyn V) :=
fun {V T W} inst1 inst2 b x y =>
  if b = true then ok { ty := T, inst := inst1, val := x } else ok { ty := W, inst := inst2, val := y }
-/
#guard_msgs in
#print exbox_lambda_test

def do_if_rest_test : Result Nat := do
  let b ← ok true
  if b then ok () else ok ()
  if b then ok () else ok ()
  if b then ok () else ok ()
  ok 1
/--
info: def Do.Tests.do_if_rest_test : Result ℕ :=
do
  let b ← ok true
  if b = true then ok () else ok ()
  if b = true then ok () else ok ()
  if b = true then ok () else ok ()
  ok 1
-/
#guard_msgs in
#print do_if_rest_test

inductive MatchTest | A | B | C

def do_match_rest_test (m : MatchTest) : Result Nat := do
  let n ← ok 3
  match m with
  | .A => ok ()
  | .B => ok ()
  | .C => ok ()
  match m with
  | .A => ok ()
  | .B => ok ()
  | .C => ok ()
  pure n
/--
info: def Do.Tests.do_match_rest_test : MatchTest → Result ℕ :=
fun m => do
  let n ← ok 3
  match m with
    | MatchTest.A => ok ()
    | MatchTest.B => ok ()
    | MatchTest.C => ok ()
  match m with
    | MatchTest.A => ok ()
    | MatchTest.B => ok ()
    | MatchTest.C => ok ()
  pure n
-/
#guard_msgs in
#print do_match_rest_test

/-! Unused var linter tests -/

#guard_msgs in
def do_match_pat_var_used (n : Nat) : Result Nat := do
  match n with
  | 0 => ok 42
  | k + 1 =>
    let a ← ok (k + 10)
    ok (a + 1)

/- Cross-arm name reuse: both arms bind `n`. The InfoTree binder map must be
   scoped per-arm — otherwise the two `n`s collide on `userName`. -/
inductive Two | A (n : Nat) | B (n : Nat)

#guard_msgs in
def do_match_cross_arm_used (t : Two) : Result Nat := do
  match t with
  | .A n => ok n
  | .B n => ok n

/-- warning: Variable name `n` is not explicitly referenced.

The binding can be removed (if unused) or named `_` (if used implicitly).

Note: This linter can be disabled with `set_option linter.unusedVariables false`
---
warning: Variable name `n` is not explicitly referenced.

The binding can be removed (if unused) or named `_` (if used implicitly).

Note: This linter can be disabled with `set_option linter.unusedVariables false` -/
#guard_msgs in
def do_match_cross_arm_unused (t : Two) : Result Nat := do
  match t with
  | .A n => ok 0
  | .B n => ok 0

#guard_msgs in
def do_let_arrow_id_used : Result Nat := do
  let x ← ok 1
  ok (x + 1)

/-- warning: Variable name `x` is not explicitly referenced.

The binding can be removed (if unused) or named `_` (if used implicitly).

Note: This linter can be disabled with `set_option linter.unusedVariables false` -/
#guard_msgs in
def do_let_arrow_id_unused : Result Nat := do
  let x ← ok 1
  ok 42

#guard_msgs in
def do_let_id_used : Result Nat := do
  let x := 1
  ok (x + 1)

#guard_msgs in
def do_let_arrow_pat_used : Result Nat := do
  let (a, b) ← ok (1, 2)
  ok (a + b)

/--
warning: Variable name `a` is not explicitly referenced.

The binding can be removed (if unused) or named `_` (if used implicitly).

Note: This linter can be disabled with `set_option linter.unusedVariables false`
---
warning: Variable name `b` is not explicitly referenced.

The binding can be removed (if unused) or named `_` (if used implicitly).

Note: This linter can be disabled with `set_option linter.unusedVariables false`
---
warning: Variable name `c` is not explicitly referenced.

The binding can be removed (if unused) or named `_` (if used implicitly).

Note: This linter can be disabled with `set_option linter.unusedVariables false`
---
warning: Variable name `d` is not explicitly referenced.

The binding can be removed (if unused) or named `_` (if used implicitly).

Note: This linter can be disabled with `set_option linter.unusedVariables false`
-/
#guard_msgs in
def do_let_arrow_pat_unused : Result Nat := do
  let ((a, b, c), d) ← ok ((1, 2, 3), 4)
  ok 42


/--
warning: Variable name `a` is not explicitly referenced.

The binding can be removed (if unused) or named `_` (if used implicitly).

Note: This linter can be disabled with `set_option linter.unusedVariables false`
---
warning: Variable name `b` is not explicitly referenced.

The binding can be removed (if unused) or named `_` (if used implicitly).

Note: This linter can be disabled with `set_option linter.unusedVariables false`
---
warning: Variable name `c` is not explicitly referenced.

The binding can be removed (if unused) or named `_` (if used implicitly).

Note: This linter can be disabled with `set_option linter.unusedVariables false`
---
warning: Variable name `d` is not explicitly referenced.

The binding can be removed (if unused) or named `_` (if used implicitly).

Note: This linter can be disabled with `set_option linter.unusedVariables false`
-/
#guard_msgs in
def do_let_pat_unused : Result Nat := do
  let ((a, b, c), d) := ((1, 2, 3), 4)
  ok 42

def unit_bind : Result Nat := do
  let () ← ok ()
  ok 1

end Tests

/- ## Regression tests for `elabDoMatch` with unresolved discriminant type metavars.

When a polymorphic function has implicit type parameters resolved through an explicit
structure argument (e.g., `{Item : Type} (inst : Iter I Item)`), the discriminant of a
subsequent `match` on `Option` may carry unresolved metavars.  The holed match
`match o with | none => _ | some p => _` needs those metavars resolved so that the
pattern `none` can be elaborated. -/
namespace MetavarTests

open Aeneas Std Result ControlFlow Error

structure TestIter (I : Type) (Item : Type) where
  next : I → Result (Option Item × I)
  extra : I → Nat
  deriving Nonempty

noncomputable opaque testEnumNext
  {I : Type} {Item : Type} (inst : TestIter I Item) (e : Nat) :
  Result (Option (Nat × Item) × Nat)

noncomputable opaque testIterInst : TestIter (List Nat) Nat

#guard_msgs in
noncomputable def option_match_metavar_test
  (e : Nat) (acc : Nat) : Result Nat := do
  let (o, _e1) ← testEnumNext testIterInst e
  match o with
  | none => ok acc
  | some p =>
    let (_i, x) := p
    ok (acc + x)
/--
info: def Do.MetavarTests.option_match_metavar_test : ℕ → ℕ → Result ℕ :=
fun e acc => do
  let (o, _e1) ← testEnumNext testIterInst e
  match o with
    | none => ok acc
    | some p =>
      let (_i, x) := p
      ok (acc + x)
-/
#guard_msgs in
#print option_match_metavar_test

#guard_msgs in
noncomputable def option_match_metavar_loop_test
  (e : Nat) (acc : Nat) : Result Nat := do
  let (o, e1) ← testEnumNext testIterInst e
  match o with
  | none => ok acc
  | some p =>
    let (_i, x) := p
    option_match_metavar_loop_test e1 (acc + x)
partial_fixpoint
/--
info: @[irreducible] def Do.MetavarTests.option_match_metavar_loop_test : ℕ → ℕ → Result ℕ :=
Lean.Order.fix
  (fun f e acc => do
    let (o, e1) ← testEnumNext testIterInst e
    match o with
      | none => ok acc
      | some p =>
        let (_i, x) := p
        f e1 (acc + x))
  option_match_metavar_loop_test._proof_1
-/
#guard_msgs in
#print option_match_metavar_loop_test

end MetavarTests

namespace CapturedSynthMVarTests

open Aeneas Std Result ControlFlow Error

/-! Regression tests for synthetic mvars captured across `do` binders.

The `25#usize` literal expands to `Usize.ofNat 25 ?proof`, where `?proof` is a
synthetic mvar discharged by tactics. If the literal is elaborated under a
`withLocalDeclD c …` and we abstract over `c` *before* synthesizing, `?proof`
gets captured as `?proof c`, making the bind continuation's body type
syntactically depend on `c` and breaking `Bind.bind` unification. -/

opaque f_dep (N : Usize) : Result (Std.Array U64 N)

/-- `let _ : Type ← _`: the originally reported regression. -/
def dep_return_let_arrow_id : Result (Std.Array U64 25#usize) := do
  let _c : Usize ← pure 0#usize
  f_dep 25#usize

/-- `let _ : _ := _`. -/
def dep_return_let_id : Result (Std.Array U64 25#usize) := do
  let _c : Usize := 0#usize
  f_dep 25#usize

/-- `let pat ← _` (pattern, monadic). -/
def dep_return_let_arrow_pat : Result (Std.Array U64 25#usize) := do
  let (_a, _b) ← (pure (0, 0) : Result (Nat × Nat))
  f_dep 25#usize

/-- `let pat := _` (pattern, pure). -/
def dep_return_let_pat : Result (Std.Array U64 25#usize) := do
  let (_a, _b) := ((0, 0) : Nat × Nat)
  f_dep 25#usize

/-- Stacked bindings exercising every let form. -/
def dep_return_stacked : Result (Std.Array U64 25#usize) := do
  let _x : Usize ← pure 0#usize
  let _y : Nat := 0
  let (_a, _b) ← (pure (1, 2) : Result (Nat × Nat))
  f_dep 25#usize

/-- Match arm body returning a dependent type (`assignArmMVar` path). -/
def dep_return_match (b : Bool) : Result (Std.Array U64 25#usize) := do
  match b with
  | true => f_dep 25#usize
  | false => f_dep 25#usize

/-- Match with pattern-bound fvars in the arm context (non-trivial
    `assignArmMVar` path). -/
def dep_return_match_pat (o : Option Nat) : Result (Std.Array U64 25#usize) := do
  match o with
  | some _x => f_dep 25#usize
  | none => f_dep 25#usize

/-- If branches with rest = [] (`elabMonadicAsDoElem` leaf path). -/
def dep_return_if (b : Bool) : Result (Std.Array U64 25#usize) := do
  if b then
    f_dep 25#usize
  else
    f_dep 25#usize

/-- Non-bound monadic statement before a dependent return
    (`elabMonadicAsDoElem` rest ≠ [] path). -/
def dep_return_seq : Result (Std.Array U64 25#usize) := do
  let _x : Usize ← pure 0#usize
  pure ()
  f_dep 25#usize

end CapturedSynthMVarTests

end Do
