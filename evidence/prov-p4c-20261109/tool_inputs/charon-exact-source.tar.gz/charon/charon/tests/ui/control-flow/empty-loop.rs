fn main() {
    loop {}
}
