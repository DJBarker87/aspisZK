//! UNPROVED COST PROBE. Seven coefficient functionals and their dual folds.
use alloc::{boxed::Box,vec::Vec};
use aspis_core::{field::{QM31 as K,WideExact as E,M31},circle::SecureCirclePoint};
use crate::{transport::{Variant,TAU},verifier::Error};
pub const QUARTER:M31=M31(536870912);
pub const PERM:[usize;4]=[0,3,2,1];
pub fn powers<const N:usize>(x:E)->[E;N]{
 let mut out=[E::ZERO;N];
 let mut p=E::ONE;
 let mut i=0usize;
 while i<N {
  out[i]=p;
  i+=1;
  if i==N { return out; }
  p=p.mul(x);
 }
 out
}
pub fn kpowers<const N:usize>(x:K)->[K;N]{
 let mut out=[K::ZERO;N]; let mut p=K::ONE;
 for i in 0..N { out[i]=p; p=p.mul(x); }
 out
}
pub fn double(x:K)->K { x.mul(x).add(x.mul(x)).sub(K::ONE) }
pub fn field(bytes:&[u8],i:usize)->E { E::from_le_bytes(&bytes[i*32..(i+1)*32]).unwrap() }

// Exact S2 coefficient-to-row inactive classification, in first-occurrence order.
// Exhaustive table correspondence is checked against Variant::row and raw(0, _).
const S2_INACTIVE_GROUPS:[u8;64]=[0,1,2,3,4,5,5,6,4,5,5,5,7,7,7,7,7,7,7,4,4,5,5,6,4,5,5,5,7,7,7,4,7,7,7,7,4,5,5,5,4,5,5,5,8,9,10,8,11,2,2,10,4,5,5,6,4,5,5,6,7,7,7,7];
const S2_INACTIVE_MASKS:[u16;12]=[32769,49217,49280,16448,32767,16383,49151,65535,49152,57344,49216,33024];

#[inline(never)]
fn s2_grouped_inactive_pair(f:&[u8],low:&[E;16])->E {
    let mut coefficients=[E::ZERO;12];
    for j in 0..64 {
        let group=S2_INACTIVE_GROUPS[j] as usize;
        coefficients[group]=coefficients[group].add(field(f,j));
    }
    let mut pair=E::ZERO;
    for group in 0..12 {
        let mut weight=E::ZERO;
        for bit in 0..16 {
            let challenge=low[bit];
            if S2_INACTIVE_MASKS[group]&(1<<bit)!=0 {weight=weight.add(challenge);}
        }
        pair=pair.add(coefficients[group].mul(weight));
    }
    pair
}

/// Contract the inactive row after combining coefficients with the same
/// sixteen-entry inactive mask. The zero mask is retained as a group; its
/// subset weight is zero, matching the ungrouped sum.
#[inline(never)]
fn grouped_inactive_pair(weights:&Weights,f:&[u8],low:&[E;16])->E {
    if weights.variant==Variant::S2 && f.len()==64*32 {return s2_grouped_inactive_pair(f,low);}
    let mut group_masks=[0u16;64];
    let mut group_coefficients=[E::ZERO;64];
    let mut groups=0;
    for j in 0..f.len()/32 {
        let mut mask=0u16;
        for s in 0..16 {if weights.raw(0,16*j+s)==K::ONE {mask|=1<<s;}}
        let coefficient=field(f,j);
        let mut group=0;
        while group<groups && group_masks[group]!=mask {group+=1;}
        if group==groups {group_masks[group]=mask;groups+=1;}
        group_coefficients[group]=group_coefficients[group].add(coefficient);
    }
    let mut pair=E::ZERO;
    for group in 0..groups {
        let mask=group_masks[group];
        let mut weight=E::ZERO;
        for s in 0..16 {
            let challenge=low[s];
            if mask&(1<<s)!=0 {weight=weight.add(challenge);}
        }
        pair=pair.add(group_coefficients[group].mul(weight));
    }
    pair
}

/// Build the four two-fold Libra dual weights without per-cell exponentiation.
#[inline(never)]
fn twofold_libra_weights(low:&[E;16],extra:[K;2])->[E;4] {
    let mut powers=[[K::ZERO;28];2];
    for side in 0..2 {
        let mut power=K::ONE;
        for index in 0..28 { powers[side][index]=power; power=power.mul(extra[side]); }
    }
    let mut out=[E::ZERO;4];
    for j in 0..4 {
        let mut weight=E::ZERO;
        for s in 0..16 {
            let index=16*j+s;
            if index<56 { weight=weight.add(low[s].mul_qm31(powers[index/28][index%28])); }
        }
        out[j]=weight;
    }
    out
}

/// Exact factorization of the existing 56-entry Libra row into two 28-entry
/// geometric runs. The 16-entry low tensor is a product of two four-entry
/// tensors; the only cut blocks have lengths 12 and 4 (28 = 16 + 12).
#[inline(never)]
fn factored_s2_libra_weights(ap0:&[E;4],ap1:&[E;4],extra:[K;2])->[E;4] {
    let mut weights=[E::ZERO;4];
    for side in 0..2 {
        let q0=K::ONE;
        let q1=q0.mul(extra[side]);
        let q2=q1.mul(extra[side]);
        let q3=q2.mul(extra[side]);
        let _q4=q3.mul(extra[side]);
        let q=[q0,q1,q2,q3];
        let q4=q[2].square();let q8=q4.square();let q12=q8.mul(q4);let q16=q8.square();
        let low=Weights::scalar_factor(&q,ap0);
        let high_powers=[K::ONE,q4,q8,q12];
        let term0=ap1[PERM[0]].mul_qm31(high_powers[0]).mul_m31(QUARTER);
        let term1=ap1[PERM[1]].mul_qm31(high_powers[1]).mul_m31(QUARTER);
        let term2=ap1[PERM[2]].mul_qm31(high_powers[2]).mul_m31(QUARTER);
        let term3=ap1[PERM[3]].mul_qm31(high_powers[3]).mul_m31(QUARTER);
        let terms=[term0,term1,term2,term3];
        let first2=terms[0].add(terms[1]);let first3=first2.add(terms[2]);let all=first3.add(terms[3]);
        if side==0 {
            weights[0]=low.mul(all);
            weights[1]=low.mul(first3).mul_qm31(q16);
        } else {
            weights[1]=weights[1].add(low.mul(ap1[PERM[3]].mul_m31(QUARTER)));
            weights[2]=low.mul(all).mul_qm31(q4);
            weights[3]=low.mul(first2).mul_qm31(q16.mul(q4));
        }
    }
    weights
}

fn shared_two_point_guard(w:&Weights,folds:usize)->bool {
    w.variant==Variant::S2 && folds==2 && w.factors[0][2]==w.factors[2][2] && w.factors[0][3]==w.factors[2][3]
 }
fn push_byte_products(pair:&mut crate::fast_pairing::EbyKDot,f:&[u8],scratch:&[K],n:usize)->Result<(),Error>{
  for j in 0..n { match pair.push(field(f,j),scratch[j]) { Ok(()) => {}, Err(_) => return Err(Error::Parse) } }
  Ok(())
 }
fn partial_dot(f:&[u8],common:&[K;16],s:usize)->Result<E,Error>{
  let mut dot=crate::fast_pairing::EbyKDot::new();
  for j in 0..16 { match dot.push(field(f,16*s+j),common[j]) { Ok(()) => {}, Err(_) => return Err(Error::Parse) } }
  Ok(dot.finish())
 }
fn high_dot(partials:&[E;4],coeffs:&[K;4])->Result<E,Error>{
  let mut high=crate::fast_pairing::EbyKDot::new();
  for s in 0..4 { match high.push(partials[s],coeffs[s]) { Ok(()) => {}, Err(_) => return Err(Error::Parse) } }
  Ok(high.finish())
 }
fn process_regular_kinds(w:&Weights,shared_two_point:bool,alpha:&[E],f:&[u8],folds:usize,n:usize,
     ap0:&[E;4],ap1:&[E;4],scratch:&mut Vec<K>,parts:&mut [E;7])->Result<(),Error>{
  if !shared_two_point { process_kind(w,1,alpha,f,folds,n,ap0,ap1,scratch,parts)?; }
  process_kind(w,2,alpha,f,folds,n,ap0,ap1,scratch,parts)?;
  if !shared_two_point { process_kind(w,3,alpha,f,folds,n,ap0,ap1,scratch,parts)?; }
  process_kind(w,5,alpha,f,folds,n,ap0,ap1,scratch,parts)?;
  process_kind(w,6,alpha,f,folds,n,ap0,ap1,scratch,parts)?;
  Ok(())
 }
fn shared_partials(f:&[u8],common:&[K;16])->Result<[E;4],Error>{
  let mut partials=[E::ZERO;4];
  for s in 0..4 { partials[s]=partial_dot(f,common,s)?; }
  Ok(partials)
 }
fn shared_high(partials:&[E;4],w:&Weights,ap0:&[E;4],ap1:&[E;4],parts:&mut [E;7])->Result<(),Error>{
  let high0=high_dot(partials,&w.factors[0][4])?;
  let scale0=Weights::scalar_factor(&w.factors[0][0],ap0)
    .mul(Weights::scalar_factor(&w.factors[0][1],ap1));
  parts[1]=scale0.mul(high0);
  let high2=high_dot(partials,&w.factors[2][4])?;
  let scale2=Weights::scalar_factor(&w.factors[2][0],ap0)
    .mul(Weights::scalar_factor(&w.factors[2][1],ap1));
  parts[3]=scale2.mul(high2);
  Ok(())
 }
fn process_kind(w:&Weights,kind:usize,alpha:&[E],f:&[u8],folds:usize,n:usize,
     ap0:&[E;4],ap1:&[E;4],scratch:&mut Vec<K>,parts:&mut [E;7])->Result<(),Error>{
  if w.variant==Variant::D && kind<4 {
   parts[kind]=w.dense_point_pair(kind,alpha,f)?;
  } else {
   let k=if kind<4 {kind-1}else{kind-2};
   w.tensor(k,folds,scratch);
   let mut scale=Weights::scalar_factor(&w.factors[k][0],ap0);
   if folds==2 {scale=scale.mul(Weights::scalar_factor(&w.factors[k][1],ap1));}
   let mut pair=crate::fast_pairing::EbyKDot::new();
   push_byte_products(&mut pair,f,scratch,n)?;
   parts[kind]=scale.mul(pair.finish());
  }
  Ok(())
 }

pub struct Weights {
    pub variant:Variant,
    pub factors:[[[K;4];5];5],
    pub points:[[K;10];3],
    pub extra:[K;2],
}
impl Weights {
    #[inline(never)]
    fn box_from_parts(variant:Variant,factors:[[[K;4];5];5],points:[[K;10];3],extra:[K;2])->Box<Self> {
        Box::new(Self { variant, factors, points, extra })
    }
    #[inline(never)]
    pub fn new(variant:Variant,alpha:&[K;10],z:&[SecureCirclePoint;2])->Result<Box<Self>,Error> {
        let points=aspis_core::state_only_prefix::r0::statement_points(alpha);
        let extra=[alpha[8],alpha[9]];
        let mut factors=[[[K::ZERO;4];5];5];
        for k in 0..3 { for d in 0..5 {
            let a=points[k][9-2*TAU[d]]; let b=points[k][8-2*TAU[d]];
            factors[k][d]=[K::ONE.sub(a).mul(K::ONE.sub(b)),a.mul(K::ONE.sub(b)),K::ONE.sub(a).mul(b),a.mul(b)];
        }}
        for k in 0..2 {
            factors[3+k][0]=[K::ONE,z[k].y,z[k].x,z[k].x.mul(z[k].y)];
            let mut x=double(z[k].x);
            for d in 1..5 {
                let y=double(x); factors[3+k][d]=[K::ONE,x,y,x.mul(y)]; x=double(y);
            }
        }
        Ok(Self::box_from_parts(variant, factors, points, extra))
    }
    pub fn raw(&self,kind:usize,j:usize)->K {
        match kind {
            0=>if aspis_core::r0::opening::inactive(self.variant.row(j)).unwrap() {K::ONE} else {K::ZERO},
            4=>if j<56 { self.extra[j/28].pow((j%28) as u64) } else {K::ZERO},
            1..=3 if self.variant==Variant::D => {
                let r=self.variant.row(j);
                (0..10).fold(K::ONE,|v,b|v.mul(if r&(1<<b)==0 {K::ONE.sub(self.points[kind-1][9-b])}else{self.points[kind-1][9-b]}))
            },
            _=> {
                let k=if kind<4 {kind-1}else{kind-2};
                (0..5).fold(K::ONE,|v,d|v.mul(self.factors[k][d][(j>>(2*d))&3]))
            }
        }
    }
    fn scalar_factor(f:&[K;4],p:&[E;4])->E {
        (0..4).fold(E::ZERO,|v,s|v.add(p[PERM[s]].mul_qm31(f[s]))).mul_m31(QUARTER)
    }
    fn tensor(&self,k:usize,folds:usize,output:&mut[K]) {
        output[0]=K::ONE;let mut n=1;
        for d in folds..5 {
            for j in (0..n).rev() {
                let x=output[j];
                output[j+0*n]=x.mul(self.factors[k][d][0]);
                output[j+1*n]=x.mul(self.factors[k][d][1]);
                output[j+2*n]=x.mul(self.factors[k][d][2]);
                output[j+3*n]=x.mul(self.factors[k][d][3]);
            }
            n*=4;
        }
    }
    pub fn dual_raw(&self,kind:usize,j:usize,alpha:&[E])->E {
        let p0=powers::<4>(alpha[0]);
        let p1=if alpha.len()==2 {powers::<4>(alpha[1])}else{[E::ONE;4]};
        let width=1<<(2*alpha.len());
        let mut sum=E::ZERO;
        for s in 0..width {
            let p=p0[PERM[s%4]].mul(p1[PERM[s/4]]);
            sum=sum.add(p.mul_qm31(self.raw(kind,width*j+s)));
        }
        for _ in alpha { sum=sum.mul_m31(QUARTER); }
        sum
    }
    /// Product rows keep a K tensor after their low digits have been folded.
    /// Only the contracted scalar is in E. Sparse rows are handled separately.
    #[inline(never)]
    pub fn pair(&self,alpha:&[E],f:&[u8],kappa:E)->Result<E,Error> {
        let n=f.len()/32; let folds=alpha.len();
        let mut expected_n=1024usize; for _ in 0..folds { expected_n=expected_n>>2u32; } if n!=expected_n {return Err(Error::Parse);}
        let ap0=powers::<4>(alpha[0]);
        let ap1=if folds==2 {powers::<4>(alpha[1])}else{[E::ONE;4]};
        let mut scratch=match aspis_core::r0::heap::filled(n,K::ZERO) { Ok(v) => v, Err(_) => return Err(Error::Allocation) };
        let mut parts=[E::ZERO;7];
        // On S2's two-fold path the high tensor factors for point rows 0 and
        // 2 are identical. Keep the equality guard so arbitrary constructed
        // `Weights` values retain the original per-row fallback.
        let shared_two_point=shared_two_point_guard(self,folds);
        process_regular_kinds(self,shared_two_point,alpha,f,folds,n,&ap0,&ap1,&mut scratch,&mut parts)?;
        if shared_two_point {
            // The two point rows share the d2/d3 coefficients. Preserve the
            // tensor's least-significant-first order: d2 is j mod 4 and d3
            // is j / 4. Each d4 slice then contracts one 16-term EbyKDot.
            let mut common=[K::ZERO;16];
            for j in 0..16 { common[j]=self.factors[0][2][j&3].mul(self.factors[0][3][j>>2u32]); }
            let partials=shared_partials(f,&common)?;
            shared_high(&partials,self,&ap0,&ap1,&mut parts)?;
        }
        if folds==1 {
            let mut dual=[E::ZERO;16];
            for mask in 0..16 {
                let mut weight=E::ZERO;
                for s in 0..4 { if mask&(1usize<<(s as u32))!=0 { weight=weight.add(ap0[PERM[s]]); } }
                dual[mask]=weight.mul_m31(QUARTER);
            }
            let mut groups=[E::ZERO;16];
            for j in 0..n {
                let mut mask=0;
                for s in 0..4 {if self.raw(0,4*j+s)==K::ONE {mask|=1usize<<(s as u32);}}
                groups[mask]=groups[mask].add(field(f,j));
            }
            for m in 1..16 {parts[0]=parts[0].add(groups[m].mul(dual[m]));}
            for side in 0..2 {
                let p=kpowers::<5>(self.extra[side]);
                let scale=Self::scalar_factor(&[p[0],p[1],p[2],p[3]],&ap0);
                let mut power=K::ONE; let mut pair=E::ZERO;
                for j in 0..7 {pair=pair.add(field(f,j+7*side).mul_qm31(power));power=power.mul(p[4]);}
                parts[4]=parts[4].add(pair.mul(scale));
            }
        } else {
            // Two-fold 0/1 row: compute the sixteen challenge products once.
            // Coefficients with the same inactive mask share one subset sum.
            let mut low=[E::ZERO;16];
            for s in 0..16 { low[s]=ap0[PERM[s%4]].mul(ap1[PERM[s/4]]).mul_m31(QUARTER.mul(QUARTER)); }
            parts[0]=grouped_inactive_pair(self,f,&low);
            let libra=if self.variant==Variant::S2 {factored_s2_libra_weights(&ap0,&ap1,self.extra)}else{twofold_libra_weights(&low,self.extra)};
            for j in 0..4 {parts[4]=parts[4].add(field(f,j).mul(libra[j]));}
        }
        #[cfg(feature="prover")]
        for kind in 0..7 {
            for j in 0..1024 {crate::trace::value(6,kind*1024+j,E::from_qm31(self.raw(kind,j)));}
            for j in 0..n {crate::trace::value(7,kind*n+j,self.dual_raw(kind,j,alpha));}
        }
        let k=powers::<7>(kappa);let mut sum=E::ZERO;
        for kind in 0..7 {crate::trace::value(8,kind,parts[kind]);sum=sum.add(k[kind].mul(parts[kind]));}
        Ok(sum)
    }
    #[inline(never)]
    fn dense_point_pair(&self,kind:usize,alpha:&[E],f:&[u8])->Result<E,Error> {
        // D keeps the full eq tensor. Hoist the sixteen shared E products
        // before combining its K entries; no tensor factorization is assumed.
        let mut rows=match aspis_core::r0::heap::filled(1024,K::ZERO) { Ok(v) => v, Err(_) => return Err(Error::Allocation) };
        rows[0]=K::ONE;let mut width=1;
        for b in 0..10 {
            let p=self.points[kind-1][9-b];
            for j in (0..width).rev() {let x=rows[j];rows[j+width]=x.mul(p);rows[j]=x.mul(K::ONE.sub(p));}
            width*=2;
        }
        let a=powers::<4>(alpha[0]);let b=powers::<4>(alpha[1]);
        let mut low=[E::ZERO;16];
        for s in 0..16 { low[s]=a[PERM[s%4]].mul(b[PERM[s/4]]).mul_m31(QUARTER.mul(QUARTER)); }
        let mut pair=E::ZERO;
        for j in 0..64 {
            let mut w=E::ZERO;
            for s in 0..16 {w=w.add(low[s].mul_qm31(rows[self.variant.row(16*j+s)]));}
            pair=pair.add(field(f,j).mul(w));
        }
        Ok(pair)
    }
    pub fn materialize(&self,kappa:E)->Result<Vec<E>,Error> {
        let kp=powers::<7>(kappa);
        let mut w=match aspis_core::r0::heap::filled(1024,E::ZERO) { Ok(v) => v, Err(_) => return Err(Error::Allocation) };
        for (j,v) in w.iter_mut().enumerate() {for kind in 0..7 {*v=v.add(kp[kind].mul_qm31(self.raw(kind,j)));}}
        Ok(w)
    }
}

#[cfg(test)]
mod s2_inactive_table_tests {
    use super::*;
    #[test]
    fn all_s2_inactive_table_entries_match_reference() {
        for j in 0..64 {
            let group=S2_INACTIVE_GROUPS[j] as usize;
            assert!(group<S2_INACTIVE_MASKS.len());
            for bit in 0..16 {
                assert_eq!((S2_INACTIVE_MASKS[group]>>bit)&1!=0,
                    aspis_core::r0::opening::inactive(Variant::S2.row(16*j+bit)).unwrap());
            }
        }
        // Equality of each coefficient's scalar factor establishes the
        // regrouping identity independently of particular message values.
        for bit in 0..16 {
            let low=core::array::from_fn(|i|if i==bit {E::ONE}else{E::ZERO});
            for j in 0..64 {
                let mut f=alloc::vec![0u8;64*32];f[j*32..(j+1)*32].copy_from_slice(&E::ONE.to_le_bytes());
                let expected=if aspis_core::r0::opening::inactive(Variant::S2.row(16*j+bit)).unwrap(){E::ONE}else{E::ZERO};
                assert_eq!(s2_grouped_inactive_pair(&f,&low),expected);
            }
        }
    }
}

#[cfg(test)]
mod libra_factor_tests {
    use super::*;
    #[test]
    fn factored_libra_matches_all_four_original_weights() {
        let mut state=0x13198a2e03707344u64;
        let mut field=|| {state=state.wrapping_mul(6364136223846793005).wrapping_add(1);(state%u64::from(aspis_core::field::P)) as u32};
        for case in 0..512 {
            let mut value=||E::from_limbs(core::array::from_fn(|_|match case {0=>0,1=>1,2=>aspis_core::field::P-1,_=>field()})).unwrap();
            let ap0=core::array::from_fn(|_|value());let ap1=core::array::from_fn(|_|value());
            let extra=[value().c0(),value().c0()];
            let low=core::array::from_fn(|s|ap0[PERM[s%4]].mul(ap1[PERM[s/4]]).mul_m31(QUARTER.mul(QUARTER)));
            assert_eq!(factored_s2_libra_weights(&ap0,&ap1,extra),twofold_libra_weights(&low,extra),"case {case}");
        }
    }
}
