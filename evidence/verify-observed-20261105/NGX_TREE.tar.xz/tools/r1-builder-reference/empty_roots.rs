//! Fixed-input leaf certificates and a checked call-trace composition.
//! Table is generated from R0P.EmptyRoots.emptyRootsNat; no source hashes
//! are stubbed in any leaf harness. Only the composition stubs the already
//! checked exact calls, verifying every argument and the exact call count.
use super::super::*;
use crate::pool_v1::pool_v1_tree_parent;
const ROOTS: [[u32; 8];21] = [
    [1438900896, 782233260, 1544844157, 891350894, 986827501, 300047813, 266092546, 1155026732],
    [141619947, 1448060902, 524379093, 1944458907, 1832113773, 579270723, 752346270, 1038346536],
    [1119858538, 128294437, 939091034, 659145897, 1933666768, 903679201, 1182639487, 1398246146],
    [1057897051, 1132946363, 794377079, 1971564389, 1255722275, 926653737, 2031728153, 2024887573],
    [1410054462, 673771449, 940847521, 274330358, 1719505495, 1690439941, 203201419, 1855504616],
    [1442759752, 1540325866, 188964047, 101815282, 1883549730, 1774537487, 1306717763, 561084592],
    [244193611, 984304317, 1467689208, 2063463197, 1766003332, 1300835127, 1578947755, 745931587],
    [673192756, 38070812, 1453532835, 1340577407, 368420458, 1834405704, 270061815, 711700631],
    [27092219, 1272373356, 998194489, 1458413288, 887470405, 1204987730, 864453460, 553704718],
    [1972918328, 1234090299, 977162835, 1704494754, 1617603773, 1819200880, 906453206, 1653526885],
    [418360492, 472096212, 871749117, 98906847, 2026788776, 1504737042, 407274798, 1800828893],
    [986339640, 660349625, 1012157959, 454024326, 987656904, 622864739, 1150440730, 1280042062],
    [2118470693, 1706590589, 2128512933, 167263577, 409542414, 1323179656, 1880070613, 2053396184],
    [260546973, 1375125357, 1584234519, 1097072342, 1685367984, 1070989054, 2113798037, 958210542],
    [1239966481, 992485427, 1397515674, 466658549, 2071909237, 712995354, 2047452742, 1680224983],
    [1796237568, 1862343136, 1954463912, 1190686266, 364700025, 46960257, 671215600, 1214723477],
    [1127845264, 662862400, 84021756, 995080286, 1419670571, 1966281459, 837284626, 2083375353],
    [1321679286, 782621548, 1415820264, 74436574, 776350425, 323154748, 429051705, 1299980413],
    [1519171444, 1235587172, 1671492368, 1449613582, 547369941, 1621086153, 266860322, 450526803],
    [19381883, 1308966873, 251977766, 474343397, 2069732268, 1863820229, 152153379, 665567443],
    [1201428963, 1296676114, 441891487, 1910121140, 602621674, 1294160489, 1878016864, 855887413],
];
fn root(n: usize) -> Digest { ROOTS[n].map(M31) }
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_00() {
    let input = [M31(0);8];
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[0][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_01() {
    let input = root(0);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[1][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_02() {
    let input = root(1);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[2][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_03() {
    let input = root(2);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[3][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_04() {
    let input = root(3);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[4][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_05() {
    let input = root(4);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[5][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_06() {
    let input = root(5);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[6][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_07() {
    let input = root(6);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[7][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_08() {
    let input = root(7);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[8][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_09() {
    let input = root(8);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[9][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_10() {
    let input = root(9);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[10][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_11() {
    let input = root(10);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[11][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_12() {
    let input = root(11);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[12][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_13() {
    let input = root(12);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[13][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_14() {
    let input = root(13);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[14][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_15() {
    let input = root(14);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[15][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_16() {
    let input = root(15);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[16][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_17() {
    let input = root(16);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[17][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_18() {
    let input = root(17);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[18][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_19() {
    let input = root(18);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[19][i]); }
}
#[kani::proof]
#[kani::unwind(33)]
fn empty_root_leaf_20() {
    let input = root(19);
    let actual = pool_v1_tree_parent(&input, &input);
    for i in 0..8 { assert_eq!(actual[i].0, ROOTS[20][i]); }
}
static mut CALLS: usize = 0;
fn checked_parent(left: &Digest, right: &Digest) -> Digest {
    let n = unsafe { CALLS }; assert!(n < 21);
    let expected = if n == 0 { [M31(0);8] } else { root(n-1) };
    for i in 0..8 { assert_eq!(left[i].0, expected[i].0); assert_eq!(right[i].0, expected[i].0); }
    unsafe { CALLS = n+1; }
    root(n)
}
#[kani::proof]
#[kani::unwind(22)]
#[kani::stub(crate::pool_v1::pool_v1_tree_parent, checked_parent)]
fn empty_root_call_trace() {
    unsafe { CALLS = 0; }
    let actual = pair_empty_roots();
    assert_eq!(unsafe { CALLS },21);
    for l in 0..21 { for i in 0..8 { assert_eq!(actual[l][i].0,ROOTS[l][i]); } }
}
