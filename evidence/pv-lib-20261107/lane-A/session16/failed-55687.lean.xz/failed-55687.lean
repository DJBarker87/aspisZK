import PV_LIB_SPEC_LaneAJoins18
set_option autoImplicit false
noncomputable section
-- IR companions accompany source objects in the private overlay.
-- Import server/private companions are included in the exact overlay.
-- Compiled in the pinned C18 compatibility cohort with exact object resolution.
namespace PV_LIB_A_F170Continuation16
open PV_STX_Machine PV_STX2_Syntax PV_STX2_Store PV_STX2_SliceMachine
open PV_EVHB_OwnerMachine PV_LIB_SPEC_D984 PV_LIB_SPEC_Frozen
open PV_LIB_SPEC_ResourceHistory (Execution Issued Context)
open PV_LIB_SPEC_F1Arithmetic14 (stage)

theorem trace (cut : PV_LIB_SPEC_ReachedNative14.Cut) (p : Parameters) (H : Handler)
    (s : Store Data) (a : Nat) (parents : List Frame) (w : OWNER) (es : List Event)
    (issued : List Issued) (consumed : List Context) (v : Data)
    (value : s.cells ⟨a,14,[]⟩ = some v) :
    PV_LIB_SPEC_SourceTransport15.Trace cut p H 9
      (stage s a parents (PV_THR2_F170.live.body.drop 40) w es issued consumed) := by
  simp [PV_LIB_SPEC_SourceTransport15.Trace,PV_LIB_SPEC_SourceTransport15.sourceStep,
    PV_LIB_SPEC_SourceTransport15.Quiet,PV_LIB_SPEC_ControlRuntime.ordinary,
    PV_LIB_StoreActionTable.Neutral,PV_LIB_StoreActionTable.select,
    PV_THR2_OwnInitAction.selected,PV_THR2_OperatorAction.selected,
    PV_THR2_OperatorAction.instruction,PV_THR2_OwnUniformNeutral.configuration,
    PV_THR2_OwnUniformNeutral.instruction,PV_THR2_InterpreterAgreement.NativeAgree,
    PV_THR2_HandlerExecutionAgreement.Agree,stage,
    PV_THR2_IntrinsicState.step,PV_THR2_Catch316Segment.select,PV_THR2_Execution.step,
    PV_THR2_Dynamic.active,PV_THR2_Dynamic.operandOf,PV_THR2_GapCompletion.step,
    PV_THR2_AggregateCompletion.complete,PV_THR2_AggregateCompletion.carrier,
    PV_STX2_SliceMachine.step,PV_THR2_F170.live,PV_THR2_F170.block66,
    PV_THR2_F170.node56,PV_THR2_F170.node57,PV_THR2_F170.node58,PV_THR2_F170.node59,PV_THR2_F170.node60,PV_THR2_F170.node61,PV_THR2_F170.node62,PV_THR2_F170.node63,PV_THR2_F170.node64,PV_THR2_F170.node65,
    native,adopt,PV_STX2_Native.step,PV_STX2_Store.bind,evaluate,operands,operand,
    PV_STX2_Store.read,locate,writeAddress,PV_STX2_Store.write,value]

#print axioms trace
end PV_LIB_A_F170Continuation16
