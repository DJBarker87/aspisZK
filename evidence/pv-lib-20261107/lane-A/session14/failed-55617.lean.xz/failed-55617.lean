import PV_LIB_A_PrefixMachine11
import PV_THR2_TableIntrinsic
set_option autoImplicit false
noncomputable section
namespace PV_LIB_A_TableCongruence14
open PV_STX_Machine PV_STX2_Syntax PV_STX2_Store PV_STX2_SliceMachine
open PV_EVHB_OwnerMachine PV_EVHB_OwnerHeap PV_THR2_SourceStoreLibrary PV_LIB_StoreActionTable
abbrev Agree := @PV_THR2_TableIntrinsic.Agree

theorem uniform (C : Carrier OWNER Data) (K : Control)
    (P Q : Data → Option PV_STX2_SliceSyntax.Program) (H : Handler) (s : State)
    (same : Agree P Q s) :
    PV_THR2_OwnUniformBindings.step C K P H s = PV_THR2_OwnUniformBindings.step C K Q H s := by
  unfold PV_THR2_OwnUniformBindings.step
  rw [PV_THR2_TableIntrinsic.step C K P Q H s same]

theorem operator (C : Carrier OWNER Data) (K : Control)
    (P Q : Data → Option PV_STX2_SliceSyntax.Program) (H : Handler) (s : State)
    (same : Agree P Q s) :
    PV_THR2_OperatorInterpreter.step C K P H s = PV_THR2_OperatorInterpreter.step C K Q H s := by
  unfold PV_THR2_OperatorInterpreter.step
  cases status : s.current.status with
  | running c =>
    cases action : PV_THR2_OperatorAction.selected c with
    | none => exact uniform C K P Q H s same
    | some action => cases action <;> exact uniform _ K P Q _ s same
  | returned r store => exact uniform C K P Q H s same
  | fault f store => exact uniform C K P Q H s same
  | undefined site store => exact uniform C K P Q H s same

theorem owner (C : Carrier OWNER Data) (K : Control)
    (P Q : Data → Option PV_STX2_SliceSyntax.Program) (resources : Resources) (encode : Encode)
    (H : Handler) (s : State) (same : Agree P Q s) :
    PV_THR2_OwnInitInterpreterBridged.step C K P resources encode H s =
      PV_THR2_OwnInitInterpreterBridged.step C K Q resources encode H s := by
  unfold PV_THR2_OwnInitInterpreterBridged.step
  cases status : s.current.status with
  | running c =>
    split <;> exact operator C K P Q _ s same
  | returned r store => exact operator C K P Q H s same
  | fault f store => exact operator C K P Q H s same
  | undefined site store => exact operator C K P Q H s same

theorem select (P Q : Data → Option PV_STX2_SliceSyntax.Program) (c : Config)
    (same : PV_THR2_TableStepShape.Agree P Q c) : sourceSelect P c = sourceSelect Q c := by
  unfold sourceSelect
  cases done : c.frame.completed with
  | some r => rfl
  | none =>
    cases waiting : c.frame.waiting with
    | none => rfl
    | some wait =>
      cases request : wait.request with
      | child fn a args => simp only [Option.bind,request,same wait fn a args done waiting request]
      | copy x y z => simp only [Option.bind,request]
      | drop fn x => simp only [Option.bind,request]

/-- Local resolver agreement extends through SOURCE phases, OWNER allocation,
operator and registration layers. Resources, replies, worlds and events are
identical. This compares one machine step, not callee activation counters. -/
theorem source (C : Carrier OWNER Data) (K : Control)
    (P Q : Data → Option PV_STX2_SliceSyntax.Program) (resources : Resources) (encode : Encode)
    (H : Handler) (values : Values OWNER PV_RJ4IDB.NativeEvent) (s : SourceState)
    (same : Agree P Q s.base) :
    sourceStep C K P resources encode H values s = sourceStep C K Q resources encode H values s := by
  unfold sourceStep
  cases phase : s.applied with
  | some p => rfl
  | none =>
    cases status : s.base.current.status with
    | running c =>
      simp only [phase,status,select P Q c (same c status),owner C K P Q resources encode H s.base same]
    | returned r store => simp only [phase,status,owner C K P Q resources encode H s.base same]
    | fault f store => simp only [phase,status,owner C K P Q resources encode H s.base same]
    | undefined site store => simp only [phase,status,owner C K P Q resources encode H s.base same]

theorem step (C : Carrier OWNER Data) (K : Control)
    (P Q : Data → Option PV_STX2_SliceSyntax.Program) (resources : Resources) (encode : Encode)
    (H : Handler) (values : Values OWNER PV_RJ4IDB.NativeEvent) (s : SourceState)
    (same : Agree P Q s.base) :
    PV_LIB_A_DeferredActions.step C K P resources encode H values s =
      PV_LIB_A_DeferredActions.step C K Q resources encode H values s := by
  unfold PV_LIB_A_DeferredActions.step
  cases phase : s.applied with
  | none => exact source C K P Q resources encode H values s same
  | some p =>
    rcases p with ⟨site,tail⟩
    cases tail <;> simp only [source C K P Q resources encode H values s same]

#print axioms uniform
#print axioms operator
#print axioms owner
#print axioms select
#print axioms source
#print axioms step
end PV_LIB_A_TableCongruence14
