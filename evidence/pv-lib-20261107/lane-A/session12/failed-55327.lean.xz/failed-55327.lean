import PV_LIB_A_Continuation12
import PV_LIB_A_RangeStartTrace11
import PV_THR2_IntrinsicStructuredCall
set_option autoImplicit false
noncomputable section
namespace PV_LIB_A_StructuredTrace12
open PV_STX_Machine PV_STX2_Syntax PV_STX2_Store PV_STX2_SliceMachine
open PV_EVHB_OwnerMachine PV_LIB_StoreActionTable PV_LIB_A_PrefixMachine11

theorem issue_quiet (P : Data → Option PV_STX2_SliceSyntax.Program)
    (s : Store Data) (a : Nat) (parents : List Frame) (loops : List LoopFrame)
    (rest : List PV_STX2_SliceSyntax.Node) (site : Site) (fn : Data) (args : List Operand) (dest : Nat)
    (w : OWNER) (es : List PV_RJ4IDB.NativeEvent) (stack : List Config) :
    Quiet P ⟨⟨.running ⟨{activation := a,remaining := .leaf (.call site fn args (.local dest) []) :: rest,loops := loops},parents,s⟩,w,es⟩,stack⟩ := by
  constructor
  · intro c hc; cases hc; rfl
  · intro c hc; cases hc; exact ⟨rfl,rfl,True.intro⟩

theorem enter_quiet (P : Data → Option PV_STX2_SliceSyntax.Program)
    (s : Store Data) (a : Nat) (parents : List Frame) (loops : List LoopFrame)
    (rest : List PV_STX2_SliceSyntax.Node) (fn : Data) (vs : List Data) (dest : Nat)
    (body : PV_STX2_SliceSyntax.Program) (resolved : P fn = some body)
    (w : OWNER) (es : List PV_RJ4IDB.NativeEvent) (stack : List Config) :
    Quiet P ⟨⟨.running (PV_THR2_IntrinsicFrameEnter.pending s a parents loops rest fn vs dest),w,es⟩,stack⟩ := by
  constructor
  · intro c hc; cases hc
    unfold sourceSelect
    change (match P fn with | some _ => none | none => _) = none
    rw [resolved]
  · intro c hc; cases hc; exact ⟨rfl,rfl,True.intro⟩

/-- Structured source calls have no source-leaf action. The failed-operand arm
is still one step to its actual gap; successful operands enter the named body. -/
theorem trace (C : Carrier OWNER Data) (K : Control)
    (P : Data → Option PV_STX2_SliceSyntax.Program) (H : Handler)
    (s : Store Data) (a : Nat) (parents : List Frame) (loops : List LoopFrame)
    (rest : List PV_STX2_SliceSyntax.Node) (site : Site) (kind generics : Data)
    (args : List Operand) (dest : Nat) (body : PV_STX2_SliceSyntax.Program)
    (w : OWNER) (es : List PV_RJ4IDB.NativeEvent) (stack : List Config)
    (stable : operands (PV_THR2_AggregateCompletion.carrier C) w a args s = operands C w a args s)
    (resolved : P (.object [("Regular",.object [("kind",kind),("generics",generics)])]) = some body) :
    Trace C K P H (PV_THR2_IntrinsicStructuredCall.steps C s a args w)
      ⟨⟨.running ⟨{activation := a,remaining := .leaf (.call site
        (.object [("Regular",.object [("kind",kind),("generics",generics)])]) args (.local dest) []) :: rest,loops := loops},parents,s⟩,w,es⟩,stack⟩ := by
  unfold PV_THR2_IntrinsicStructuredCall.steps
  apply append C K P H 1 _ _ ⟨issue_quiet P s a parents loops rest site _ args dest w es stack,True.intro⟩
  rw [PV_THR2_IntrinsicFrameCall.run C K P H s a parents loops rest site kind generics args dest w es stack stable]
  unfold PV_THR2_IntrinsicFrameCall.after
  cases h : operands C w a args s with
  | none => trivial
  | some pair =>
    rcases pair with ⟨vs,t⟩
    exact ⟨enter_quiet P t a parents loops rest _ vs dest body resolved w es stack,True.intro⟩

#print axioms issue_quiet
#print axioms enter_quiet
#print axioms trace
end PV_LIB_A_StructuredTrace12
