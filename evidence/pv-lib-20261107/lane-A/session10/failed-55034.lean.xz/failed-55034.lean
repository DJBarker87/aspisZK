import PV_LIB_A_WeakGuardCaller9
import PV_LIB_A_TypedBody661
set_option autoImplicit false
namespace PV_LIB_A_DestructorValues10
open PV_STX2_Syntax PV_STX2_Store PV_EVHB_OwnerMachine

/-- Source unit is an empty value, not a physical allocation byte image. -/
def unitValue : Data := PV_THR2_KeyValues.pack PV_LIB_A_GenericDropMachine.unitTag []

/-- Interpret the actual empty-tuple literal used as reference metadata in the
emitted destructors. This binds a source literal; it supplies no native reply. -/
def constant (fallback : Data → Option Data) : Data → Option Data
  | .object [("kind",.object [("Adt",.array [.null,.array []])]),
      ("ty",.object [("Adt",.object [("id",.atom "Tuple"),("generics",.object
        [("regions",.array []),("types",.array []),("const_generics",.array []),
         ("trait_refs",.array [])])])])] => some unitValue
  | d => fallback d

def carrier (C : Carrier OWNER Data) (b : Bool) : Carrier OWNER Data :=
  let original := PV_THR2_OwnInitExactReturnedCases.carrier C b
  {original with constant := constant original.constant}

def metadata : Data :=
  match PV_LIB_A_TypedBody661.node4 [] with
  | .leaf (.bind _ _ (.reference _ (.constant m))) => m
  | _ => .null

theorem literal (C : Carrier OWNER Data) (b : Bool) :
    (carrier C b).constant metadata = some unitValue := rfl

theorem reference (C : Carrier OWNER Data) (b : Bool) (p : Address) (m : Data) (w : OWNER) :
    (carrier C b).dereference w ((carrier C b).reference p m) = some p := rfl

theorem aggregate (C : Carrier OWNER Data) (b : Bool) :
    (carrier C b).aggregate PV_LIB_A_GenericDropMachine.unitTag [] = some unitValue := rfl

#print axioms unitValue
#print axioms constant
#print axioms carrier
#print axioms metadata
#print axioms literal
#print axioms reference
#print axioms aggregate
end PV_LIB_A_DestructorValues10
