# W5 session11 — copy leaf closed

Branch codex/pv-w5-20261109; continuation base113e7bd6f23459cd61cad3a7d120f2c186e4235b.
W5 complete in the pinned unchanged checker overlay:28 CLOSED /0 PARTIAL /0 OPEN.
Newly CLOSED: slice:builtin:CopyNonOverlapping, PV_W5_CopyContract.contract.
Authoritative ledger untouched. Full closure with13 direct/transitive contexts:
evidence/pv-w5-20261109/closures.json. Current partial-proposals rows are empty.

## Claim and hypotheses

The generic full-reply contract and its Pre are byte-unchanged. Its verbatim
proposition binders (from focused printer48501) are:

    (pre : PV_W5_CopyContract.Pre (fun {A} => resources) e w)
    (fresh : FreshAllocationValidity' (fun {A} => resources) granted e.allocationEntry)
    (malloc_semantics : PV_STX2_IntrinsicSemantics_Malloc fun {A} => resources)

Complete named binder inventory is in statements/PV_W5_CopyContract.contract.json;
expanded Pre/Post/Entry and both theorem statements are in out-48501.log.
Source validity and positive malloc provenance at s630 are now DERIVED by
PV_W5_CopyAt630.contract. It consumes the pinned slice export
PV_STX2_ToVecCopyCallerReady.closed, which instantiates CLOSED f31 at s581 and
uses PV_STX2_ToVecCopyCallerContext.from_f31 BY NAME. Provider pin:
9a866ae82fe7a6318ee9254dd94dfaaa6b7e9458 (D964), inspected with git show only.
No f31/f35/f59 instructions replayed in the new consumer. Exact operands and
thread25 numbering retained. No counter or whole-store equality across calls.

The caller helper's running/completed/positive selectors identify arrival at
s630. They are not leaf-contract hypotheses. Zero length bypasses s630; other
f31 outcomes retain their own provider statuses/world/events. The intrinsic
contract covers every returned/error/fault/divergence/pending answer and ends
at its native answer, without running into the caller (thread23/23').
Foundation-construction discharge of the refined typed entry remains the
existing named caller obligation. No endpoint premise or T field added/removed.

## Verification

Focused48500 PV_W5_CopyAt630: exit0, wall0:03.24, peak4661480KiB, swap0.
Focused48501 PV_W5_CopyStatement: exit0, wall0:02.54, peak4668348KiB, swap0.
One strict raw audit45956:3/3 roots PASS, zero unresolved constants, zero
raw/summary disagreements, only propext/Classical.choice/Quot.sound; exit0,
wall0:11.39, peak6837552KiB, swap0, source8063a4e65a3c4fa0a0ba2b33ff2ca22e32fc10a8.
Receipts, source hashes, dependency fingerprints and summary-based #print axioms:
session11/formal-results.json. Raw graphs:raw45956/; raw-audit-45956.json.
Strict walker and constructor-summary union unchanged; only root/module arrays
changed. Every shared effective object hash equals the pinned provider cohort.
No unchanged full regression or package manifest replay was run.

Audit45955 was admission-refused before compiler start, retired under D802;
full180s cooldown observed before48501. D942 turn check ran separately before
every ID. turn.sh exited0 with transient /proc cmdline ENOENT scanner messages.
No slot.sh or lock used. Caps6G/8G/swap0/tasks64, Lean-M7000. All host writes
inside own W5 directory, no deletion. Local launcher ID-range assertion only
extended to48500–48599. No frozen source, wallet/key, endpoint or provider edits.
IDs consumed:48500,48501,45955(refused),45956; next fresh Lean48502/raw45957.

Pinned checker: research84e6b3cfbd787211dbcb04a7e218e9dabd2750d5, unchanged
SHA45b1242a814008575f9ba44438d10ec6096fe17cc56e519c7c4521cacaa02c99.
Run python3 tools/pv-w5-20261109/check-session11.py.
Result session11/checker-output.json: W5 28/0/0; global96/125 CLOSED;
slice32 CLOSED/1 PARTIAL/10 OPEN; thread64 CLOSED/8 PARTIAL/10 OPEN; errors[].
D953 f32/f33 closures reused unchanged. Authoritative ledger not modified.

## Remaining work and next deliverable

No W5 row remains partial or open. Lead may accept the copy closure from the
pinned evidence; slice owns f21 and Programs.source7 composition. No root,
release correspondence or privacy endpoint closure is claimed. Endpoint
premises removed0; privacy target not yet established. No push, merge or delegation.

Session commits before the final evidence/handoff commit:

b27506d65de Record the copy leaf closure with all caller contexts
84cbcb547f3 Audit the copy closure and actual caller discharge strictly
8063a4e65a3 Record the complete copy contract statement and hypothesis inventory
db820e53289 Discharge the actual copy contract from the closed f31 context
