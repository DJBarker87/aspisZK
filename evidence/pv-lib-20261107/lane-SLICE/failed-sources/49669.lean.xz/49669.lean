import PV_LIB_Observation
import PV_FN_SLICE_f7_RuntimeDrop
import PV_FN_SLICE_f7_DestructorBinding
set_option autoImplicit false
noncomputable section
namespace PV_LIB_SLICE_TypedDrop
open PV_STX_Machine PV_STX2_Syntax PV_STX2_Store PV_STX2_SliceMachine PV_EVHB_OwnerMachine
abbrev Input := PV_FN_SLICE_f7_RuntimeDrop.Input

def model (x : Input) (capture : Data) :=
  PV_LIB.observe (PV_FN_SLICE_f7_AfterDrop.finish x capture
    (x.H (.drop PV_FN_SLICE_f7_AfterDrop.source.1 capture) x.w))
def law (x : Input) (capture : Data)
    (out : PV_LIB.MachineObservation OWNER PV_RJ4IDB.NativeEvent) : Prop :=
  out = model x capture

/-- W2's proved runtime adapter uses the ACTUAL typed f22 execution to derive
its caller-store projection. The full native reply is retained; no arbitrary
identity delta or empty writable set is supplied. This is the Drop suffix
adapter, not a full f7 provider or a discharge of its missing f6 dependency. -/
theorem certified (x : Input) (capture : Data)
    (spec : PV_FN_SLICE_RuntimeBindings.DropSemantics x.H)
    (cell : x.s.cells ⟨x.a,1,[]⟩ = some capture)
    (value : x.s.cells ⟨x.a,0,[]⟩ = some x.ptr)
    (saved : x.parent.waiting = some x.wait)
    (action : x.wait.action = .child x.a (.local x.dest))
    (pre : PV_W1_OwnerWellFormed.OwnerWellFormed x.w x.s.nextActivation) :
    let r := x.H (.drop PV_FN_SLICE_f7_AfterDrop.source.1 capture) x.w
    law x capture (PV_LIB.observe (PV_THR2_IntrinsicState.advance
      (PV_FN_SLICE_ValueCarrier.carrier x.C) x.K x.P x.H
      (1+1+PV_FN_SLICE_f7_AfterDrop.steps r)
      ⟨⟨.running ⟨{activation := x.a,remaining := PV_STX2_SliceF7.program.body.drop 4},
        x.parent :: x.parents,x.s⟩,x.w,x.es⟩,x.stack⟩)) := by
  exact congrArg PV_LIB.observe
    (PV_FN_SLICE_f7_RuntimeDrop.run x capture spec cell value saved action pre)

theorem selected : PV_STX2_ChainCaptures.regular
    (.object [("Regular",PV_FN_SLICE_f7_Drop.source)]) = some 22 :=
  PV_FN_SLICE_f7_DestructorBinding.selected

#print axioms certified
#print axioms selected
end PV_LIB_SLICE_TypedDrop
