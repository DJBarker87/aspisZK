# Automatic-relaunch continuation progress

FINAL LEAN CHECKPOINT: IDs48900..48999 ALL SPENT,57 accepted/31 failed/
12 refused. No remaining authorized Lean ID. Raw45903 PASSED108/108 roots across32modules, zero unresolved/mismatch,
standard axioms only; exit0 wall0:45.62 peak6778808KiB swap0.
Next raw45904 only for new proof/source evidence (no unchanged regression).
Raw allowed through45909. Every passing focused module through48998 committed.
48999 FAILED: initialized-store registry rfl hits isDefEq heartbeat limit;
several branch simp goals were True rather than conjunctions. Exact failed
source archived48999.lean.xz, removed from active lean/; NOT committed as a
Lean module. Future replacement needs symbolic header and field-store registry
frame lemmas, not more unfolding or raised heartbeat limits.

Join5 proved initial session19; join6 proved and strict raw45902 PASSED41/41
roots (13modules), zero unresolved/mismatch, standard axioms. No newly CLOSED
rows;361/270/166 PARTIAL;443/458/537 unchanged; premises removed0; target not
yet established. Required order remains finish7, then8..10,361.contract,
closures,270,166. Do not work ahead.

Join7 now has two source certificate paths:
- InitTo129.from_entry (48981) derives actual tagged payload from original
  entry, using exact join5 Entry facets; no physical callback history claim.
- History113.to113/physical113 (48980), HistoryRegistration.to118 (48984),
  HistoryClone.to119 (48986), HistoryMoves.to124/125/126 (48988),
  HistoryPayload.to129 (48989) preserve the SAME physical callback allocation
  origin, actual registration113 snapshot, and separate entry->113,
  delivered-allocation->113 and113->selected certificates. No independent
  existential traces are spliced. All source operations/callees reused by name.
- HistoryWorld.registration/backend/decoded (48990) proves actual registration
  world and backend commutation and tagged decoding from the original resource
  answer. No activation number is used as a physical address.

LATEST ACCEPTED:
HistoryOwned.from_history (48992): actual129 allBridged outcome/conditional
SourceOwnership export, decoder, two_steps agreement. No Checked/OwnInit claim.
HistoryTo129.from_entry/from92 (48994): same full history from original entry.
HistoryEntryExport.from_entry (48996): original entry -> Finished or129+Export.
CheckedComposition.start_mem/append_mem/checked_append (48997): generic trace
concatenation bookkeeping only, concrete Checked still OPEN.
InitAllocationBoundary.call/step (48998): exact14756 moved operand and complete
allocation reply edge, no resource success assumption. Context/owner to130 OPEN.
No uncompiled Lean drafts remain. Failed99 source is evidence only.

Remaining fulljoin7: OwnInit's registrationBefore has loops=[]; generic Cut
and current Origin retain loops without deriving emptiness. Need derive source
geometry from original-entry trace (never a new late ownership/read premise),
then attach exact OwnInit to SAME129 checkpoint and prove Checked for its
finite composition, then consume actual14756 allocation and frame to130.
Do not mistake Export for OwnInit or conditional SourceOwnership39 for an
actual binding at39. Original-machine carrier/resolver/handler satisfaction,
source/binary bridge adequacy, numbering clause/thread25 remain OPEN.

IDs continuation refusals:48926/41/47/67/70/72/83/85/87/91/93/95. Refused IDs spent,
>=180s cooldown, separate turn command before every next ID. Only own host dir,
no locks/provider/admission/cap changes. Every actual accepted/failed source is
compressed in session19-resume-sources/ID.lean.xz; sources.json is refreshed through99 with every decompressed snapshot SHA
checked against its receipt. Receipts include revision/source/dependency hashes, wall/RSS/swap/axioms.
Raw45903 audited108 roots/32modules since45902, with ONLY module/root lists
changed from existing W3Join6RawAudit driver (collector suffix SHA identical).
Full reachable inventories and hashes in session19-resume/reachable45903.json.xz
and audit-manifest45903.json. No audit/run remains active.
Collector/constructor summary union/private resolution/walker unchanged.

Old Facts/Pre/Post bytes unchanged. Optional454 shared-root fact and inventory
(48948..50) remain separate named source result with original satisfaction open
Recount14; actual214 callback frame derives from EXISTING facts.thread214 plus
value-adapter success and SourceValues, with missing-source fallback retained.
No endpoint/T/source implementation edits. No keys touched. No push/merge.

# W3 session19 current handoff

Branch codex/pv-w3-20261108; base31814d321232925b0548157e4f353f76e6fffbf4.
Read evidence/pv-w3-20261108/session19/{review.md,summary.json,commits.txt,
entry-refinement.md}. No row newly CLOSED;361/270/166 PARTIAL;443/458/537
unchanged. Endpoint premises removed0. Target not yet established.

## Required order / next deliverable

Successor JOIN5 is now PROVED as PV_FN_THREAD_f361ScopeJoin5.to92/join5.
Exact original-entry certificate through actual213 and BOTH hook arms to92,
with the name ownership/footprint gap handled as below. The original weaker
scope126_join_statement is retained unchanged, NOT inhabited by this theorem.

NEXT: finish join6 (callback BoxNew13923 at92 -> CLOSED443 at94 -> actual
14119/14121 casts -> CLOSED458 at106 -> source14320/cut113). Then7..10,
f361.contract, closures.json including covered_call_contexts and literal
CLOSED124/126 with no obsolete pending dependencies, then270/166. Do not
work ahead or commit placeholders. Existing join6 helpers below are audited.

## Join5 exact changes and limitations

PV_FN_THREAD_f361ScopeJoin5.Entry R x :=
  PV_FN_THREAD_f361NameEntryValidity.Pre' R x ∧
  PV_FN_THREAD_f361ScopeEntryValidity.Shape x.scope

Pre' = original Pre plus EXACT new EntryName clause, before/after verbatim
and old implication in entry-refinement.md. The actual caller270 supplies
Builder.name (10018 ->10029 ->10166); its discharge remains the same named
caller obligation, now including this clause. No ownership premise INSIDE a run.

String is OPAQUE N95807 type84: explicit parametric Representation.decode
interprets it into address/pointer/len/cap/UTF8 bytes; NO native field order or
invented source field projection is assumed. Original source/binary adequacy
of this interpretation is still an explicit Recount14 obligation, not proved.
NameOwned covers BOTH Option constructors, registered ownership, validity and
initialized bytes (including empty/dangling and interior-NUL/abort cases).
Age/Scope separation derives from actual registration and ORIGINAL Pre.owner.
The old Pre and old Fact/DocumentedFacts/Post/JoinStatements bytes are unchanged.

PV_THR2_LibrarySemantics_ThreadNew213.Fact is ONE new named thread16 fact,
only the returned-success old SOURCE-cell footprint projection. Original
handler satisfaction remains explicit/Recount14. CString reserve/pushNUL/
into_boxed_slice, fresh Thread allocation, backend effects, all worlds/events
and nonsuccess replies are retained. No world/store identity chosen. Its
PV_FN_THREAD_f213.contract_frame implies literal W1 through implies_W1.
Pinned std bodies/hashes + N95807 opacity/signature inventory in session19-source.

NameEntryValidity.name_lift proves the existing withWorld lift frames OWNER
buffer ownership on every answer, WITHOUT a new handler hypothesis. The
NameOwnedTo34 companion carries this same view, original name, Scope and exact
store/geometry through295/452/source34. ThreadNewFromEntry.from_entry then
instantiates the strengthened213 at the ACTUAL issued args, derives Scope4's
frame and the typed Thread in local10, and concludes ScopeHooks.ThreadCut x35.
ScopeJoin5.to92 consumes ScopeHooks.to92 BY NAME with both hook arms and the
existing literal CLOSED124/126 Scope suffix, no callee-body replay.

Exact to92 hypotheses: R,x,ScopeJoin5.Entry R x,LibraryFacts.Facts x,
ScopeEntryValidity.SourceControl x.K,ScopeHookFrame.SourceValues (base x),
ScopeUnsafeCell.Law x,Selected295.Law x,ThreadNewFromEntry.Law R x.
Full signature and all dependency definitions are in the committed source.

These are D877 local certificates, NOT complete original-machine satisfaction.
Thread22 full carrier/control/reached resolver+handler agreement and original
transport using RunAgreement.prefix_identity BY NAME remain OPEN. SourceValues
is a partial carrier facet. Eventual row Pre must also carry EXACT thread25
numbering, with before/after and old implication; reuse slice LiveNumbering
initial/push/waiting_mono/stack_mono/caller_older BY NAME. Thread21/21' bridged
14756/allBridged obligations remain in later joins. No T/endpoint addition.

## Audited join6 helpers

PV_FN_THREAD_f361CallbackOwner.resource_registry/finish_registry/owner:
all allocator answers, actual named newAt and issued-counter OWNER invariant.
PV_FN_THREAD_f361CallbackProgress.step/progress/returned_pointer:
one13923 D877 summary on complete issued store, exact caller geometry and
world/events, frozen failures and pending waiting; returned pointer DERIVED
from actual allocation's source-minted backing. NO chosen receiver/shape or
allocation-success premise. Need caller composition from92, then443/casts/458.
No interface may equate nextActivation (or whole stores including it) with
expanded callee execution (thread27). Carry required cells/facts and numbering.

## Validation / IDs / host

Focused48900..48918 SPENT:12 accepted/7 failed. Every exact source archived
compressed + SHA in session19-sources; failed drafts are evidence only.
All passing focused steps committed; no uncompiled Lean draft remains.
NEXT Lean48919 (authorized through48999). Launcher diff ONLY adds489xx range.
Raw45900 RETIRED: basename collision with existing deployment verifier-write
artifacts at preflight, no submission/scope/Lean. Collision inventory retained.
Waited>=180s, fresh turn, strict raw45901 PASSED55/55 roots in12 modules;
zero unresolved; standard axioms;6 root-only summary differences reconciled
by UNCHANGED constructor-summary UNION; zero augmented mismatch.
Exit0 wall1:41.05 peak6741792KiB swap0, exact revision/dependency hashes and
summary/raw receipts committed. NEXT raw45902 (through45909). Walker/edges/
private-name resolver and constructor union unchanged. No frozen manifest
replay while full361 open, no unchanged regression.

Checker pinned research86370a2c585bdd45f2a63932ca0244602b57061d:
baseline0/candidate0 errors; thread64 CLOSED/8 PARTIAL/10 OPEN;
slice32/1/10,total96/125. No W3 closure credit. Exact checker inputs committed.

HOST ONLY ssh dombarker@100.108.41.90 OWN directory
/home/dombarker/project-offloads/codex-pv-w3-20261108. D931: never write/delete
other jobs/caches. Before EACH ID run remote
/home/dombarker/streamb-slots/turn.sh as its OWN ssh command, wait exit0, then
python3 tools/pv-w3-20261108/compile.py ID MODULE [--audit]. No locks/slot.sh.
Caps6G/8G/Swap0/Tasks64,Lean-M7000; never change cap/walker/provider/admission.
Refused ID spent, cooldown>=180s,nextID. /proc warnings from turn exited0.
No active scope. No local Lean, cold dependency build, implementation/ledger/
closure/endpoint/T edit, key cleanup, push or merge. All artifacts<20MB.
