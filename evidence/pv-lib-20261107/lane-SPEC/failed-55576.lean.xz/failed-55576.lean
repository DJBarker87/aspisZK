import PV_LIB_SPEC_TlsAt85
set_option autoImplicit false
noncomputable section
namespace PV_LIB_SPEC_FixedNativeGap17
open PV_STX_Machine PV_STX2_Syntax PV_STX2_Store PV_STX2_SliceMachine
open PV_EVHB_OwnerMachine PV_LIB_SPEC_D984 PV_LIB_SPEC_Frozen
open PV_LIB_SPEC_Tls18Bound16 (request)

/-- The fixed historical runtime forwards the request, but does not install
its context-bound source/TLS result adapter. Check the actual original84 poll,
not a fresh local source fixture. -/
theorem fixed_answer :
    (runtime PV_LIB_SPEC_ReachedEnvironment14.parameters).native (request 10)
      PV_LIB_SPEC_Entry14.state =
      ⟨.returned (.ok .null),PV_LIB_SPEC_Entry14.state,[]⟩ := by
  rfl

/-- The operational adapter computes false from source0/local20 and physical
65520, on exactly that same original poll and world. -/
theorem bound_answer (stack : PV_LIB_SPEC_PhysicalStack12.Frame) :
    PV_LIB_SPEC_ReachedNative14.answer (PV_LIB_SPEC_TlsNative15.cut stack)
      PV_LIB_SPEC_ReachedEnvironment14.parameters PV_LIB_SPEC_TlsAt84.config
      (request 10) PV_LIB_SPEC_Entry14.state =
      some ⟨.returned (.ok (.boolean false)),PV_LIB_SPEC_Entry14.state,[]⟩ := by
  exact PV_LIB_SPEC_Tls18Bound16.answer stack
    PV_LIB_SPEC_ReachedEnvironment14.parameters.resources
    PV_LIB_SPEC_TlsAt84.config PV_LIB_SPEC_Entry14.state 10
    (PV_LIB_SPEC_Tls18Reached16.active _)

/-- SPEC-C14: the trigger environment is not already a full native binding
for the fixed eighteen-contract runtime. A global identity transport would
have to identify these unequal full replies at an actually reached poll.
This is a failed local transport candidate, NOT a contradiction of Witness. -/
theorem no_reply_identity (stack : PV_LIB_SPEC_PhysicalStack12.Frame) :
    PV_LIB_SPEC_ReachedNative14.answer (PV_LIB_SPEC_TlsNative15.cut stack)
      PV_LIB_SPEC_ReachedEnvironment14.parameters PV_LIB_SPEC_TlsAt84.config
      (request 10) PV_LIB_SPEC_Entry14.state ≠
      some ((runtime PV_LIB_SPEC_ReachedEnvironment14.parameters).native
        (request 10) PV_LIB_SPEC_Entry14.state) := by
  rw [bound_answer,fixed_answer]
  intro equal
  cases equal

#print axioms fixed_answer
#print axioms bound_answer
#print axioms no_reply_identity
end PV_LIB_SPEC_FixedNativeGap17
