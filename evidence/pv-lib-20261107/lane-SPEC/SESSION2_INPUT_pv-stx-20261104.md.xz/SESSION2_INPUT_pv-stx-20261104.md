# to_vec B-y row — current state (session88)

Worktree /Users/dominic/ZK/.worktrees/pv-stx; branch codex/pv-stx-20261104.
Session base0fa9836bd1c. Resume committed HEAD. No unproved Lean draft remains.
B-y, slice9/10/11/11′, thread17/20/22/23/23′/25/26/27 and D931/D942 apply.
Conditional translator-patch acceptance remains. No inherited proved module,
Pre, MachineSpec, execution, Pending, Boundary or Post was edited.

## Full row is ABSENT; row remains PARTIAL

There is still NO theorem named PV_STX2_ToVecCallSummary. Do not confuse the
namespace, compiled specification, zero completion or audited helpers with it.
No final row hypothesis inventory, CLOSED receipt or endpoint-premise removal.
The positive and exceptional branches have NOT been integrated into the full
Post. SLICE/row-closures.json retains PARTIAL and records the new evidence.

## Checked boundary defect — correct before claiming closure

PV_STX2_ToVecCallPendingDiagnostic.actual_entry_false_pending proves, on the
row's stated MachineSpec and actual entry e, that an always-pending native
fallback makes the current Pending predicate hold at execution prefix11.
But execution11 is EXACTLY the push into the emitted f31 BODY from f21/s581;
the new active frame has waiting=none. No native reply is consumed there.
actual_f31_push consumes ToVecCallDispatch.source1 BY NAME. entry10 derives
the real source request from f21 entry, with actual captures, Layout global,
registration, store/world/events and arbitrary lower context.
ignored_answer_counts_as_pending exposes the missing dispatch test generically.
not_first170 consequently refutes firstness at170 for that backend, including
when e.length=0 and the separately proved genuine completion is at170.

This is a SPECIFICATION-FIDELITY finding. It does NOT prove the entire existing
Post is false: that Post can instead stop TOO EARLY at the ignored answer.
Do not exploit this to write a CLOSED receipt. It is not an f31/provider or
thread27/from_f31 obstruction. Those results remain accepted and untouched.

The correction is explicit in session88/pending-review.md: actual Pending
must additionally require c.frame.completed=none and, for a child request,
m.programs callee=none. These are recognizer tests on the reached configuration,
NOT row hypotheses. Retain old modules; introduce the corrected boundary in a
NEW module and record old/new statements. Preserve the same supplied machine,
execution, all replies, stores, worlds and events. No success, alias, frame,
store-identity or counter-identity premise. Then finish branch assembly.

## New proved assembly facts

PV_STX2_ToVecCallSummary.corrected_numbering_step and execution_numbered lift
the existing SliceNumbering/InstalledNumbering lemmas through the corrected
zero-header interpreter on EVERY running prefix, including pending and failed
branches. execution_events supplies the exact prior-event suffix for every
prefix. These need no successful callee, handler replacement or counter identity.

zero_completion consumes session87's zero and zero_success BY NAME and supplies
ALL outcome/frame/validity/ownership clauses of Post at actual completion170,
EXCEPT firstness. The OwnerWellFormed counter bound is derived from Numbered at
that actual completion; no across-callee counter equality was assumed.
first_boundary selects a least witness for the EXISTING Boundary predicate;
it does not establish that predicate's adequacy. zero_boundary proves the
actual own completion. The failed zero_first_boundary draft is retained only
as failed-source evidence; it is NOT in any Lean module or audited root list.

Session87's reference_usize/entry/noOverflow/byteSize/column_pre and
copy_from_f31 remain unchanged. Pre still covers every source7 column with
reference-valid registered ownership and live numbering. Overflow is excluded
from Pre by noOverflow, not assumed. copy_from_f31 still instantiates W5's
literal full copy Post through CallerReady.closed/ProviderContext.instantiate.

## Next concrete deliverable

Correct actual-pending recognition in a NEW statement module, then assemble
PV_STX2_ToVecCallSummary from the retained positive source294 own completion /
source295 evidence and ownership/byte/header/caller frames, signed-size
rejection, zero, allocation fault/null/pending/fail/div and copy exceptions.
Reuse named branch results, not a whole-run re-proof. Consume copy_from_f31;
record f31/f32/f33 BODY and W5 copy contract instantiations at actual arguments.
Prove firstness with respect to the corrected boundary, and every frame at that
chosen prefix. No CLOSED credit before the full theorem and its fresh audit.

## Validation and evidence

Accepted source freeze ae9989240a657cdbb6c470424391cb12c86dbe07.
Five new compiled modules, twelve theorem roots; exact sources/signatures and
printer output in evidence/pv-stx-20261104/SLICE/session88/.
Focused IDs48252–48265 SPENT: 12 compiler launches, five passes, seven failures;
48263/48264 were admission refusals BEFORE Lean, followed by full180s cooldowns
and NEXT IDs. Passes48253/48254/48257/48262/48265 each immediately committed.
Seven exact failed source inputs are hash-verified in session88/failed-sources/.
Failures were proof elaboration/rewriting, not memory pressure; no raised limits
or unchanged failed reruns. Working source was compiled before each passing
commit; receipts retain compile-parent revisions and byte-verified source freeze.

ONE fresh STRICT raw audit45835 PASSED all12 roots: zero unresolved constants,
zero raw/collectAxioms disagreements; only propext, Classical.choice, Quot.sound.
Exit0; wall0:09.87; peak6718008KiB; swaps0; sourceae9989240a6.
Unchanged hard-unresolved walker/driver/checker. Reachability graphs/checksums:
SLICE/raw45835/. This is NOT an audit of the absent full row theorem.
No final manifest replay or privacy headline is claimed.

## IDs and host discipline

NEXT Lean48266–48299; NEXT raw45836–45849 for genuinely new roots.
Separate D942 turn, then admission allowed:true AND exit0; no slot.sh or locks.
One scope at a time; 6G/8G/swap0/TasksMax64/Lean-M7000. Own host directory only;
pinned verified J/cache reused. No host deletion, provider write/replay,
persistent launcher/checker edit, frozen-source/trust/endpoint edit, wallet/key
action, push or merge. No scope/staging/turn helper left running.
Current-state handoff; full assembly remains unfinished with the checked
pending-recognition defect recorded explicitly, not hidden in row closure.
