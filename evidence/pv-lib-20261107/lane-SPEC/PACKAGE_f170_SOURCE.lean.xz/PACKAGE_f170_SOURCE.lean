import PV_FN_THREAD_f170_NumberedContract
set_option autoImplicit false
noncomputable section
namespace PV_FN_THREAD_f170
open PV_STX_Machine PV_STX2_Syntax PV_STX2_Store PV_STX2_SliceMachine
open PV_EVHB_OwnerMachine PV_W1_LeafBoundary PV_W1_OwnerNativeFrame PV_FN_W4_NativeFootprint

/-- Per-entry original machine specification: source substitutions may choose
getter or setter at the same emitted generic FnOnce token. These are resolver
and documented request-semantics clauses, not run/frame conclusions. -/
structure OriginalMachineSpec {E : Type} (M : PV_FN_W4_ContractEntry.Machine E)
    (base : Carrier OWNER Data) (i : Input E) : Prop where
  carrier : M.carrier = PV_FN_THREAD_f164.carrier base i.needsDrop
  initializer : ∀ b, M.programs (PV_THR2_KeyValues.castToken b).2 = none
  pureLeaves : ∀ fn, PureLeafToken fn → M.programs fn = none
  getter : i.callback = PV_THR2_F2Call.descriptors.2 →
    M.programs PV_THR2_RunTlsCallable.descriptors.1 = none
  setter : i.callback = PV_FN_W4_CallbackDispatchGap.enterCallback →
    M.programs PV_THR2_RunTlsCallable.descriptors.1 = some PV_THR2_F207.live
  replace : M.programs PV_FN_THREAD_f207.fn289 = none
  getterRequest : i.callback = PV_THR2_F2Call.descriptors.2 →
    ∀ a p w, PV_THR2_OwnUniformResourceHandler.lift M.handler
      (.child PV_THR2_RunTlsCallable.descriptors.1 a
        [i.callback,PV_FN_THREAD_f207.tuple p]) w =
      PV_THR2_OwnUniformResourceHandler.lift M.handler
        (.child PV_THR2_F2Call.descriptors.2 a [PV_STX2_TypedReferences.reference p .null]) w

/-- Missing original-machine portion, with the SAME provider Pre, Post,
source arguments and final Store. This is an explicit target, not a theorem
or documented-semantics fact and never an entry/endpoint premise. -/
def OriginalContract {E : Type} (M : PV_FN_W4_ContractEntry.Machine E)
    (base : Carrier OWNER Data) (D : Effects) : Prop :=
  ∀ i : Input E, OriginalMachineSpec M base i → PreNumbered i →
    DocumentedFacts (PV_FN_THREAD_f164.carrier base i.needsDrop) D M.handler i.nativeRegion →
    DocumentedValueFacts M.handler →
    DocumentedSourceFacts (PV_FN_THREAD_f164.carrier base i.needsDrop) M.handler →
    ∃ out finalStore, Post base D M.control M.programs M.handler i out finalStore ∧
      PV_FN_W4_ContractEntry.Post M PV_THR2_F170.live (numberedEntry i)
        [PV_STX2_TypedReferences.reference ⟨i.keyActivation,i.keyLocal,[]⟩ .null,i.callback] out finalStore

/-- Statement compatibility only. No original-machine contract is assumed
proved by this projection; it remains a named pending provider obligation. -/
theorem original_implies_numbered {E : Type} (M : PV_FN_W4_ContractEntry.Machine E)
    (base : Carrier OWNER Data) (D : Effects) (original : OriginalContract M base D)
    (i : Input E) (spec : OriginalMachineSpec M base i) (pre : PreNumbered i)
    (facts : DocumentedFacts (PV_FN_THREAD_f164.carrier base i.needsDrop) D M.handler i.nativeRegion)
    (values : DocumentedValueFacts M.handler)
    (sources : DocumentedSourceFacts (PV_FN_THREAD_f164.carrier base i.needsDrop) M.handler) :
    ∃ out t, Post base D M.control M.programs M.handler i out t := by
  obtain ⟨out,t,summary,actual⟩ := original i spec pre facts values sources
  exact ⟨out,t,summary⟩

#print axioms OriginalMachineSpec
#print axioms OriginalContract
#print axioms original_implies_numbered
end PV_FN_THREAD_f170
