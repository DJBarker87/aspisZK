import PV_FN_THREAD_f2_NumberedPush
import PV_FN_THREAD_f17OriginalStatement
set_option autoImplicit false
noncomputable section
namespace PV_FN_THREAD_f2Contract
open PV_STX2_Syntax PV_STX2_Store PV_STX2_SliceMachine PV_EVHB_OwnerMachine
open PV_FN_W4_NativeFootprint PV_FN_W4_ContractEntry

def MachineSpecWithOriginal {E : Type} (M : Machine E) (base : Carrier OWNER Data)
    (ctl : Control) (i : Input E) : Prop :=
  MachineSpec M base ctl i.needsDrop ∧
    PV_FN_THREAD_f17Contract.MachineSpecWithOriginal M base ctl (withInput i)

/-- Intended original-machine target. The earlier summary-only dependency
cannot establish a real run. This uses the provider's exact stronger target;
no callee representation or outcome interface is reconstructed by the caller.
The target is UNPROVED, with f17 explicitly pending under thread18. -/
def OriginalBodyContract {E : Type} (M : Machine E) (base : Carrier OWNER Data) (D : Effects)
    (ctl : Control) : Prop :=
  ∀ i : Input E, MachineSpecWithOriginal M base ctl i → Pre i →
    PV_FN_THREAD_f170.DocumentedFacts (PV_FN_THREAD_f164.carrier base i.needsDrop)
      D M.handler i.callEntry.nativeRegion →
    PV_FN_THREAD_f170.DocumentedValueFacts M.handler →
    PV_FN_THREAD_f170.DocumentedSourceFacts (PV_FN_THREAD_f164.carrier base i.needsDrop) M.handler →
    ∃ out finalStore, Post M i out finalStore

/-- Conditional proof target. The dependency is the provider's full BODY
contract, not the conditional theorem that would eventually prove it. -/
def ContractWithOriginal {E : Type} (M : Machine E) (base : Carrier OWNER Data) (D : Effects)
    (ctl : Control) : Prop :=
  PV_FN_THREAD_f17Contract.OriginalBodyContract M base D ctl → OriginalBodyContract M base D ctl

#print axioms MachineSpecWithOriginal
#print axioms OriginalBodyContract
#print axioms ContractWithOriginal
end PV_FN_THREAD_f2Contract
