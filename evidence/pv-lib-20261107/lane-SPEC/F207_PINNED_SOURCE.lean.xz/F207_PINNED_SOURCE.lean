import PV_THR2_Program
set_option autoImplicit false
namespace PV_THR2_F207
open PV_STX2_Syntax PV_STX2_SliceSyntax
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def node0 : Node :=
  .leaf (.storage ⟨207, 8239, .array [(.atom "body"), (.atom "statements"), (.number 0)]⟩ true 0)
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def node1 : Node :=
  .leaf (.storage ⟨207, 8240, .array [(.atom "body"), (.atom "statements"), (.number 1)]⟩ true 3)
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def node2 : Node :=
  .leaf (.bind ⟨207, 8241, .array [(.atom "body"), (.atom "statements"), (.number 2)]⟩ (.local 3) (.use (.move (.project (.local 2) (.field 0)))))
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def node3 : Node :=
  .leaf (.storage ⟨207, 8242, .array [(.atom "body"), (.atom "statements"), (.number 3)]⟩ true 4)
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def node4 : Node :=
  .leaf (.bind ⟨207, 8243, .array [(.atom "body"), (.atom "statements"), (.number 4)]⟩ (.local 4) (.reference (.project (.local 3) (.deref)) (.constant (.object [("kind", (.object [("Adt", (.array [(.null), (.array [])]))])), ("ty", (.object [("Deduplicated", (.number 646))]))]))))
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def node5 : Node :=
  .leaf (.call ⟨207, 8248, .array [(.atom "body"), (.atom "statements"), (.number 5)]⟩ (.object [("Regular", (.object [("kind", (.object [("Fun", (.object [("Regular", (.number 289))]))])), ("generics", (.object [("regions", (.array [(.object [("Body", (.number 3))])])), ("types", (.array [(.object [("Deduplicated", (.number 556))])])), ("const_generics", (.array [])), ("trait_refs", (.array []))]))]))]) [(.move (.local 4)), (.constant (.object [("kind", (.object [("Literal", (.object [("Bool", (.boolean true))]))])), ("ty", (.object [("Deduplicated", (.number 556))]))]))] (.local 0) [])
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def node6 : Node :=
  .leaf (.storage ⟨207, 8249, .array [(.atom "body"), (.atom "statements"), (.number 6)]⟩ false 4)
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def node7 : Node :=
  .leaf (.storage ⟨207, 8250, .array [(.atom "body"), (.atom "statements"), (.number 7)]⟩ false 3)
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def node8 : Node :=
  .leaf (.storage ⟨207, 8251, .array [(.atom "body"), (.atom "statements"), (.number 8)]⟩ false 2)
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def node9 : Node :=
  .leaf (.storage ⟨207, 8252, .array [(.atom "body"), (.atom "statements"), (.number 9)]⟩ false 1)
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def node10 : Node :=
  .leaf (.ret ⟨207, 8253, .array [(.atom "body"), (.atom "statements"), (.number 10)]⟩ (.local 0))
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def block11 : List Node :=
  [node0, node1, node2, node3, node4, node5, node6, node7, node8, node9, node10]
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def live : PV_STX2_SliceSyntax.Program :=
  ⟨207, .object [("opcode", (.atom "CallEntry")), ("function", (.number 207)), ("signature", (.object [("is_unsafe", (.boolean false)), ("abi", (.atom "Rust")), ("is_variadic", (.boolean false)), ("inputs", (.array [(.object [("Deduplicated", (.number 4952))]), (.object [("HashConsedValue", (.array [(.number 38969), (.object [("Adt", (.object [("id", (.atom "Tuple")), ("generics", (.object [("regions", (.array [])), ("types", (.array [(.object [("HashConsedValue", (.array [(.number 38968), (.object [("Ref", (.array [(.object [("Var", (.object [("Free", (.number 0))]))]), (.object [("Deduplicated", (.number 2383))]), (.atom "Shared")]))])]))])])), ("const_generics", (.array [])), ("trait_refs", (.array []))]))]))])]))])])), ("output", (.object [("Deduplicated", (.number 556))]))])), ("argument_count", (.number 2))], .array [(.object [("opcode", (.atom "LocalDeclaration")), ("function", (.number 207)), ("local", (.number 0)), ("role", (.atom "return")), ("declaration", (.object [("index", (.number 0)), ("name", (.null)), ("span", (.object [("data", (.object [("file_id", (.number 0)), ("beg", (.object [("line", (.number 18)), ("col", (.number 45))])), ("end", (.object [("line", (.number 18)), ("col", (.number 45))]))])), ("generated_from_span", (.null))])), ("ty", (.object [("Deduplicated", (.number 556))]))]))]), (.object [("opcode", (.atom "LocalDeclaration")), ("function", (.number 207)), ("local", (.number 1)), ("role", (.atom "argument")), ("declaration", (.object [("index", (.number 1)), ("name", (.null)), ("span", (.object [("data", (.object [("file_id", (.number 0)), ("beg", (.object [("line", (.number 18)), ("col", (.number 42))])), ("end", (.object [("line", (.number 18)), ("col", (.number 61))]))])), ("generated_from_span", (.null))])), ("ty", (.object [("Deduplicated", (.number 4952))]))]))]), (.object [("opcode", (.atom "LocalDeclaration")), ("function", (.number 207)), ("local", (.number 2)), ("role", (.atom "argument")), ("declaration", (.object [("index", (.number 2)), ("name", (.atom "tupled_args")), ("span", (.object [("data", (.object [("file_id", (.number 0)), ("beg", (.object [("line", (.number 0)), ("col", (.number 0))])), ("end", (.object [("line", (.number 0)), ("col", (.number 0))]))])), ("generated_from_span", (.null))])), ("ty", (.object [("Deduplicated", (.number 38969))]))]))]), (.object [("opcode", (.atom "LocalDeclaration")), ("function", (.number 207)), ("local", (.number 3)), ("role", (.atom "temporary")), ("declaration", (.object [("index", (.number 3)), ("name", (.atom "a")), ("span", (.object [("data", (.object [("file_id", (.number 0)), ("beg", (.object [("line", (.number 18)), ("col", (.number 43))])), ("end", (.object [("line", (.number 18)), ("col", (.number 44))]))])), ("generated_from_span", (.null))])), ("ty", (.object [("HashConsedValue", (.array [(.number 10197), (.object [("Ref", (.array [(.object [("Body", (.number 0))]), (.object [("Deduplicated", (.number 2383))]), (.atom "Shared")]))])]))]))]))]), (.object [("opcode", (.atom "LocalDeclaration")), ("function", (.number 207)), ("local", (.number 4)), ("role", (.atom "temporary")), ("declaration", (.object [("index", (.number 4)), ("name", (.null)), ("span", (.object [("data", (.object [("file_id", (.number 0)), ("beg", (.object [("line", (.number 18)), ("col", (.number 46))])), ("end", (.object [("line", (.number 18)), ("col", (.number 47))]))])), ("generated_from_span", (.null))])), ("ty", (.object [("HashConsedValue", (.array [(.number 10198), (.object [("Ref", (.array [(.object [("Body", (.number 1))]), (.object [("Deduplicated", (.number 2383))]), (.atom "Shared")]))])]))]))]))])], block11⟩
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def cleanup0 : String := "{\"span\":{\"data\":{\"file_id\":0,\"beg\":{\"line\":18,\"col\":42},\"end\":{\"line\":18,\"col\":61}},\"generated_from_span\":null},\"statements\":[{\"opcode\":\"Native.StorageDead\",\"identity\":{\"function\":207,\"statement\":8244,\"path\":[\"body\",\"statements\",5,\"kind\",\"Call\",\"on_unwind\",\"statements\",0]},\"span\":{\"data\":{\"file_id\":0,\"beg\":{\"line\":18,\"col\":42},\"end\":{\"line\":18,\"col\":61}},\"generated_from_span\":null},\"comments_before\":[],\"native_opcode\":\"StorageDead\",\"native\":{\"StorageDead\":3}},{\"opcode\":\"Native.StorageDead\",\"identity\":{\"function\":207,\"statement\":8245,\"path\":[\"body\",\"statements\",5,\"kind\",\"Call\",\"on_unwind\",\"statements\",1]},\"span\":{\"data\":{\"file_id\":0,\"beg\":{\"line\":18,\"col\":42},\"end\":{\"line\":18,\"col\":61}},\"generated_from_span\":null},\"comments_before\":[],\"native_opcode\":\"StorageDead\",\"native\":{\"StorageDead\":2}},{\"opcode\":\"Native.StorageDead\",\"identity\":{\"function\":207,\"statement\":8246,\"path\":[\"body\",\"statements\",5,\"kind\",\"Call\",\"on_unwind\",\"statements\",2]},\"span\":{\"data\":{\"file_id\":0,\"beg\":{\"line\":18,\"col\":42},\"end\":{\"line\":18,\"col\":61}},\"generated_from_span\":null},\"comments_before\":[],\"native_opcode\":\"StorageDead\",\"native\":{\"StorageDead\":1}},{\"opcode\":\"Native.UnwindResume\",\"identity\":{\"function\":207,\"statement\":8247,\"path\":[\"body\",\"statements\",5,\"kind\",\"Call\",\"on_unwind\",\"statements\",3]},\"span\":{\"data\":{\"file_id\":0,\"beg\":{\"line\":18,\"col\":42},\"end\":{\"line\":18,\"col\":61}},\"generated_from_span\":null},\"comments_before\":[],\"native_opcode\":\"UnwindResume\",\"native\":\"UnwindResume\"}]}"
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def cleanupSite0 : Site := ⟨207, 8248, .array [(.atom "body"), (.atom "statements"), (.number 5)]⟩
/-- Conditional on owner acceptance of amended translator. Hypotheses: none.
Generated syntax only; original cleanup retained without interpreting matches. -/
def program : PV_THR2_Program.Program :=
  ⟨live, [(cleanupSite0, cleanup0)]⟩
#print axioms program
end PV_THR2_F207
