#!/bin/sh
# run-extract.sh <scratch R> <tag> : Charon (pinned cb50ff16) then Aeneas (pinned b59d5188) on refine/writers,
# each in its own capped scope (MemoryHigh 6G / MemoryMax 8G / swap 0).
set -u
R=$1; A=$2; T=/home/dombarker/project-offloads/aspis-r1-r18-tools-20261016
rm -rf $R/extract/writers-$A; cp -r $R/in/refine/writers $R/extract/writers-$A
# The copy crates are root-workspace members since the writer migration (D68.2);
# extraction builds the copy as its own workspace, as before.
printf '\n[workspace]\n' >> $R/extract/writers-$A/Cargo.toml
mkdir -p $R/extract/charon-$A $R/extract/aeneas-$A/generated
cd $R/extract/writers-$A && PATH=/home/dombarker/.cargo/bin:$PATH cargo generate-lockfile --offline
systemd-run --user --scope --quiet -p MemoryHigh=6G -p MemoryMax=8G -p MemorySwapMax=0 -p TasksMax=64 \
  --setenv=PATH=/home/dombarker/.cargo/bin:/usr/bin:/bin --setenv=RUSTUP_TOOLCHAIN=nightly-2026-06-01 \
  /usr/bin/time -v -o $R/extract/charon-$A/time.log timeout 1200 $T/charon-target/release/charon cargo \
  --preset aeneas --mir built --start-from crate::write_aux_block --start-from crate::write_path_block \
  --start-from crate::node_right_lane7 --start-from crate::merge_check --start-from crate::merge_copy \
  --dest-file $R/extract/charon-$A/writers.llbc -- --lib --release --offline > $R/extract/charon-$A/charon.log 2>&1
echo "charon exit=$?"
cd $R/extract && systemd-run --user --scope --quiet -p MemoryHigh=6G -p MemoryMax=8G -p MemorySwapMax=0 -p TasksMax=64 \
  /usr/bin/time -v -o $R/extract/aeneas-$A/time.log timeout 1200 $T/bin/aeneas -sequential -no-progress-bar \
  -abort-on-error -backend lean -namespace R0WriterCopies -dest $R/extract/aeneas-$A/generated -loops-to-rec \
  -print-unknown-externals $R/extract/charon-$A/writers.llbc > $R/extract/aeneas-$A/aeneas.log 2>&1
echo "aeneas exit=$?"
sha256sum $R/extract/writers-$A/src/lib.rs $R/extract/charon-$A/writers.llbc $R/extract/aeneas-$A/generated/Writers.lean $T/charon-target/release/charon $T/bin/aeneas
grep -hE "Elapsed|Maximum res|Swaps|Exit" $R/extract/charon-$A/time.log $R/extract/aeneas-$A/time.log
