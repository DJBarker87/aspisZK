# Candidate composition loop slice and proof adapter (draft)

This is an uncompiled source-only preparation. `CompositionPartsLoopSlice.lean` copies the two pinned candidate-generated `partial_fixpoint` declaration blocks verbatim and defines them in the original `AspisR1SelectedMaskProbe` namespace with their original fully qualified names. It imports the active Lean4.32 checked-mask `Types` and `Funs` modules for shared Aeneas field/iterator types; those support Funs do not contain either composition loop declaration. Their hashes are the active pins 4aa955ab… and adc179f8… (not the earlier attempt-b raw source copies).

`CompositionPartsLoopAdapter.lean` is separate. It states the width-24 and width-4 reverse-loop refinement contracts against the existing symbolic Horner model, retaining canonical input/coefficient, prepared multiplier, iterator-start/end, and width-bound premises. The recursion proofs use each actual generated function's `.eq_def` equation. They do not use `.body`, `.cont`, or `.done` partial-fixpoint APIs. No Lean run has been performed.

`verify_slices.py` checks exact declaration bytes against the candidate Funs source, stripping only surrounding whitespace. It does not rename identifiers or normalize internal whitespace. `slice-check.json` records the passing source-retention check.

The Rust source is an isolated modified candidate, not current production. This draft proves no production-source correspondence, enclosing `composition_parts` theorem, terminal acceptance, or security conclusion.
