# Selected claim source slice kit

This kit separates the pinned generated declarations from their proof adapter. `source/SelectedClaimSlice.lean` contains four exact generated blocks from G output: three Funs blocks and the closure type alias block from Types. G Funs SHA is `8a612e11ee96c7a5a909c40bc09ef1f99e4e515b2b129f64059b5c033aa426fb`; G Types SHA is `0055593e96268d6451fa5750684ed54909f8652fbe9284f03b0d321834dac473`. The generator records each exact block hash.

The module imports the existing selected-mask Funs and Types rather than G's full Types file. Their pinned source snapshots are included under `inputs/old-selected-mask/`. The old Funs already defines `state_only_hiding.STATE_ONLY_HIDING_MASK_ONLY_C1_COLUMNS`; the generator's overlap scan confirms that the only overlap is that reused symbol. The closure alias, C1 and selected-width constants, `selected_claim`, H1/G constants, and flat `call_mut` declaration do not exist in the pinned old Funs/Types. G Types is not imported, avoiding its unrelated generated declarations.

`adapter/SelectedClaimProofs.lean` contains proof-side lemmas only. It establishes checked index arithmetic and canonicality inherited from the supplied selected arrays, reusing `ExtractedMaskHornerStep.array_index_usize_ok`. The flat closure reader divides and reduces by 28, so it selects columns 0 through 27 of each 29-cell row; D at column 28 is outside the 84-element selected array. H1 and G select columns 26 and 27. The proofs retain explicit fixed-array length bounds.

The adapter is an uncompiled draft. No source-refinement theorem, `from_fn`/`map` refinement, complete terminal theorem, acceptance conclusion, or caller canonicality derivation is claimed.

Regenerate and verify the source slice with:

```sh
python3 /tmp/selected-claim-slice-kit-20261016/generate.py
```
