# Stable-capture callback audit

The generic helper proof is in `proofs/ArrayFromFnCopyStable.lean`. Its callback premise is explicit: every in-range `call_mut f i` must return `(value i.val, f)`. This proves the generated copy loop's output cells under that premise; it does not prove that any Rust callback satisfies it.

## Exact generated helper

Input: `/tmp/fromfn-copy-indexed-20261016/output/generated/AspisR1SelectedMaskProbe/Funs.lean`, SHA-256 `76abaf4cdd807726983f944b9e4710044f49e0a8a006ea1bdfd553fb00e3cc5c`.

The extracted byte range `[35079, 36144)` (1,065 bytes; SHA-256 `837e1a8082584d7aa0c340d897e9d6dce1812b510eb696400179e3cc03a2b506`) contains exactly `array_from_fn_copy_loop` and `array_from_fn_copy`. The generated slice is `source/ArrayFromFnCopySlice.lean`, SHA-256 `9b861100afa866571736b4e4e2e37a39b4dd86e9a34d8b9589c0ae2d8b15c652`; only the import/header/namespace framing was adapted.

## Call sites inspected

The following 18 `FnMut.call_mut` dictionaries occur at the `array_from_fn_copy` call sites in the pinned G file. Inspection of each corresponding generated `call_mut` body shows that successful branches return the captured environment unchanged; error branches propagate failure. This is a source-body observation, not a proof of the callback equation in Lean.

| Funs line | Callback dictionary |
|---:|---|
| 1685 | `state_only_poseidon.internal_linear_lazy.closure_2.Insts.CoreOpsFunctionFnMutTupleUsizeU64` |
| 1705 | `state_only_poseidon.internal_linear_lazy.closure.Insts.CoreOpsFunctionFnMutTupleUsizeU64` |
| 1709 | `state_only_poseidon.internal_linear_lazy.closure_1.Insts.CoreOpsFunctionFnMutTupleUsizeU64` |
| 1989 | `state_only_poseidon.external_local_packed_raw.closure.closure.Insts.CoreOpsFunctionFnMutTupleUsizeU64` |
| 2087 | `state_only_poseidon.external_local_packed_raw.closure.Insts.CoreOpsFunctionFnMutTupleUsizeArrayU644` |
| 2366 | `state_only_poseidon.external_linear_lazy.closure.closure.Insts.CoreOpsFunctionFnMutTupleUsizeU64` |
| 2502 | `state_only_poseidon.external_linear_lazy_row.closure.Insts.CoreOpsFunctionFnMutTupleUsizeU64` |
| 2554 | `state_only_poseidon.external_linear_lazy.closure_1.Insts.CoreOpsFunctionFnMutTupleUsizeU64` |
| 2573 | `state_only_poseidon.external_linear_lazy.closure.Insts.CoreOpsFunctionFnMutTupleUsizeArrayU644` |
| 2846 | `state_only_poseidon.evaluate_state_only_poseidon_oracle_projected.closure_2.Insts.CoreOpsFunctionFnMutTupleUsizeQM31` |
| 3606 | `pool_v1.pair_forest_semantic_terminal.add_preweighted.closure.Insts.CoreOpsFunctionFnMutTupleUsizeQM31` |
| 4190 | `pool_v1.pair_forest_semantic_terminal.absorption_lanes_literal.closure.Insts.CoreOpsFunctionFnMutTupleUsizeQM31` |
| 4309 | `pool_v1.pair_forest_semantic_terminal.semantic_initial_and_absorption.closure.Insts.CoreOpsFunctionFnMutTupleUsizeQM31` |
| 6370 | `pool_v1.pair_forest_semantic_terminal.composition_parts.closure_1.Insts.CoreOpsFunctionFnMutTupleUsizeQM31` |
| 6374 | `pool_v1.pair_forest_semantic_terminal.composition_parts.closure_2.Insts.CoreOpsFunctionFnMutTupleUsizeQM31` |
| 6378 | `pool_v1.pair_forest_semantic_terminal.composition_parts.closure_3.Insts.CoreOpsFunctionFnMutTupleUsizeQM31` |
| 6382 | `pool_v1.pair_forest_semantic_terminal.composition_parts.closure_4.Insts.CoreOpsFunctionFnMutTupleUsizeQM31` |
| 6538 | `pool_v1.pair_forest_semantic_terminal.r0.Public.terminal_qm31.closure.Insts.CoreOpsFunctionFnMutTupleUsizeQM31` |

The stable-capture theorem is generic in the array length and element/capture types. Its application still requires a separate exact proof for each dictionary that its bounds, arithmetic, reads, and branch conditions produce the stated result and return the same capture. In particular, this audit does not establish an acceptance-path refinement or prove the helper’s behavior for these 18 callbacks.
