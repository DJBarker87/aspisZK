#!/usr/bin/env python3
"""Extract exact Clone/Copy and FnOnce/FnMut dictionaries for selected gather."""
from pathlib import Path
import hashlib, json
SRC = Path('/tmp/fromfn-copy-indexed-20261016/output/generated/AspisR1SelectedMaskProbe/Funs.lean')
EXPECT = '76abaf4cdd807726983f944b9e4710044f49e0a8a006ea1bdfd553fb00e3cc5c'
raw = SRC.read_bytes()
sha = hashlib.sha256(raw).hexdigest()
assert sha == EXPECT, (sha, EXPECT)
text = raw.decode()
lines = text.splitlines(keepends=True)
spans = [('QM31 Clone/Copy dictionary definitions', 247, 266),
         ('terminal closure FnOnce/FnMut dictionaries', 972, 1009)]
blocks=[]
for name, lo, hi in spans:
    blocks.append((name, ''.join(lines[lo-1:hi])))
header = '''-- Exact declaration slice from the pinned combined from_fn candidate Funs.lean.
-- The source blocks are byte-exact; only imports and namespace framing are adapted.
import Aeneas.Std
import AspisR1SelectedMaskProbe.Types
import AspisR1SelectedMaskProbe.Funs
import SelectedClaimSlice
open Aeneas Aeneas.Std Result ControlFlow Error
set_option linter.dupNamespace false
set_option linter.hashCommand false
set_option linter.unusedVariables false
set_option maxHeartbeats 1000000
set_option maxRecDepth 2048
namespace AspisR1SelectedMaskProbe

'''
footer='\nend AspisR1SelectedMaskProbe\n'
source=header+''.join(block for _,block in blocks)+footer
out=Path(__file__).parent/'source'/'SelectedClaimGatherSlice.lean'
out.write_text(source)
manifest={
 'kind':'exact-generated-source-slice',
 'source_path':str(SRC), 'source_sha256':sha, 'expected_source_sha256':EXPECT,
 'blocks':[{'name':name,'source_lines':[spans[i][1],spans[i][2]],'sha256':hashlib.sha256(block.encode()).hexdigest(),'byte_exact':True} for i,(name,block) in enumerate(blocks)],
 'generated_path':str(out), 'generated_sha256':hashlib.sha256(source.encode()).hexdigest(),
 'adaptations':['header/import/namespace framing only'],
 'imports':{'SelectedClaimSlice':'selected claim closure alias and call_mut body; direct import required for the dictionary reference'},
 'scope':'Provides exact Clone/Copy and FnOnce/FnMut dictionaries used by the selected gather expression. Does not include the parent terminal_qm31 wrapper.'
}
(Path(__file__).parent/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps(manifest,indent=2))
