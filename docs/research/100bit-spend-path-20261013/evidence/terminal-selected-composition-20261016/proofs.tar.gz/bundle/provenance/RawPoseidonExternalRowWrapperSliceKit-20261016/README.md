# Exact external linear row wrapper slice

This kit extracts only the `state_only_poseidon.external_linear_lazy_row` wrapper from the from_fn-copy candidate generated Funs.lean. Its declaration bytes are unchanged; import/framing lines are added around it. The wrapper calls `array_from_fn_copy` with the exact row FnMut instance, then passes the returned U64 array to `extension_from_raw_limbs`.

`RowCallbackSlice` supplies the closure type and FnMut/FnOnce declarations; it is not duplicated here. The other imports provide the generated copy helper and extension converter. This is a source slice and import-pin record only; it has not been compiled and makes no whole-permutation or terminal claim.

See `manifest.json` for full source/output hashes and byte offsets.
