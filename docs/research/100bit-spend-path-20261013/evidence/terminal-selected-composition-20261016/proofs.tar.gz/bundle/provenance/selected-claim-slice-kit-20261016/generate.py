#!/usr/bin/env python3
"""Deterministically extract exact named blocks from pinned G output."""
from pathlib import Path
import hashlib, json, re
ROOT = Path('/Users/dominic/ZK/.worktrees/100bit-spend-path')
gbase = ROOT / 'docs/research/100bit-spend-path-20261013/evidence/terminal-qm31-extraction-20261016/attempt-g-name-adapt/output/generated/AspisR1SelectedMaskProbe'
funsp = gbase / 'Funs.lean'
typesp = gbase / 'Types.lean'
oldbase = Path('/tmp/selected-claim-slice-kit-20261016/inputs/old-selected-mask')
oldfuns, oldtypes = oldbase/'Funs.lean', oldbase/'Types.lean'
g_funs_expected = '8a612e11ee96c7a5a909c40bc09ef1f99e4e515b2b129f64059b5c033aa426fb'
g_types_expected = '0055593e96268d6451fa5750684ed54909f8652fbe9284f03b0d321834dac473'
old_funs_expected = '4aa955ab74e6db926d02bdbee7dd9cdf5f755b019311dd3c67599bd8d97aa395'
old_types_expected = 'adc179f8f9627b346f86dd8655698bd0f820d5b36681ab213fa5d932e0ddd538'
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for p, want in [(funsp,g_funs_expected),(typesp,g_types_expected),(oldfuns,old_funs_expected),(oldtypes,old_types_expected)]:
    assert sha(p) == want, (p,sha(p),want)
# Imported old source already owns the mask-column count; make sure new blocks do not redeclare any old symbol.
old_funs_text, old_types_text = oldfuns.read_text(), oldtypes.read_text()
old_overlap = {
 'state_only_hiding.STATE_ONLY_HIDING_MASK_ONLY_C1_COLUMNS': bool(re.search(r'(?m)^def state_only_hiding\.STATE_ONLY_HIDING_MASK_ONLY_C1_COLUMNS\b',old_funs_text)),
 'POOL_V1_PAIR_FOREST_TERMINAL_C1_COLUMNS_V1': bool(re.search(r'(?m)^def\s+pool_v1\.pair_forest_semantic_terminal\.POOL_V1_PAIR_FOREST_TERMINAL_C1_COLUMNS_V1\b',old_funs_text)),
 'POOL_V1_PAIR_FOREST_SELECTED_TERMINAL_COLUMNS_V1': bool(re.search(r'(?m)^def\s+pool_v1\.pair_forest_semantic_terminal\.POOL_V1_PAIR_FOREST_SELECTED_TERMINAL_COLUMNS_V1\b',old_funs_text)),
 'selected_claim': bool(re.search(r'(?m)^def\s+pool_v1\.pair_forest_semantic_terminal\.selected_claim\b',old_funs_text)),
 'SELECTED_H1_COLUMN': bool(re.search(r'(?m)^def\s+pool_v1\.pair_forest_semantic_terminal\.SELECTED_H1_COLUMN\b',old_funs_text)),
 'SELECTED_G_COLUMN': bool(re.search(r'(?m)^def\s+pool_v1\.pair_forest_semantic_terminal\.SELECTED_G_COLUMN\b',old_funs_text)),
 'terminal_qm31.closure': bool(re.search(r'(?m)^def\s+pool_v1\.pair_forest_semantic_terminal\.r0\.Public\.terminal_qm31\.closure\b',old_types_text)),
}
assert old_overlap == {'state_only_hiding.STATE_ONLY_HIDING_MASK_ONLY_C1_COLUMNS': True,
 'POOL_V1_PAIR_FOREST_TERMINAL_C1_COLUMNS_V1': False,
 'POOL_V1_PAIR_FOREST_SELECTED_TERMINAL_COLUMNS_V1': False,
 'selected_claim': False, 'SELECTED_H1_COLUMN': False, 'SELECTED_G_COLUMN': False,
 'terminal_qm31.closure': False}, old_overlap
# 1-based inclusive spans, pinned to exact G output hashes above.
blocks = [
 ('terminal_qm31.closure type alias', typesp, 115, 119),
 ('terminal_qm31.closure.Insts.CoreOpsFunctionFnMutTupleUsizeQM31.call_mut', funsp, 968, 981),
 ('POOL_V1_PAIR_FOREST_TERMINAL_C1_COLUMNS_V1 + POOL_V1_PAIR_FOREST_SELECTED_TERMINAL_COLUMNS_V1 + selected_claim', funsp, 2857, 2889),
 ('SELECTED_H1_COLUMN + SELECTED_G_COLUMN', funsp, 4614, 4628),
]
def getspan(path, lo, hi):
    lines=path.read_text().splitlines(keepends=True)
    return ''.join(lines[lo-1:hi])
header='''-- Generated source slice: declarations copied byte-for-byte from pinned G blocks.\nimport Aeneas.Std\nimport AspisR1SelectedMaskProbe.Types\nimport AspisR1SelectedMaskProbe.Funs\nopen Aeneas Aeneas.Std Result ControlFlow Error\nset_option linter.dupNamespace false\nset_option linter.hashCommand false\nset_option linter.unusedVariables false\nset_option maxHeartbeats 1000000\nset_option maxRecDepth 2048\nnamespace AspisR1SelectedMaskProbe\n\n'''
# Closure alias must precede its call_mut use. It is included verbatim from G Types;
# imported old Types has only six declarations and does not define this alias.
chunks=[getspan(p,l,h) for _,p,l,h in blocks]
footer='\nend AspisR1SelectedMaskProbe\n'
source=''.join([header,*chunks,footer])
out=Path('/tmp/selected-claim-slice-kit-20261016/source/SelectedClaimSlice.lean')
out.write_text(source)
adapter=Path('/tmp/selected-claim-slice-kit-20261016/adapter/SelectedClaimProofs.lean')
manifest={
 'kind':'exact-generated-source-slice', 'generator':'generate.py',
 'generator_sha256':hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
 'generated_inputs':{
  'G_Funs':{'path':str(funsp),'sha256':sha(funsp),'expected_sha256':g_funs_expected},
  'G_Types':{'path':str(typesp),'sha256':sha(typesp),'expected_sha256':g_types_expected,'used_for':'one exact closure alias declaration only'},
  'old_selected_mask_Funs':{'path':str(oldfuns),'sha256':sha(oldfuns),'expected_sha256':old_funs_expected,'copied_to':'inputs/old-selected-mask/Funs.lean'},
  'old_selected_mask_Types':{'path':str(oldtypes),'sha256':sha(oldtypes),'expected_sha256':old_types_expected,'copied_to':'inputs/old-selected-mask/Types.lean'}},
 'old_overlap_scan':old_overlap,
 'blocks':[{'name':n,'input':p.name,'lines':[l,h],'sha256':hashlib.sha256(getspan(p,l,h).encode()).hexdigest(),'byte_exact':True} for n,p,l,h in blocks],
 'generated_output':{'path':'source/SelectedClaimSlice.lean','sha256':hashlib.sha256(source.encode()).hexdigest()},
 'proof_adapter':{'path':'adapter/SelectedClaimProofs.lean','sha256':hashlib.sha256(adapter.read_bytes()).hexdigest(),'not_compiled':True},
 'proof_dependencies':{'ExtractedMaskReducerOps':'docs/research/100bit-spend-path-20261013/lean/ExtractedMaskReducerOps.lean','ExtractedMaskTowerAdd':'docs/research/100bit-spend-path-20261013/lean/ExtractedMaskTowerAdd.lean','ExtractedMaskHornerStep.array_index_usize_ok':'docs/research/100bit-spend-path-20261013/lean/ExtractedMaskHornerStep.lean'},
 'framing_only':{'header':header,'footer':footer,'noncomputable_section':'omitted; these copied blocks do not require noncomputable declarations'},
 'scope_note':'The selected-claim closure alias and three Funs blocks are copied byte-exactly. Imported old Funs supplies the existing mask-column constant; old Types/Funs are pinned and G Types is never imported.'}
Path('/tmp/selected-claim-slice-kit-20261016/manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'output':manifest['generated_output'],'blocks':manifest['blocks'],'old_overlap_scan':old_overlap},indent=2))
