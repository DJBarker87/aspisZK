#!/usr/bin/env python3
"""Extract the exact Aeneas declarations for array_from_fn_copy and its loop."""
from pathlib import Path
import hashlib, json

SRC = Path('/private/tmp/fromfn-copy-indexed-20261016/output/generated/AspisR1SelectedMaskProbe/Funs.lean')
OUT = Path(__file__).parent / 'source' / 'ArrayFromFnCopySlice.lean'
EXPECT = '76abaf4cdd807726983f944b9e4710044f49e0a8a006ea1bdfd553fb00e3cc5c'
raw = SRC.read_bytes()
sha = hashlib.sha256(raw).hexdigest()
s = raw.decode('utf-8')
if sha != EXPECT:
    raise SystemExit(f'pinned combined from_fn candidate Funs SHA mismatch: {sha}')
start_marker = '/-- [aspis_r1_mask_extraction_probe::array_from_fn_copy]: loop 0:'
start_char = s.index(start_marker)
wrapper_marker = '  array_from_fn_copy_loop coreopsfunctionFnMutT2TupleUsizeTInst f out 0#usize\n'
end_body_char = s.index(wrapper_marker, start_char) + len(wrapper_marker)
end_char = s.index('\n/-- ', end_body_char)
start = len(s[:start_char].encode('utf-8'))
end = len(s[:end_char].encode('utf-8'))
block = raw[start:end].decode('utf-8')
if block.count('def array_from_fn_copy_loop') != 1 or block.count('def array_from_fn_copy\n') != 1:
    raise SystemExit('expected exactly the loop and wrapper declarations')
if 'partial_fixpoint' not in block:
    raise SystemExit('missing loop partial_fixpoint marker')
header = '''-- Generated exact declaration slice from the pinned combined from_fn candidate Funs.lean; only header/framing is adapted.\nimport Aeneas.Std\nimport Aeneas.Tactic.RustAttributes\nopen Aeneas Aeneas.Std Result ControlFlow Error\nset_option linter.dupNamespace false\nset_option linter.hashCommand false\nset_option linter.unusedVariables false\nset_option maxHeartbeats 1000000\nset_option maxRecDepth 2048\nnamespace AspisR1SelectedMaskProbe\n\n'''
footer = '\n\nend AspisR1SelectedMaskProbe\n'
OUT.write_text(header + block + footer)
manifest = {
  'source_path': str(SRC), 'source_sha256': sha,
  'source_start_byte': start, 'source_end_byte_exclusive': end,
  'source_span_sha256': hashlib.sha256(block.encode()).hexdigest(),
  'source_span_bytes': len(block.encode()),
  'declarations': ['array_from_fn_copy_loop', 'array_from_fn_copy'],
  'generated_path': str(OUT),
  'generated_sha256': hashlib.sha256(OUT.read_bytes()).hexdigest(),
  'adaptations': ['header/import/framing only; declaration span copied verbatim']
}
(Path(__file__).parent/'manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(manifest, indent=2))
