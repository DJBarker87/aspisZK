from pathlib import Path
import hashlib, json
root = Path('/tmp/RawPoseidonExternalRowWrapperSliceKit-20261016')
src = Path('/tmp/fromfn-copy-indexed-20261016/output/generated/AspisR1SelectedMaskProbe/Funs.lean')
b = src.read_bytes()
start_token = b'def state_only_poseidon.external_linear_lazy_row\n'
assert b.count(start_token) == 1
pos = b.index(start_token)
start = b.rfind(b'/--', 0, pos)
end = b.find(b'/--', pos)
assert start >= 0 and end > pos
block = b[start:end]
assert block.count(b'def state_only_poseidon.external_linear_lazy_row') == 1
assert b'array_from_fn_copy 4#usize core.marker.CopyU64' in block
header = b'''-- Exact generated wrapper declaration extracted from the pinned from_fn-copy candidate.\nimport Aeneas.Std\nimport Aeneas.Tactic.RustAttributes\nimport ArrayFromFnCopySlice\nimport RowCallbackSlice\nimport RawPoseidonExtensionSlice\nopen Aeneas Aeneas.Std Result ControlFlow Error\nset_option linter.dupNamespace false\nset_option linter.hashCommand false\nset_option linter.unusedVariables false\nset_option maxHeartbeats 1000000\nset_option maxRecDepth 2048\nnamespace AspisR1SelectedMaskProbe\n\n'''
footer = b'\nend AspisR1SelectedMaskProbe\n'
out = root / 'RawPoseidonExternalRowWrapperSlice.lean'
out.write_bytes(header + block + footer)
manifest = {
  'kind': 'exact generated declaration slice; import/header framing is adapted',
  'source_path': str(src),
  'source_sha256': hashlib.sha256(b).hexdigest(),
  'source_module': 'AspisR1SelectedMaskProbe.Funs',
  'declaration': 'AspisR1SelectedMaskProbe.state_only_poseidon.external_linear_lazy_row',
  'byte_range': {'start_inclusive': start, 'end_exclusive': end},
  'declaration_sha256': hashlib.sha256(block).hexdigest(),
  'output': str(out),
  'output_sha256': hashlib.sha256(out.read_bytes()).hexdigest(),
  'framing': 'imports ArrayFromFnCopySlice, RowCallbackSlice, RawPoseidonExtensionSlice; extracted declaration bytes unchanged',
  'direct_imports': {
    'ArrayFromFnCopySlice': '/tmp/fromfn-copy-helper-kit-20261016/source/ArrayFromFnCopySlice.lean',
    'RowCallbackSlice': '/tmp/aspis-r1-mask-rawposeidon-callback-bridge-20261016/import-sources/RowCallbackSlice.lean',
    'RawPoseidonExtensionSlice': '/tmp/aspis-r1-mask-extension-evidence-20261016/sources-final-bridge-recheck/RawPoseidonExtensionSlice.lean'
  }
}
(root / 'manifest.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(manifest, indent=2))
