from pathlib import Path
import hashlib,json,re
root=Path('.')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def parse_time(t):
    s=t.read_text(errors='replace') if t.exists() else ''
    out={}
    m=re.search(r'Elapsed \(wall clock\) time \(h:mm:ss or m:ss\):\s*(.+)',s)
    out['elapsed_wall_clock']=m.group(1).strip() if m else None
    for key,pat in [('max_rss_kib',r'Maximum resident set size \(kbytes\):\s*(\d+)'),('process_swaps',r'Swaps:\s*(\d+)'),('exit_status_time',r'Exit status:\s*(\d+)')]:
        m=re.search(pat,s); out[key]=int(m.group(1)) if m else None
    return out
attempts=[]
for d in sorted((root/'attempts').iterdir()):
    receipt=d/'receipt.json'
    if not receipt.exists(): continue
    r=json.loads(receipt.read_text())
    ax=json.loads((d/'axiom-reports.json').read_text()) if (d/'axiom-reports.json').exists() else []
    if isinstance(ax,dict): ax=ax.get('reports',[])
    logs=(d/'lean.log').read_text(errors='replace') if (d/'lean.log').exists() else ''
    snap=d/'sources'/Path(r['target']+'.lean')
    imports=json.loads((d/'direct-import-pins.json').read_text()) if (d/'direct-import-pins.json').exists() else []
    attempts.append({
      'attempt_dir':str(d), 'label':r.get('attempt'), 'target':r.get('target'),
      'exit_status':r.get('exit_status'), 'source_base_revision':r.get('source_base_revision'),
      'source_path_at_run':r.get('source_path'), 'source_sha256':r.get('source_sha256'),
      'snapshot_path':str(snap), 'snapshot_sha256':sha(snap) if snap.exists() else None,
      'environment_sha256':r.get('environment_sha256'), 'lean_version_pin':r.get('lean_version_pin'),
      'output_path':r.get('output_path'), 'output_sha256':r.get('output_sha256'),
      'time_metrics':parse_time(d/'time.log'), 'axiom_reports':ax, 'axiom_report_count':len(ax),
      'log_has_sorryAx':'sorryAx' in logs, 'log_has_kernel_error':'kernel type mismatch' in logs.lower(),
      'receipt_path':str(receipt), 'direct_import_pins_path':str(d/'direct-import-pins.json'),
      'direct_import_pins':imports,
    })
objects=[]
for p in sorted((root/'objects').glob('*.olean')):
    objects.append({'path':str(p),'sha256':sha(p),'bytes':p.stat().st_size})
latest={}
for a in attempts:
    if a['exit_status']==0: latest[a['target']]=a
for name,a in latest.items():
    op=root/'objects'/f'{name}.olean'
    if not op.is_file() or sha(op)!=a['output_sha256']:
        raise SystemExit(f'green target object mismatch: {name}')
imports_by_module={}
for a in attempts:
    for pin in a['direct_import_pins']:
        imports_by_module.setdefault(pin['module'],[]).append({'attempt':a['label'],'object_path':pin.get('object_path'),'object_sha256':pin.get('object_sha256'),'source_path':pin.get('source_path'),'source_sha256':pin.get('source_sha256')})
manifest={
 'bundle':'selected-claim-composition-rawposeidon-focused-20261016',
 'purpose':'Focused Lean evidence for selected 84-cell claim gather, generic stable from_fn copy, 24/4 generated composition-parts loops, and conditional 4-limb raw Poseidon row wrapper.',
 'scope_limitations':['No full Poseidon permutation theorem.','No parent terminal_qm31 wrapper/from_fn refinement.','No source acceptance, end-to-end protocol, probability, soundness, or privacy closure.','External row theorem is the exact generated wrapper component for the specified fixed-size arrays; the raw callback formula and extension words are derived under its stated inputs.'],
 'attempt_count':len(attempts), 'green_attempts':sum(a['exit_status']==0 for a in attempts),
 'failed_attempts':sum(a['exit_status']!=0 for a in attempts),
 'targets':{name:{'source_sha256':a['source_sha256'],'output_sha256':a['output_sha256'],'attempt':a['label']} for name,a in latest.items()},
 'attempts':attempts,'target_objects':objects,'direct_imports_by_module':imports_by_module,
 'environment_path':'environment.json','environment_sha256':sha(root/'environment.json'),
 'runner_path':'run-mask432-one-comment-aware.py','runner_sha256':sha(root/'run-mask432-one-comment-aware.py'),
 'executor_path':'exec-mask432-lean.py','executor_sha256':sha(root/'exec-mask432-lean.py'),
}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
