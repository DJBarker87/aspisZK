import SelectedClaimSlice
import ExtractedMaskReducerOps
import ExtractedMaskTowerAdd
import ExtractedMaskHornerStep

/-! Proof-only adapter for the pinned, byte-exact G selected-claim slice. -/
set_option autoImplicit false

namespace AspisR1SelectedMaskProbe
open Aeneas Aeneas.Std Result ControlFlow

private theorem smallUsize_bound (n : Nat) (hn : n < 84) :
    n < 2 ^ Std.UScalarTy.Usize.numBits := by
  have hb : 84 < 2 ^ Std.UScalarTy.Usize.numBits := by
    norm_num [Std.UScalarTy.Usize_numBits_eq, System.Platform.numBits]
  omega

theorem selected_width_ok :
    pool_v1.pair_forest_semantic_terminal.POOL_V1_PAIR_FOREST_SELECTED_TERMINAL_COLUMNS_V1
      = .ok 28#usize := by
  norm_num [pool_v1.pair_forest_semantic_terminal.POOL_V1_PAIR_FOREST_SELECTED_TERMINAL_COLUMNS_V1,
    pool_v1.pair_forest_semantic_terminal.POOL_V1_PAIR_FOREST_TERMINAL_C1_COLUMNS_V1,
    state_only_hiding.STATE_ONLY_HIDING_MASK_ONLY_C1_COLUMNS,
    UScalar.add, UScalar.tryMk, UScalar.tryMkOpt, UScalar.check_bounds,
    Result.ofOption, System.Platform.numBits]

theorem selected_h1_column_ok :
    pool_v1.pair_forest_semantic_terminal.SELECTED_H1_COLUMN = .ok 26#usize := by
  norm_num [pool_v1.pair_forest_semantic_terminal.SELECTED_H1_COLUMN,
    pool_v1.pair_forest_semantic_terminal.POOL_V1_PAIR_FOREST_TERMINAL_C1_COLUMNS_V1,
    state_only_hiding.STATE_ONLY_HIDING_MASK_ONLY_C1_COLUMNS,
    UScalar.add, UScalar.tryMk, UScalar.tryMkOpt, UScalar.check_bounds,
    Result.ofOption, System.Platform.numBits]

theorem selected_g_column_ok :
    pool_v1.pair_forest_semantic_terminal.SELECTED_G_COLUMN = .ok 27#usize := by
  norm_num [pool_v1.pair_forest_semantic_terminal.SELECTED_G_COLUMN,
    pool_v1.pair_forest_semantic_terminal.SELECTED_H1_COLUMN,
    pool_v1.pair_forest_semantic_terminal.POOL_V1_PAIR_FOREST_TERMINAL_C1_COLUMNS_V1,
    state_only_hiding.STATE_ONLY_HIDING_MASK_ONLY_C1_COLUMNS,
    UScalar.add, UScalar.tryMk, UScalar.tryMkOpt, UScalar.check_bounds,
    Result.ofOption, System.Platform.numBits]

/-- Every bounded source selection is a successful checked array read at the
row-major index `point*28+column`; per-cell canonicality is inherited from the
actual caller-provided array. -/
theorem selected_claim_success
    (claims : Array field.QM31 84#usize) (point column : Std.Usize)
    (hp : point.val < 3) (hc : column.val < 28)
    (hcanonical : ∀ j : Fin 84,
      AspisR1.ExtractedMaskTowerAdd.CanonicalQM
        (claims.val[j.val]'(by simpa [claims.property] using j.isLt))) :
    ∃ q : field.QM31,
      pool_v1.pair_forest_semantic_terminal.selected_claim claims point column = .ok q ∧
      q = claims.val[point.val * 28 + column.val]'(by
        have hindex : point.val * 28 + column.val < 84 := by omega
        simpa [claims.property] using hindex) ∧
      AspisR1.ExtractedMaskTowerAdd.CanonicalQM q := by
  have hindexNat : point.val * 28 + column.val < 84 := by omega
  have hmulBound : point.val * 28 < 2 ^ Std.UScalarTy.Usize.numBits :=
    smallUsize_bound _ (by omega)
  obtain ⟨i1, hi1, hi1val⟩ :=
    AspisR1.ExtractedMaskReducerOps.tryMk_success
      (ty := .Usize) (point.val * 28) hmulBound
  have hmul : point * (28#usize) = .ok i1 := by
    change UScalar.tryMk .Usize (point.val * (28#usize).val) = .ok i1
    simpa [hi1val] using hi1
  have haddBound : i1.val + column.val < 2 ^ Std.UScalarTy.Usize.numBits :=
    smallUsize_bound _ (by rw [hi1val]; exact hindexNat)
  obtain ⟨i2, hi2, hi2val⟩ :=
    AspisR1.ExtractedMaskReducerOps.tryMk_success
      (ty := .Usize) (i1.val + column.val) haddBound
  have hadd : i1 + column = .ok i2 := by
    change UScalar.tryMk .Usize (i1.val + column.val) = .ok i2
    exact hi2
  have hreadBound : i2.val < (84#usize).val := by
    rw [hi2val, hi1val]
    simpa using hindexNat
  have hread := AspisR1.ExtractedMaskHornerStep.array_index_usize_ok claims i2 hreadBound
  have hvalue : i2.val = point.val * 28 + column.val := by
    rw [hi2val, hi1val]
    rfl
  refine ⟨claims.val[i2.val]'(by simpa [claims.property] using hreadBound), ?_, ?_, ?_⟩
  · simp only [pool_v1.pair_forest_semantic_terminal.selected_claim,
      selected_width_ok, bind_tc_ok, hmul, hadd, bind_tc_ok]
    exact hread
  · simpa [hvalue]
  · exact hcanonical ⟨i2.val, hreadBound⟩


/-- Composition's H1 selection from the first 28-column row. -/
theorem selected_h1_claim_success
    (claims : Array field.QM31 84#usize)
    (hcanonical : ∀ j : Fin 84,
      AspisR1.ExtractedMaskTowerAdd.CanonicalQM
        (claims.val[j.val]'(by simpa [claims.property] using j.isLt))) :
    ∃ q,
      (do
        let i ← pool_v1.pair_forest_semantic_terminal.SELECTED_H1_COLUMN
        pool_v1.pair_forest_semantic_terminal.selected_claim claims 0#usize i) = .ok q ∧
      q = claims.val[26]'(by simpa [claims.property] using (show 26 < 84 by norm_num)) ∧
      AspisR1.ExtractedMaskTowerAdd.CanonicalQM q := by
  obtain ⟨q, hq, hval, hcan⟩ := selected_claim_success claims 0#usize 26#usize
    (by norm_num) (by norm_num) hcanonical
  refine ⟨q, ?_, hval, hcan⟩
  simpa only [selected_h1_column_ok, bind_tc_ok] using hq

theorem selected_g_claim_success
    (claims : Array field.QM31 84#usize)
    (hcanonical : ∀ j : Fin 84,
      AspisR1.ExtractedMaskTowerAdd.CanonicalQM
        (claims.val[j.val]'(by simpa [claims.property] using j.isLt))) :
    ∃ q,
      (do
        let i ← pool_v1.pair_forest_semantic_terminal.SELECTED_G_COLUMN
        pool_v1.pair_forest_semantic_terminal.selected_claim claims 0#usize i) = .ok q ∧
      q = claims.val[27]'(by simpa [claims.property] using (show 27 < 84 by norm_num)) ∧
      AspisR1.ExtractedMaskTowerAdd.CanonicalQM q := by
  obtain ⟨q, hq, hval, hcan⟩ := selected_claim_success claims 0#usize 27#usize
    (by norm_num) (by norm_num) hcanonical
  refine ⟨q, ?_, hval, hcan⟩
  simpa only [selected_g_column_ok, bind_tc_ok] using hq

/-- Exact G closure carrier: three rows of 29 field cells. The generated
flattening closure nevertheless divides and reduces by 28, deliberately
leaving each row's D cell (column 28) out of the 84-element selected array. -/
@[reducible]
def pool_v1.pair_forest_semantic_terminal.r0.Public.terminal_qm31.closure :=
  Array (Array field.QM31 29#usize) 3#usize

/-- G `terminal_qm31` closure call_mut, lines 2071–2078. -/
def pool_v1.pair_forest_semantic_terminal.r0.Public.terminal_qm31.closure.Insts.CoreOpsFunctionFnMutTupleUsizeQM31.call_mut
    (c : pool_v1.pair_forest_semantic_terminal.r0.Public.terminal_qm31.closure)
    (tupled_args : Std.Usize) :
    Result (field.QM31 × pool_v1.pair_forest_semantic_terminal.r0.Public.terminal_qm31.closure) := do
  let i ← tupled_args / 28#usize
  let i1 ← tupled_args % 28#usize
  let a ← Array.index_usize c i
  let q ← Array.index_usize a i1
  ok (q, c)

/-- Source call_mut succeeds for every flat index below 84, and returns the
row-major cell with quotient/remainder by 28. -/
theorem terminal_flat_call_mut_success
    (c : pool_v1.pair_forest_semantic_terminal.r0.Public.terminal_qm31.closure)
    (flat : Std.Usize) (hflat : flat.val < 84)
    (hcanonical : ∀ p : Fin 3, ∀ col : Fin 28,
      AspisR1.ExtractedMaskTowerAdd.CanonicalQM
        (c.val[p.val]'(by simpa [c.property] using p.isLt).val[
          col.val]'(by simpa using col.isLt))) :
    ∃ q : field.QM31,
      pool_v1.pair_forest_semantic_terminal.r0.Public.terminal_qm31.closure.Insts.CoreOpsFunctionFnMutTupleUsizeQM31.call_mut
        c flat = .ok (q, c) ∧
      let row := c.val[(flat.val / 28)]' (by
        have hquot : flat.val / 28 < 3 := by omega
        simpa [c.property] using hquot)
      q = row.val[flat.val % 28]' (by
        have hcol29 : flat.val % 28 < 29 := by omega
        simpa [row.property] using hcol29) ∧
      AspisR1.ExtractedMaskTowerAdd.CanonicalQM q := by
  have hden : (28#usize : Std.Usize).val ≠ 0 := by norm_num
  obtain ⟨row, hdiv, hdivVal⟩ := UScalar.div_spec flat hden
  obtain ⟨col, hmod, hmodVal⟩ := UScalar.rem_spec flat hden
  have hrow : row.val < 3 := by rw [hdivVal]; omega
  have hcol : col.val < 28 := by rw [hmodVal]; exact Nat.mod_lt _ (by omega)
  have hquot : flat.val / 28 < 3 := by rw [← hdivVal]; exact hrow
  have hrem : flat.val % 28 < 28 := by rw [← hmodVal]; exact hcol
  have hrowRead := AspisR1.ExtractedMaskHornerStep.array_index_usize_ok c row (by simpa [c.property] using hrow)
  let r := c.val[flat.val / 28]'(by simpa [c.property] using hquot)
  have hcolRead := AspisR1.ExtractedMaskHornerStep.array_index_usize_ok r col (by simpa [r.property] using hcol)
  refine ⟨r.val[flat.val % 28]'(by simpa [r.property] using hrem), ?_, ?_, ?_⟩
  · simp only [pool_v1.pair_forest_semantic_terminal.r0.Public.terminal_qm31.closure.Insts.CoreOpsFunctionFnMutTupleUsizeQM31.call_mut,
      hdiv, hmod, bind_tc_ok]
    rw [hrowRead, hcolRead]
  · rfl
  · exact hcanonical ⟨flat.val / 28, hquot⟩ ⟨flat.val % 28, hrem⟩

#print axioms selected_width_ok
#print axioms selected_h1_column_ok
#print axioms selected_g_column_ok
#print axioms selected_claim_success
#print axioms selected_h1_claim_success
#print axioms selected_g_claim_success
#print axioms terminal_flat_call_mut_success

end AspisR1SelectedMaskProbe
