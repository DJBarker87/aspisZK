# Selected-mask extraction input B (prepared only)

This is a separate input snapshot for attempt-b. Input-a and attempt-a are preserved unchanged. The complete 73-file production `aspis-core/src` snapshot is copied byte-for-byte from the recorded worktree revision; the compile `src/` tree has the same production module bytes plus the extraction wrapper and root declaration already documented in input-a.

This input additionally includes the original `crates/aspis-core/build.rs` byte-for-byte, both at Cargo's expected package-root `build.rs` path and in `build-script-snapshot/build.rs`. Its pinned hash is in `source-pins.json`. It generates the exact `OUT_DIR/circle_tables.rs` included by production `circle_fri.rs`. No table constants or production bodies are stubbed or rewritten.

The only Cargo manifest change relative to input-a is `[profile.release.build-override] opt-level = 3`, to optimize the bounded circle lookup-table generator. No third-party dependencies are introduced. Features remain default-off, including `r0-op-count`, `r0-r91-audit`, and `r0-e4-reference`.

This kit has not been built or extracted. The separate runner is expected to run `cargo generate-lockfile --offline`, Charon in optimized release mode with overflow checks and offline/locked/single-job settings, then Aeneas, each under the same sampled 2 GiB aggregate RSS and 300-second stage caps. Root will decide whether to run it.
