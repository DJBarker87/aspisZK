# Selected-mask extraction evidence (attempt A and attempt B)

This archive preserves both extraction attempts. Attempt A lacked Cargo `build.rs`; Charon failed because `OUT_DIR` was not defined, so the dependent generated circle-table constants were unavailable. Attempt B includes the unchanged production `build.rs` both as Cargo `build.rs` and as a separate source snapshot; their byte hashes match the pinned production file. The failed attempt remains preserved.

Attempt B completed lock generation, Charon, and Aeneas under the recorded local resource caps. The archive contains complete input sources, run scripts, commands, tool/source pins, receipts, logs, LLBC, and generated Lean Types/Funs/translation metadata. It intentionally excludes Cargo target directories and caches.

This records extraction and translation only. Generated Lean has not yet been separately compiled; no source-equivalence theorem or security conclusion is claimed. See `inventory.json` for exact hashes and pins.
