#!/usr/bin/env python3
"""Prepare/run one bounded selected-mask Charon/Aeneas attempt.

Prepared only: this file is not executed during runner setup. It refuses to
reuse an attempt, verifies source/tool pins first, and then runs Charon followed
by Aeneas into a fresh attempt directory.
"""
import ast
import hashlib
import json
import os
import shutil
import signal
import subprocess
import time
from pathlib import Path

ROOT = Path('/tmp/aspis-r1-mask-extraction-20261015')
KIT = ROOT / 'input'
ATTEMPT = ROOT / 'attempt-a'
WORKTREE = Path('/Users/dominic/ZK/.worktrees/100bit-spend-path')


def sha(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def verify_pins(kit: Path) -> dict:
    manifest = json.loads((kit / 'source-pins.json').read_text())
    for row in manifest['files']:
        path = kit / row['path']
        if not path.is_file() or path.stat().st_size != row['bytes'] or sha(path) != row['sha256']:
            raise RuntimeError(f"source pin mismatch: {row['path']}")
    for key in ('production_entrypoint', 'production_field_source', 'production_wide_exact_source', 'production_cargo_manifest'):
        row = manifest[key]
        origin = WORKTREE / row['path']
        if not origin.is_file() or sha(origin) != row['sha256']:
            raise RuntimeError(f"worktree source pin mismatch: {row['path']}")
    for source in sorted((kit / 'source-snapshot').rglob('*.rs')):
        rel = source.relative_to(kit / 'source-snapshot')
        origin = WORKTREE / 'crates/aspis-core/src' / rel
        if not origin.is_file() or sha(origin) != sha(source):
            raise RuntimeError(f"production tree mismatch: {rel}")
    current_head = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=WORKTREE, text=True).strip()
    if current_head != manifest['source_revision']:
        raise RuntimeError(f"source revision changed: expected {manifest['source_revision']}, got {current_head}")
    tool_manifest = json.loads((kit / 'tool-pins.json').read_text())
    rustc = subprocess.check_output(['rustup', 'run', tool_manifest['rust_toolchain']['name'], 'rustc', '--version', '--verbose'], text=True)
    expected_rustc = tool_manifest['rust_toolchain']['rustc']
    if expected_rustc not in rustc or tool_manifest['rust_toolchain']['host'] not in rustc:
        raise RuntimeError(f'rustc toolchain pin mismatch: expected {expected_rustc}; got {rustc}')
    for tool in tool_manifest['tools']:
        binary = Path(tool['path'])
        if not binary.is_file() or sha(binary) != tool['sha256']:
            raise RuntimeError(f"executable pin mismatch: {tool['name']} at {binary}")
    manifest['_verified_rustc_version_output'] = rustc
    return manifest


def main() -> None:
    if not KIT.is_dir():
        raise SystemExit(f'missing prepared input kit: {KIT}')
    if ATTEMPT.exists():
        raise SystemExit(f'refusing to overwrite existing attempt: {ATTEMPT}')
    pins = verify_pins(KIT)
    ATTEMPT.mkdir(parents=True)
    shutil.copytree(KIT, ATTEMPT / 'input')
    shutil.copy2(Path(__file__), ATTEMPT / 'run-extraction.py')
    copied = ATTEMPT / 'input'
    for row in pins['files']:
        if sha(copied / row['path']) != row['sha256']:
            raise RuntimeError(f"attempt input copy mismatch: {row['path']}")

    env = dict(os.environ)
    env.update({
        'RUSTUP_TOOLCHAIN': 'nightly-2026-06-01',
        'CARGO_BUILD_JOBS': '1',
        'CARGO_PROFILE_RELEASE_OPT_LEVEL': '3',
        'CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS': 'true',
        'RUSTFLAGS': '-C overflow-checks=yes',
        'CARGO_TARGET_DIR': str(ROOT / 'cargo-target'),
        'CARGO_NET_OFFLINE': 'true',
    })
    env_record = {key: env[key] for key in (
        'RUSTUP_TOOLCHAIN', 'CARGO_BUILD_JOBS', 'CARGO_PROFILE_RELEASE_OPT_LEVEL',
        'CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS', 'RUSTFLAGS', 'CARGO_TARGET_DIR',
        'CARGO_NET_OFFLINE')}
    env_record['verified_rustc_version_output'] = pins['_verified_rustc_version_output']
    (ATTEMPT / 'environment.json').write_text(json.dumps(env_record, indent=2) + '\n')
    commands = json.loads((copied / 'expected-commands.json').read_text())
    charon = list(commands['charon'])
    aeneas = list(commands['aeneas'])
    charon[charon.index('--dest-file') + 1] = str(ATTEMPT / 'output/SelectedMask.llbc')
    aeneas[aeneas.index('-dest') + 1] = str(ATTEMPT / 'output/generated')
    aeneas[-1] = str(ATTEMPT / 'output/SelectedMask.llbc')
    (ATTEMPT / 'output').mkdir()
    (ATTEMPT / 'planned-commands.json').write_text(json.dumps({'charon': charon, 'aeneas': aeneas}, indent=2) + '\n')

    def run(stage: str, command: list[str]) -> None:
        started = time.monotonic()
        peak_kib = 0
        killed = False
        with (ATTEMPT / f'{stage}.log').open('x') as log:
            proc = subprocess.Popen(
                ['/usr/bin/time', '-l', *command], cwd=copied, env=env,
                stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            while proc.poll() is None:
                rows = subprocess.check_output(['ps', '-axo', 'pid=,pgid=,rss='], text=True)
                aggregate_kib = 0
                for line in rows.splitlines():
                    cols = line.split()
                    if len(cols) == 3 and cols[1].isdigit() and int(cols[1]) == proc.pid:
                        aggregate_kib += int(cols[2])
                peak_kib = max(peak_kib, aggregate_kib)
                if aggregate_kib > 2 * 1024 * 1024 or time.monotonic() - started > 300:
                    killed = True
                    os.killpg(proc.pid, signal.SIGKILL)
                    break
                time.sleep(0.1)
            status = proc.wait()
        log_text = (ATTEMPT / f'{stage}.log').read_text(errors='replace')
        import re
        time_match = re.search(r'^\s*([0-9]+(?:\.[0-9]+)?) real\b', log_text, re.MULTILINE)
        receipt = {
            'stage': stage,
            'command': command,
            'exit_status': status,
            'wall_seconds_monotonic': round(time.monotonic() - started, 3),
            'time_real_seconds_from_usr_bin_time': float(time_match.group(1)) if time_match else None,
            'time_real_recorded': 'Parsed from /usr/bin/time -l output; raw stage log retained',
            'peak_sampled_aggregate_process_group_rss_kib': peak_kib,
            'sampled_rss_stop_threshold_kib': 2 * 1024 * 1024,
            'stage_timeout_seconds': 300,
            'killed_for_memory_or_timeout': killed,
            'source_revision': pins['source_revision'],
            'input_source_manifest_sha256': sha(copied / 'source-pins.json'),
            'runner_sha256': sha(Path(__file__)),
            'tool_pins_sha256': sha(copied / 'tool-pins.json'),
            'resource_scope': 'sampled 2 GiB aggregate process-group RSS stop; no cgroup; one Cargo job',
        }
        (ATTEMPT / f'{stage}.receipt.json').write_text(json.dumps(receipt, indent=2) + '\n')
        print(json.dumps(receipt), flush=True)
        if status != 0:
            raise SystemExit(status)

    run('lock', ['cargo', 'generate-lockfile', '--offline'])
    run('charon', charon)
    run('aeneas', aeneas)
    artifacts = {}
    for path in sorted(ATTEMPT.rglob('*')):
        if path.is_file() and path.name != 'artifact-pins.json':
            artifacts[path.relative_to(ATTEMPT).as_posix()] = sha(path)
    (ATTEMPT / 'artifact-pins.json').write_text(json.dumps(artifacts, indent=2) + '\n')


if __name__ == '__main__':
    main()
