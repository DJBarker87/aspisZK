//! Added extraction entrypoint; production call graph is unchanged.
use crate::field::QM31;

/// Calls the unchanged production selected-mask implementation.
pub fn state_only_selected_mask_value_probe(
    c1: &[QM31; crate::state_only_hiding::STATE_ONLY_HIDING_C1_COLUMNS],
    mask_only_c1: &[QM31; crate::state_only_hiding::STATE_ONLY_HIDING_MASK_ONLY_C1_COLUMNS],
    explicit_g: QM31,
    point: &[QM31; crate::state_only_hiding::STATE_ONLY_HIDING_SUMCHECK_ROUNDS],
) -> QM31 {
    crate::state_only_hiding::state_only_selected_mask_value(
        c1, mask_only_c1, explicit_g, point,
    )
}
