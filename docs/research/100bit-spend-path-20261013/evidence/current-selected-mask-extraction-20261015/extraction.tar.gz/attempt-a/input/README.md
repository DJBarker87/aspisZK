# Selected-mask extraction input (prepared only)

This standalone crate preserves the complete `crates/aspis-core/src` tree from the recorded source revision byte-for-byte in `source-snapshot/` and `src/`. The only added source is `src/extraction_probe.rs`, a free-function wrapper that calls the unchanged `state_only_hiding::state_only_selected_mask_value`. The compile scaffold `src/lib.rs` is the production crate root plus one `pub mod extraction_probe;` declaration; the exact original crate root is retained at `source-snapshot/lib.rs`.

The selected production entrypoint is `aspis_core::state_only_hiding::state_only_selected_mask_value` at source lines 647–674. Its signature consumes C1 `[QM31; 16]`, mask-only C1 `[QM31; 10]`, one `QM31` explicit mask, and a point `[QM31; 10]`, returning `QM31`. The wrapper is `aspis_r1_mask_extraction_probe::state_only_selected_mask_value_probe` with the same argument shape and delegates directly to that production function.

The standalone manifest has no third-party dependencies, and all production Cargo features are declared with defaults empty. `r0-op-count`, `r0-r91-audit`, and `r0-e4-reference` are disabled, as are the other optional audit/insecure features. The original `aspis-core/Cargo.toml` has an empty `[dependencies]`; its dev-dependencies are not included because the planned command targets only the library.

The full source tree is retained because `state_only_hiding.rs` imports transcript types, while transcript imports circle and field, and other crate modules cross-reference verifier types. No module body is stubbed. The source manifest records every retained production file and every compile-scaffold file hash, plus the exact entrypoint, field, wide-exact, wrapper, and tool pins.

No Cargo build, Charon extraction, or Aeneas translation has been run for this kit. `expected-commands.json` is a proposed command shape using the locally pinned tools recorded in `tool-pins.json`; root approval is still required before execution. The intended extracted call graph and Aeneas support remain unverified.
