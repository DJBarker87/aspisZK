from pathlib import Path
import json,subprocess,time,hashlib,os
w=Path("/home/dombarker/project-offloads/aspis-r1-r18-sampler-rank-consumers-20261016")
s=json.loads((w/"external-inputs-rank-consumers.json").read_text())
names=[n for n,v in s["modules"].items() if v["root"].startswith("rank_")]
paths=[s["modules"][n]["objects"][".olean"]["path"] for n in names]
runtime=Path(s["runtime_root"])
cmd=["/usr/bin/time","-v","-o",str(w/"object-imports.time.log"),str(runtime/"bin/lean"),"--run",str(w/"ReadObjectImports.lean"),*paths]
env=dict(os.environ);env.pop("LEAN_PATH",None);env.pop("LEAN_SRC_PATH",None)
cg=Path("/sys/fs/cgroup")/next(x.split(":",2)[2] for x in Path("/proc/self/cgroup").read_text().splitlines() if x.startswith("0::")).lstrip("/")
limits={n:(cg/n).read_text().strip() for n in ["memory.high","memory.max","memory.swap.max"]}
assert limits=={"memory.high":str(6*2**30),"memory.max":str(8*2**30),"memory.swap.max":"0"}
begin=time.monotonic()
with (w/"object-imports.jsonl").open("w") as out,(w/"object-imports.stderr.log").open("w") as err:
 p=subprocess.run(cmd,env=env,stdout=out,stderr=err,timeout=180)
receipt={"command":cmd,"exit_status":p.returncode,"wall_seconds":time.monotonic()-begin,"limits":limits,"source_sha256":hashlib.sha256((w/"ReadObjectImports.lean").read_bytes()).hexdigest(),"cgroup_memory_peak":(cg/"memory.peak").read_text().strip(),"cgroup_swap_current":(cg/"memory.swap.current").read_text().strip(),"scope":"readModuleData only; no theorem/dependency replay"}
(w/"object-imports.receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt));print((w/"object-imports.stderr.log").read_text())
if p.returncode==0:
 mapping={s["modules"][n]["objects"][".olean"]["path"]:n for n in names};diffs=[]
 for line in (w/"object-imports.jsonl").read_text().splitlines():
  d=json.loads(line);name=mapping[d["path"]];expected=s["modules"][name]["imports"]
  if d["imports"]!=expected:diffs.append({"module":name,"source_imports":expected,"object_imports":d["imports"]})
 (w/"object-imports-differences.json").write_text(json.dumps(diffs,indent=2)+"\n");print("DIFFERENCES",json.dumps(diffs))
raise SystemExit(p.returncode)
