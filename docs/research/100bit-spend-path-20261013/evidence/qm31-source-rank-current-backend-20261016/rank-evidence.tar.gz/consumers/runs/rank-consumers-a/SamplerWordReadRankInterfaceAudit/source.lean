import AspisV8R19.SamplerWordRead

#print axioms AspisV8R19.SamplerWordRead.four
