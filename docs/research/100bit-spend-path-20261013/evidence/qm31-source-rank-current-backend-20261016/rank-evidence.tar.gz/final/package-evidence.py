from pathlib import Path
import hashlib,json,tarfile
base=Path("/home/dombarker/project-offloads")
roots={"rank":base/"aspis-r1-r18-sampler-rank-20261016","consumers":base/"aspis-r1-r18-sampler-rank-consumers-20261016","final":base/"aspis-r1-r18-sampler-rank-final-20261016"}
w=roots["final"]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files=[]
for label,root in roots.items():
 for p in sorted(root.rglob("*")):
  if not p.is_file() or p.is_symlink():continue
  rel=p.relative_to(root)
  if any(x in rel.parts for x in ["import-overlay","__pycache__"]):continue
  if p.name in ["rank-evidence.tar.gz","archive-members.json","check-summary.json"]:continue
  files.append((p,str(Path(label)/rel)))
summary=[]
for label,root in roots.items():
 for rp in sorted((root/"runs").glob("*/*/receipt.json")):
  r=json.loads(rp.read_text());summary.append({"workspace":label,"receipt":str(rp.relative_to(root)),"target":r["target"],"exit_status":r["exit_status"],"wall_seconds":r["wall_seconds"],"peak_process_rss_kib":r["peak_process_rss_kib"],"sampled_cgroup_peak_bytes":r["sampled_cgroup_peak_bytes"],"process_swaps":r["process_swaps"],"cgroup_swap_current":r["cgroup_swap_current"],"source_sha256":r["key"]["source_sha256"],"axioms":r["axioms"]})
(w/"check-summary.json").write_text(json.dumps(summary,indent=2)+"\n")
files.append((w/"check-summary.json","final/check-summary.json"))
archive=w/"rank-evidence.tar.gz"
with tarfile.open(archive,"w:gz",compresslevel=6) as t:
 for p,name in files:t.add(p,arcname=name,recursive=False)
members=[]
with tarfile.open(archive,"r:gz") as t:
 for m in t:
  assert m.isfile()
  members.append({"path":m.name,"size":m.size,"sha256":hashlib.sha256(t.extractfile(m).read()).hexdigest()})
(w/"archive-members.json").write_text(json.dumps(members,indent=2)+"\n")
print(json.dumps({"archive":str(archive),"size":archive.stat().st_size,"sha256":sha(archive),"members":len(members),"checks":len(summary)},indent=2))
