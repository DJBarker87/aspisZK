#!/usr/bin/env python3
"""Reviewed 58-GiB watcher for the frozen indexed decode_k candidate Charon/Aeneas script.
Prepared for execution; invoking it starts the extraction."""
import hashlib,json,pathlib,re,subprocess,sys,time,os
G=1024**3; CAP=4608*1024**2; SAFE=58*G; BASE=45*G; DOCKER_FLOOR=24*G
ROOT=pathlib.Path('/home/dombarker/project-offloads/aspis-r1-semantic-query-final-a555-20261017/decode-k-indexed-candidate-v3-20261018')
CACHE=pathlib.Path('/home/dombarker/project-offloads/aspis-r1-semantic-query-final-a555-20261017/cargo-target')
RUNNER=pathlib.Path('/tmp/run-actual-decode-k-full-v10-a555-20261018.sh')
OUT=pathlib.Path('/tmp/actual-decode-k-full-v10-a555-20261018')
ATT=pathlib.Path('/tmp/actual-decode-k-full-v10-attempt-a555-20261018')
CHARON=pathlib.Path('/home/dombarker/project-offloads/aspis-r1-r18-tools-20261016/charon-target/release/charon')
AENEAS=pathlib.Path('/home/dombarker/project-offloads/v7-tag73-challenge-qm31-source-20260825-work/toolchain/output/aeneas-b59d5188-lean432-extended-static')
DRIVER=pathlib.Path('/home/dombarker/project-offloads/aspis-r1-r18-tools-20261016/charon-target/release/charon-driver')
UNIT='aspis-decode-k-full-v10-a555-20261018'
PINS={'runner':'92b53bf47b41417febc6afdba726421fae87c5462aae2bd7c3de4cf91fa8fcad','charon':'daad69bea1114042a2d2fbd3dfde99922b152d4f57023bf8edb83e5a6f336af8','aeneas':'4632746db1bf6c3953f2971078965a2a5a8ad6cf5f75636b46b397bc50c550b5','driver':'efdbe5b86c9f5f70c93810af08f358d4ecbaecf6f3e87517b1176689a8c28c45','wire':'47562d76a47ba602aacbbdd61c9b97c4429ba9700aa96e8ea49d3c4ccab9b444','semantic':'1e62a9512db72e2ddd83edd124c707e3c5158b35b3cf0ba60e3dcb0803525896','field':'28df5a1abee13bde4b3aa9eeceb0489bedf00531f298460954a97661f5f1baea','lock':'f93f8f524fdd707c7a3b7feade31d015c891264b6c8fbd8bff885249e19600ea','manifest':'5fafcd2572896d4ba35cb01304aa6ccde1d0b634804fedf22c3f74133cedf093'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def need(ok,msg):
 if not ok: raise SystemExit('preflight refused: '+msg)
def mem():
 d={}
 for line in pathlib.Path('/proc/meminfo').read_text().splitlines():
  k,_,v=line.partition(':')
  if k in ('MemTotal','MemAvailable'): d[k+'_bytes']=int(v.split()[0])*1024
 return d
def scopes(exclude=()):
 docker=other=0; active=[]
 for f in pathlib.Path('/sys/fs/cgroup').rglob('memory.max'):
  c=f.parent
  if not c.name.endswith('.scope') or c.name in exclude: continue
  mx=f.read_text().strip(); ev=c/'cgroup.events'
  if mx=='max' or not ev.is_file(): continue
  d=dict(x.split() for x in ev.read_text().splitlines() if len(x.split())==2)
  if d.get('populated')!='1': continue
  n=int(mx); active.append({'cgroup':str(c),'unit':c.name,'memory_max_bytes':n})
  if c.name.startswith('docker-') or 'docker' in c.name.lower(): docker+=n
  else: other+=n
 ext=BASE+max(0,docker-DOCKER_FLOOR)
 return {'docker_caps':docker,'external_reserve':ext,'other_scope_caps':other,'job_cap':CAP,'total_reserved':ext+other+CAP,'active_scopes':active}
def gate(exclude=()):
 r=scopes(exclude); m=mem()
 need(m['MemTotal_bytes']>=62*G,'MemTotal < 62 GiB')
 need(r['total_reserved']<=SAFE,'reserved scopes + job > 58 GiB')
 need(m['MemTotal_bytes']-r['total_reserved']>=4*G,'physical headroom < 4 GiB')
 need(m['MemAvailable_bytes']>=16*G if not exclude else m['MemAvailable_bytes']>=12*G,'MemAvailable below gate')
 return {**r,**m}
def cgroup():
 for f in pathlib.Path('/sys/fs/cgroup').rglob('memory.max'):
  if f.parent.name==UNIT+'.scope': return f.parent
 return None
def sample(c):
 if c is None:return {'stage':'waiting','rss_bytes':0,'pids':[],'memory_current':None,'memory_peak':None,'swap_current':None}
 rss=0; pids=[]; cmds=[]
 try: ids=map(int,(c/'cgroup.procs').read_text().split())
 except: ids=[]
 for pid in ids:
  try:
   p=pathlib.Path('/proc')/str(pid); cmd=(p/'cmdline').read_bytes().replace(b'\0',b' ').decode(errors='replace')
   vm=re.search(r'^VmRSS:\s+(\d+) kB$',(p/'status').read_text(),re.M); n=int(vm.group(1))*1024 if vm else 0
   rss+=n; cmds.append(cmd.lower()); pids.append({'pid':pid,'rss_bytes':n,'cmd':cmd[:240]})
  except: pass
 joined=' '.join(cmds); stage='controller'
 if 'aeneas' in joined: stage='aeneas'
 elif 'charon' in joined or 'cargo' in joined or 'rustc' in joined: stage='charon-cargo'
 def num(n):
  try:
   v=(c/n).read_text().strip(); return None if v=='max' else int(v)
  except: return None
 return {'stage':stage,'rss_bytes':rss,'pids':pids,'memory_current':num('memory.current'),'memory_peak':num('memory.peak'),'swap_current':num('memory.swap.current')}
def main():
 need(sha(RUNNER)==PINS['runner'],'runner hash mismatch')
 need(not OUT.exists() and not ATT.exists(),'output/attempt path already exists')
 need((CACHE/'release/deps').is_dir(),'pinned release cache unavailable')
 files={'wire':ROOT/'crates/aspis-r1-cost-probe/src/r1_wire.rs','semantic':ROOT/'crates/aspis-r1-cost-probe/src/r1_semantic.rs','field':ROOT/'crates/aspis-core/src/field.rs','lock':ROOT/'Cargo.lock','manifest':ROOT/'crates/aspis-r1-cost-probe/Cargo.toml'}
 for k,p in files.items(): need(p.is_file() and sha(p)==PINS[k],f'{k} source pin mismatch')
 tools={'charon':CHARON,'aeneas':AENEAS,'driver':DRIVER}
 for k,p in tools.items(): need(p.is_file() and sha(p)==PINS[k],f'{k} tool pin mismatch')
 pre=gate(); ATT.mkdir(mode=0o700)
 doc={'target':'crate::r1_wire::_::decode_k caller loop with actual field parser and included QM31::ZERO','source_snapshot':'aspis-r1-semantic-query-final-a555-20261017/decode-k-indexed-candidate-v3-20261018 (isolated helper candidate; production source unchanged)','source_root':str(ROOT),'cargo_target':str(CACHE),'runner':str(RUNNER),'runner_sha256':sha(RUNNER),'source_pins':{k:{'path':str(p),'sha256':sha(p)} for k,p in files.items()},'tool_pins':{k:{'path':str(p),'sha256':sha(p)} for k,p in tools.items()},'resource_gate':pre,'resource_policy':{'safe_ceiling':SAFE,'base_reserve':BASE,'launch_available_min':16*G,'watchdog_available_min':12*G,'MemTotal_min':62*G,'headroom_min':4*G,'MemoryHigh':'4G','MemoryMax':'4608M','MemorySwapMax':'0','TasksMax':128,'original_guard':50*G,'reviewed_guard':58*G}}
 (ATT/'preflight.json').write_text(json.dumps(doc,indent=2)+'\n')
 env=['/usr/bin/env',f'SOURCE_ROOT={ROOT}',f'CARGO_TARGET_DIR={CACHE}',f'OUT_DIR={OUT}','/bin/bash',str(RUNNER)]
 cmd=['systemd-run','--user','--scope','--quiet','--unit='+UNIT,'-p','MemoryHigh=4G','-p','MemoryMax=4608M','-p','MemorySwapMax=0','-p','TasksMax=128','/usr/bin/time','-v','-o',str(ATT/'time.log'),*env]
 (ATT/'command.json').write_text(json.dumps({'argv':cmd},indent=2)+'\n')
 wall0=time.monotonic(); last_poll=wall0; peaks={}; first={}; stage_seconds={}; last_seen={}; last={}; abort=None
 with (ATT/'stdout-stderr.log').open('x') as log,(ATT/'watcher.jsonl').open('x') as watch:
  p=subprocess.Popen(cmd,stdout=log,stderr=subprocess.STDOUT)
  while p.poll() is None:
   try:
    g=gate({UNIT+'.scope'}); c=cgroup(); s=sample(c); t=time.monotonic(); stage=s['stage']; dt=max(0.0,t-last_poll); last_poll=t
    e={'unix_time':time.time(),'elapsed_s':round(t-wall0,3),'stage':stage,'reserved_total':g['total_reserved'],'MemTotal':g['MemTotal_bytes'],'MemAvailable':g['MemAvailable_bytes'],'scope':str(c) if c else None,**{k:s[k] for k in ('rss_bytes','memory_current','memory_peak','swap_current')}}
    watch.write(json.dumps(e)+'\n'); watch.flush(); last=e; first.setdefault(stage,e['elapsed_s']); stage_seconds[stage]=stage_seconds.get(stage,0.0)+dt; last_seen[stage]=e['elapsed_s']
    q=peaks.setdefault(stage,{'samples':0,'rss_bytes':0,'memory_current':0,'memory_peak':0,'swap_current':0}); q['samples']+=1
    for k in ('rss_bytes','memory_current','memory_peak','swap_current'):
     if s[k] is not None:q[k]=max(q[k],s[k])
    if g['total_reserved']>SAFE: abort='reserved_caps_over_58GiB'
    elif g['MemAvailable_bytes']<12*G: abort='MemAvailable_below_12GiB'
    elif g['MemTotal_bytes']-g['total_reserved']<4*G: abort='physical_headroom_below_4GiB'
    elif g['MemTotal_bytes']<62*G: abort='MemTotal_below_62GiB'
    if abort:
     watch.write(json.dumps({'unix_time':time.time(),'abort':abort,'killed_scope':UNIT+'.scope'})+'\n');watch.flush()
     subprocess.run(['systemctl','--user','kill','--kill-who=all',UNIT+'.scope'],check=False,stdout=log,stderr=log); break
   except Exception as e:
    abort='watcher_failed:'+repr(e);watch.write(json.dumps({'unix_time':time.time(),'abort':abort})+'\n');watch.flush()
    subprocess.run(['systemctl','--user','kill','--kill-who=all',UNIT+'.scope'],check=False,stdout=log,stderr=log);break
   time.sleep(1)
  rc=p.wait()
 elapsed=round(time.monotonic()-wall0,3)
 (ATT/'stage-metrics.json').write_text(json.dumps({'first_seen_elapsed_s':first,'last_seen_elapsed_s':last_seen,'observed_seconds_by_stage':stage_seconds,'peaks_by_stage':peaks,'watchdog_abort':abort,'last_sample':last},indent=2)+'\n')
 receipt={'target':'crate::r1_wire::_::decode_k caller loop with actual field parser and included QM31::ZERO','exit_status':rc,'wall_seconds':elapsed,'watchdog_abort':abort,'attempt':str(ATT),'output':str(OUT),'source_pins':doc['source_pins'],'tool_pins':doc['tool_pins'],'caps':doc['resource_policy'],'preflight':pre,'stage_metrics':'stage-metrics.json'}
 (ATT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n')
 print(json.dumps({'exit_status':rc,'wall_seconds':elapsed,'watchdog_abort':abort,'stage_peaks':peaks}),flush=True)
 raise SystemExit(rc)
if __name__=='__main__':main()
