#!/usr/bin/env bash
set -euo pipefail

SOURCE_ROOT=${SOURCE_ROOT:-/home/dombarker/project-offloads/aspis-r1-semantic-query-final-a555-20261017/decode-k-indexed-candidate-v3-20261018}
CARGO_TARGET_DIR=${CARGO_TARGET_DIR:-/home/dombarker/project-offloads/aspis-r1-semantic-query-final-a555-20261017/cargo-target}
OUT_DIR=${OUT_DIR:?set OUT_DIR to a fresh isolated output directory}
CHARON=${CHARON:-/home/dombarker/project-offloads/aspis-r1-r18-tools-20261016/charon-target/release/charon}
AENEAS=${AENEAS:-/home/dombarker/project-offloads/v7-tag73-challenge-qm31-source-20260825-work/toolchain/output/aeneas-b59d5188-lean432-extended-static}
CHARON_DRIVER=${CHARON_DRIVER:-/home/dombarker/project-offloads/aspis-r1-r18-tools-20261016/charon-target/release/charon-driver}
SOURCE_SNAPSHOT=${SOURCE_SNAPSHOT:-"aspis-r1-semantic-query-final-a555-20261017/decode-k-indexed-candidate-v3-20261018 (isolated proof candidate; production source unchanged)"}

export PATH="$HOME/.cargo/bin:$PATH"
cd "$SOURCE_ROOT"
test "$(sha256sum crates/aspis-r1-cost-probe/src/r1_wire.rs | cut -d' ' -f1)" = 47562d76a47ba602aacbbdd61c9b97c4429ba9700aa96e8ea49d3c4ccab9b444
test "$(sha256sum crates/aspis-r1-cost-probe/src/r1_semantic.rs | cut -d' ' -f1)" = 1e62a9512db72e2ddd83edd124c707e3c5158b35b3cf0ba60e3dcb0803525896
test "$(sha256sum crates/aspis-core/src/field.rs | cut -d' ' -f1)" = 28df5a1abee13bde4b3aa9eeceb0489bedf00531f298460954a97661f5f1baea
test "$(sha256sum Cargo.lock | cut -d' ' -f1)" = f93f8f524fdd707c7a3b7feade31d015c891264b6c8fbd8bff885249e19600ea
test "$(sha256sum crates/aspis-r1-cost-probe/Cargo.toml | cut -d' ' -f1)" = 5fafcd2572896d4ba35cb01304aa6ccde1d0b634804fedf22c3f74133cedf093
test "$(sha256sum "$CHARON" | cut -d' ' -f1)" = daad69bea1114042a2d2fbd3dfde99922b152d4f57023bf8edb83e5a6f336af8
test "$(sha256sum "$AENEAS" | cut -d' ' -f1)" = 4632746db1bf6c3953f2971078965a2a5a8ad6cf5f75636b46b397bc50c550b5
test "$(sha256sum "$CHARON_DRIVER" | cut -d' ' -f1)" = efdbe5b86c9f5f70c93810af08f358d4ecbaecf6f3e87517b1176689a8c28c45
test -d "$CARGO_TARGET_DIR/release/deps"
test ! -e "$OUT_DIR"
mkdir -p "$OUT_DIR/generated"
export CARGO_TARGET_DIR
export RUSTUP_TOOLCHAIN=nightly-2026-06-01
export CARGO_BUILD_JOBS=1 CARGO_NET_OFFLINE=true CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS=true
~/.cargo/bin/rustup show active-toolchain > "$OUT_DIR/rustup-toolchain.txt"
~/.cargo/bin/rustc --version --verbose > "$OUT_DIR/rustc-version.txt"
~/.cargo/bin/cargo --version > "$OUT_DIR/cargo-version.txt"
printf '%s\n' "$SOURCE_SNAPSHOT" > "$OUT_DIR/source-revision.txt"
sha256sum Cargo.lock crates/aspis-r1-cost-probe/Cargo.toml crates/aspis-r1-cost-probe/src/r1_wire.rs crates/aspis-r1-cost-probe/src/r1_semantic.rs crates/aspis-core/src/field.rs > "$OUT_DIR/source-pins.sha256"
printf '%s\n' "$SOURCE_ROOT" > "$OUT_DIR/source-root.txt"
printf '%s\n' "$CARGO_TARGET_DIR" > "$OUT_DIR/cargo-target-dir.txt"

"$CHARON" cargo \
  --preset aeneas --mir built --sysroot default \
  --include aspis_core::field::_::from_le_bytes \
  --include aspis_core::field::P \
  --include aspis_core::field::_::ZERO \
  --include core::option::_::ok_or \
  --include core::option::_::branch \
  --include core::option::_::from_residual \
  --include core::option::Option \
  --include core::result::Result \
  --include core::result::_::map_err \
  --start-from crate::r1_wire::_::decode_k \
  --dest-file "$OUT_DIR/decode_k.llbc" \
  -- \
  --manifest-path crates/aspis-r1-cost-probe/Cargo.toml \
  --locked --offline --release --lib --no-default-features \
  --features private-leaf-salts --jobs 1

"$AENEAS" \
  -sequential -no-progress-bar -abort-on-error -backend lean \
  -namespace AspisR1DecodeKFullV10 \
  -dest "$OUT_DIR/generated" \
  -subdir AspisR1DecodeKFullV10 \
  -split-files -emit-json "$OUT_DIR/decode_k.llbc"

find "$OUT_DIR" -type f ! -name SHA256SUMS -print0 | sort -z | xargs -0 sha256sum > "$OUT_DIR/SHA256SUMS"
