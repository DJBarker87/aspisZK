import AspisR1DecodeKFullHelperCanonicality

set_option autoImplicit false
set_option maxHeartbeats 1000000
open Aeneas Aeneas.Std Result WP
namespace AspisR1DecodeKFullLoopCanonicality

abbrev QM := AspisR1DecodeKFullV10.aspis_core.field.QM31
abbrev N := Usize
abbrev Range := core.ops.range.Range Usize
abbrev DecodeError := AspisR1DecodeKFullV10.r1_wire.Error
abbrev Canonical (q : QM) : Prop :=
  q.c0.a.val < AspisR1DecodeKFullV10.aspis_core.field.P.val ∧
  q.c0.b.val < AspisR1DecodeKFullV10.aspis_core.field.P.val ∧
  q.c1.a.val < AspisR1DecodeKFullV10.aspis_core.field.P.val ∧
  q.c1.b.val < AspisR1DecodeKFullV10.aspis_core.field.P.val
abbrev CanonicalArray {n : Usize} (a : Array QM n) : Prop :=
  ∀ j : Fin n, Canonical (a.val[j.val]'(by simpa [a.property] using j.isLt))

private theorem set_canonical {n : Usize} (a : Array QM n) (i : Usize) (x : QM)
    (ha : CanonicalArray a) (hx : Canonical x) : CanonicalArray (a.set i x) := by
  intro j
  have hjSet : j.val < (a.val.set i.val x).length := by simpa using j.isLt
  have hjOld : j.val < a.val.length := by simpa [a.property] using j.isLt
  change Canonical ((a.val.set i.val x)[j.val]'hjSet)
  by_cases heq : i.val = j.val
  · have hcell : (a.val.set i.val x)[j.val]'hjSet = x := by
      have hself := List.getElem_set_self (l := a.val) (i := i.val) (a := x)
        (by simpa [heq] using hjSet)
      simpa [heq] using hself
    rw [hcell]
    exact hx
  · have hcell : (a.val.set i.val x)[j.val]'hjSet = a.val[j.val]'hjOld := by
      simpa using (List.getElem_set_ne (l := a.val) (i := i.val) (j := j.val)
        heq hjSet)
    rw [hcell]
    exact ha j

private theorem update_success_set {n : Usize} (a : Array QM n) (i : Usize) (x : QM)
    (hi : i.val < n.val) :
    ∃ out : Array QM n, Array.update a i x = .ok out ∧ out = a.set i x := by
  obtain ⟨out, hr, hs⟩ := WP.spec_imp_exists
    (Array.update_spec a i x (by simpa [a.property] using hi))
  exact ⟨out, hr, hs⟩

theorem loop_body_preserves_canonical
    {n : Usize} (self : AspisR1DecodeKFullV10.r1_wire.ValidatedRecord)
    (i offset_values byte_offset : Usize) (iter : Range) (out : Array QM n)
    (value : Usize) (iter1 : Range) (cf : ControlFlow (Range × Array QM n)
      (Array QM n × Option (Result (Array QM n) DecodeError)))
    (hactive : iter.start.val < n.val) (hvalue : value.val < n.val)
    (hnext : core.iter.range.IteratorRange.next core.iter.range.StepUsize iter =
      .ok (some value, iter1)) (hout : CanonicalArray out)
    (hbody : AspisR1DecodeKFullV10.r1_wire.ValidatedRecord.decode_k_loop.body
      self i offset_values byte_offset iter out = .ok cf) :
    (match cf with
      | .cont (_, out1) => CanonicalArray out1
      | .done (out1, _) => CanonicalArray out1) := by
  unfold AspisR1DecodeKFullV10.r1_wire.ValidatedRecord.decode_k_loop.body at hbody
  simp only [hnext, bind_tc_ok] at hbody
  cases hcall : AspisR1DecodeKFullV10.r1_wire.ValidatedRecord.decode_k_value
      { self with row := i } byte_offset value offset_values with
  | fail e => simp [hcall] at hbody
  | div => simp [hcall] at hbody
  | ok result =>
      cases result with
      | Err e =>
          simp only [hcall,
            AspisR1DecodeKFullV10.core.result.Result.Insts.CoreOpsTry.branch,
            bind_tc_ok] at hbody
          simp only [AspisR1DecodeKFullV10.core.result.Result.Insts.CoreOpsTry.branch,
            AspisR1DecodeKFullV10.core.result.Result.Insts.CoreOpsTryTraitFromResidualResultInfallible.from_residual,
            bind_tc_ok, Result.ok.injEq] at hbody
          cases hbody
          exact hout
      | Ok q =>
          have hq : Canonical q :=
            AspisR1DecodeKFullHelperCanonicality.decode_k_value_success_canonical
              { self with row := i } byte_offset value offset_values q hcall
          cases hu : Array.update out value q with
          | fail e => simp [hcall, hu,
              AspisR1DecodeKFullV10.core.result.Result.Insts.CoreOpsTry.branch] at hbody
          | div => simp [hcall, hu,
              AspisR1DecodeKFullV10.core.result.Result.Insts.CoreOpsTry.branch] at hbody
          | ok out1 =>
              obtain ⟨outSpec, hspec, hset⟩ := update_success_set out value q hvalue
              rw [hu] at hspec
              have houtEq : out1 = out.set value q := by
                have heq := Result.ok.inj hspec
                simpa [hset] using heq.symm
              simp only [hcall,
                AspisR1DecodeKFullV10.core.result.Result.Insts.CoreOpsTry.branch,
                bind_tc_ok, hu, Result.ok.injEq] at hbody
              cases hbody
              rw [houtEq]
              exact set_canonical out value q hout hq

#print axioms set_canonical
#print axioms loop_body_preserves_canonical
end AspisR1DecodeKFullLoopCanonicality
