import hashlib,json,pathlib,subprocess,time
G=1024**3; SAFE=58*G; BASE=45*G; DOCKER_FLOOR=24*G; CAP=4608*1024**2
UNIT='aspis-decodek-full-v10-m31-v2-20261018'
ATT=pathlib.Path('/tmp/decodek-full-v10-m31-attempt-v2-20261018')
SRC=pathlib.Path('/tmp/DecodeKFullM31Canonicality-v1.lean')
OBJROOT=pathlib.Path('/tmp/decode-k-full-v10-m31-objects-v2')
V10=pathlib.Path('/tmp/decode-k-full-v10-lean-objects-v2')
OBJ=OBJROOT/'AspisR1DecodeKFullV10ParserCanonicality.olean'
ENV=json.loads(pathlib.Path('/tmp/serializer-bridge-focused-workspace-20261018/environment.json').read_text())['LEAN_PATH']
LEAN=pathlib.Path('/home/dombarker/.elan/toolchains/leanprover--lean4---v4.32.0/bin/lean')
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def need(x,m):
 if not x: raise SystemExit('preflight refused: '+m)
def mem():
 d={}
 for ln in pathlib.Path('/proc/meminfo').read_text().splitlines():
  k,_,v=ln.partition(':')
  if k in ('MemTotal','MemAvailable'): d[k+'_bytes']=int(v.split()[0])*1024
 return d
def scopes(exclude=()):
 docker=other=0; active=[]
 for f in pathlib.Path('/sys/fs/cgroup').rglob('memory.max'):
  c=f.parent
  if not c.name.endswith('.scope') or c.name in exclude: continue
  mx=f.read_text().strip(); ev=c/'cgroup.events'
  if mx=='max' or not ev.is_file(): continue
  d=dict(x.split() for x in ev.read_text().splitlines() if len(x.split())==2)
  if d.get('populated')!='1': continue
  n=int(mx); active.append({'unit':c.name,'memory_max_bytes':n})
  if c.name.startswith('docker-') or 'docker' in c.name.lower(): docker+=n
  else: other+=n
 ext=BASE+max(0,docker-DOCKER_FLOOR)
 return {'docker_caps':docker,'external_reserve':ext,'other_scope_caps':other,'job_cap':CAP,'total_reserved':ext+other+CAP,'active_scopes':active}
def gate(exclude=()):
 s=scopes(exclude); m=mem(); need(m['MemTotal_bytes']>=62*G,'MemTotal <62GiB'); need(s['total_reserved']<=SAFE,'reservation >58GiB'); need(m['MemTotal_bytes']-s['total_reserved']>=4*G,'physical headroom <4GiB'); need(m['MemAvailable_bytes']>=(12 if exclude else 16)*G,'MemAvailable below gate'); return {**s,**m}
def main():
 need(not ATT.exists() and not OBJROOT.exists(),'fresh output paths required')
 need(sha(SRC)=='842a4415db192cad619f4d76ee7af7fd50b42f52a6906cd76bfaed5856a54c40','source hash mismatch')
 need(sha(V10/'AspisR1DecodeKFullV10/Funs.olean')=='8e8696389e79756a7bc2a9415974e251d477ffb0b55670bf14db897249b314db','V10 Funs object mismatch')
 need((V10/'AspisR1DecodeKFullV10/Types.olean').is_file(),'V10 Types object missing')
 pre=gate(); ATT.mkdir(mode=0o700); OBJROOT.mkdir()
 lp=str(OBJROOT)+':/tmp/decode-k-helper-v7-lean-objects-v3:'+str(V10)+':'+ENV
 cmd=['/usr/bin/env','LEAN_PATH='+lp,str(LEAN),'-R','/tmp','-o',str(OBJ),str(SRC)]
 doc={'target':'actual V10 M31 parser success implies canonical range','source':str(SRC),'source_sha256':sha(SRC),'output_module':'AspisR1DecodeKFullV10ParserCanonicality','Lean':str(LEAN),'Lean_commit':'8c9756b28d64dab099da31a4c09229a9e6a2ef35','LEAN_PATH':lp,'imports':{'V10_Funs':'8e8696389e79756a7bc2a9415974e251d477ffb0b55670bf14db897249b314db','V10_Types':'d71d34a5a94afcf860ca8bc5c7b86e3a281838e7baaf8db088409dd996e78043'},'resource_gate':pre,'resource_policy':{'safe_ceiling':SAFE,'MemoryHigh':'4G','MemoryMax':'4608M','MemorySwapMax':'0','TasksMax':128}}
 (ATT/'preflight.json').write_text(json.dumps(doc,indent=2)+'\n')
 shell='/usr/bin/time -v -o '+str(ATT/'time.log')+' '+' '.join(subprocess.list2cmdline([x]) for x in cmd)+' > '+str(ATT/'lean.log')+' 2>&1'
 wrapped=['systemd-run','--user','--scope','--quiet','--unit='+UNIT,'-p','MemoryHigh=4G','-p','MemoryMax=4608M','-p','MemorySwapMax=0','-p','TasksMax=128','/bin/bash','-lc',shell]
 (ATT/'command.json').write_text(json.dumps({'argv':wrapped,'lean_argv':cmd},indent=2)+'\n')
 proc=subprocess.Popen(wrapped); start=time.monotonic(); peak=swpeak=0; aborted=None
 with (ATT/'watcher.jsonl').open('x') as w:
  while proc.poll() is None:
   try:
    g=gate([UNIT+'.scope']); c=next((f.parent for f in pathlib.Path('/sys/fs/cgroup').rglob('memory.max') if f.parent.name==UNIT+'.scope'),None)
    cur=pk=sw=None
    if c:
     cur=int((c/'memory.current').read_text()); pk=int((c/'memory.peak').read_text()); sw=int((c/'memory.swap.current').read_text()); peak=max(peak,pk); swpeak=max(swpeak,sw)
    w.write(json.dumps({'elapsed_s':round(time.monotonic()-start,3),'reserved_total':g['total_reserved'],'MemAvailable':g['MemAvailable_bytes'],'memory_current':cur,'memory_peak':pk,'swap_current':sw})+'\n'); w.flush()
    if g['total_reserved']>SAFE or g['MemAvailable_bytes']<12*G or g['MemTotal_bytes']-g['total_reserved']<4*G:
     aborted='resource_gate_crossed'; subprocess.run(['systemctl','--user','kill','--kill-who=all',UNIT+'.scope'],check=False); break
   except Exception as e:
    aborted='watcher_error:'+repr(e); subprocess.run(['systemctl','--user','kill','--kill-who=all',UNIT+'.scope'],check=False); break
   time.sleep(1)
 rc=proc.wait(); receipt={'target':doc['target'],'exit_status':rc,'wall_seconds':round(time.monotonic()-start,3),'watchdog_abort':aborted,'source_sha256':doc['source_sha256'],'object_sha256':sha(OBJ) if OBJ.exists() else None,'cgroup_memory_peak_bytes':peak,'cgroup_swap_peak_bytes':swpeak,'attempt':str(ATT),'resource_gate':pre}
 (ATT/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n'); print(json.dumps(receipt),flush=True); raise SystemExit(rc)
if __name__=='__main__': main()
