import AspisV8R17.RawReducerNat

/-! Pure arithmetic bridge adapted from the proof bodies in
`GeneratedCM31SquareNormalized.lean` (historical source SHA
`d100cd8da24014e36b23d188cfb9c0958480b1ec882244ba2805275d6a9e2d5a`).
Only Nat/Int identities are reproduced here; no old generated runtime is
imported into the current extraction graph. -/
set_option autoImplicit false

namespace AspisR1.ExtractedMaskSquareArithmetic

abbrev P : Nat := AspisV8R17.RawReducer.P

theorem square_real_int (a b : Nat) (hb : b < P) :
    ((((a + b) * (a + P - b)) % P : Nat) : Int) =
      ((a : Int) * a - (b : Int) * b) % (P : Int) := by
  rw [← Int.natCast_mul, ← Int.natCast_mul]
  have hbb := Nat.mul_le_mul_right b (Nat.le_of_lt hb)
  unfold P at *
  simp only [Nat.mul_sub_left_distrib, Nat.add_mul, Nat.mul_add,
    Nat.mul_comm b a]
  omega

def imagWord (a b c d : Nat) :=
  ((((a + b) * (c + d)) % P + P - (a * c) % P) % P + P -
    (b * d) % P) % P

theorem imagWord_mod (a b c d : Nat) :
    imagWord a b c d = (a * d + b * c) % P := by
  unfold imagWord P
  simp only [Nat.add_mul, Nat.mul_add]
  omega

theorem square_real_word_eq_mul_self_real (a b : Nat)
    (ha : a < P) (hb : b < P) :
    ((a + b) * (a + P - b)) % P =
      ((a * a) % P + P - (b * b) % P) % P := by
  let A := a * a % P
  let B := b * b % P
  have hA : A < P := Nat.mod_lt _ (by omega)
  have hB : B < P := Nat.mod_lt _ (by omega)
  have hleft := square_real_int a b hb
  have hright : ((A + P - B) % P : Nat) =
      ((a : Int) * a - (b : Int) * b) % (P : Int) := by
    apply Int.natCast_inj.mpr
    calc
      (((A + P - B) % P : Nat) : Int) =
          ((A : Int) + P - B) % P := by
            rw [Int.natCast_mod, Int.natCast_sub (by omega)]
            simp only [Int.natCast_add, Int.natCast_natCast]
      _ = ((a : Int) * a - (b : Int) * b) % (P : Int) := by
            dsimp [A, B]
            rw [Int.natCast_mod, Int.natCast_mod]
            omega
  apply Int.natCast_inj.mpr
  calc
    ((((a + b) * (a + P - b)) % P : Nat) : Int) =
        ((a : Int) * a - (b : Int) * b) % (P : Int) := hleft
    _ = (((A + P - B) % P : Nat) : Int) := hright.symm
    _ = (((a * a) % P + P - (b * b) % P) % P : Nat) := by
      dsimp [A, B]
      rfl

#print axioms square_real_int
#print axioms imagWord_mod
#print axioms square_real_word_eq_mul_self_real

end AspisR1.ExtractedMaskSquareArithmetic
