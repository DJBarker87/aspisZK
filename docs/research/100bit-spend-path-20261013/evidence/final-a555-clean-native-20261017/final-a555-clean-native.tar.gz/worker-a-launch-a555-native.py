from pathlib import Path
import json,subprocess,sys,time
p=Path("/home/dombarker/project-offloads/aspis-r1-semantic-query-final-a555-20261017")
label=sys.argv[1]
rev="a555c852664c80000942f0c911e16719a5493625"
cargo="/home/dombarker/.cargo/bin/cargo"
base=[cargo,"run","--verbose","--release","--locked","--offline","-j1"]
test=[cargo,"test","--verbose","--release","--locked","--offline","-j1"]
commands={
 "codec1233-final":base+["-p","aspis-statement","--features","r0,pool-v1-kernel","--example","j1_terminal_codec_trace"],
 "saved-proof-counter-final":base+["--manifest-path","tools/r1-hash-input-counter/Cargo.toml","--",str(p/"fixtures/r1-s2-proof.bin"),str(p/"fixtures/r1-s2-public-asf8.bin"),str(p/"ordered-counter.json"),rev],
 "checkpoint23-final":test+["-p","aspis-r1-cost-probe-program","--features","pool-adapter,private-leaf-salts","--lib","r1_pool_adapter::checkpoint_tests::","--","--test-threads=1"],
}
commands["prepared-failure-overlay"]=test+["-p","aspis-r1-cost-probe","--features","prover,private-leaf-salts,optimized-terminal","--lib","verifier::prepared_migration_tests::prepared_exact_old_new_failures_and_success","--","--nocapture","--test-threads=1"]

commands["tx1-saved-s2-overlay"]=test+["-p","aspis-r1-cost-probe","--features","prover,private-leaf-salts,optimized-terminal,detail-phases","--lib","verifier::tx1_migration_tests::tx1_saved_s2_exact_old_new_faults_and_success","--","--nocapture","--test-threads=1"]
commands["tx1-shared-overlay"]=test+["--manifest-path","tools/r1-tx1-migration-kit/Cargo.toml","--lib","--","--nocapture","--test-threads=1"]

commands["prepared-failure-overlay-fixed"]=commands["prepared-failure-overlay"]

reservations=[]
for d in Path("/sys/fs/cgroup").rglob("*.scope"):
 try:
  maximum=(d/"memory.max").read_text().strip()
  if maximum!="max" and "populated 1" in (d/"cgroup.events").read_text():reservations.append({"scope":str(d),"memory_max_bytes":int(maximum)})
 except (FileNotFoundError,PermissionError):pass
current=sum(r["memory_max_bytes"] for r in reservations)
reservation={"time_unix":time.time(),"active_scope_reservations":reservations,"existing_scope_max_total_bytes":current,"new_scope_memory_max_bytes":8*2**30,"total_with_new_bytes":current+8*2**30,"safe_working_limit_bytes":55*2**30,"expected_work":"warm optimized compilation then named finite native gate; no proof generation, no SBF, no runtime harness","source_revision":rev}
assert reservation["total_with_new_bytes"]<reservation["safe_working_limit_bytes"],reservation
(p/(label+"-reservation.json")).write_text(json.dumps(reservation,indent=2)+"\n")
command=["systemd-run","--user","--scope","--quiet","--unit=r1-finala555-"+label+"-20261017","-p","MemoryHigh=6G","-p","MemoryMax=8G","-p","MemorySwapMax=0","python3",str(p/"run-final-host.py"),"--root",str(p),"--input-manifest",str(p/("inputs-injected.json" if "overlay" in label else "inputs-clean.json")),"--label",label,"--cwd",str(p/("source" if "overlay" in label else "source-clean")),"--kind","native","--timeout","600","--",*commands[label]]
print(json.dumps({"label":label,"reservation_bytes":reservation["total_with_new_bytes"],"safe_limit_bytes":reservation["safe_working_limit_bytes"]}),flush=True)
sys.exit(subprocess.run(command).returncode)
