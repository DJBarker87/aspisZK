from pathlib import Path
import json,hashlib,shutil,subprocess,tarfile,time,os
n=Path('/home/dombarker/project-offloads/aspis-r1-semantic-query-final-a555-20261017');old=Path('/home/dombarker/project-offloads/aspis-r1-semantic-query-final-5a28-20261017');rev='a555c852664c80000942f0c911e16719a5493625';sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
assert n.is_dir() and not(n/'setup.json').exists()
(n/'source-clean').mkdir(exist_ok=True)
with tarfile.open(n/'worker-a-final-a555-source.tar.gz') as t:t.extractall(n/'source-clean',filter='data')
files=json.loads((n/'worker-a-final-a555-source-files.json').read_text())
for p,d in files.items():assert sha(n/'source-clean'/p)==d,p
assert not(n/'cargo-target').exists();subprocess.run(['cp','-a','--reflink=auto',str(old/'cargo-target'),str(n/'cargo-target')],check=True)
for d in ['baseline','fixtures']:shutil.copytree(old/d,n/d)
base='docs/research/100bit-spend-path-20261013/evidence/p3-private-leaf-salts-20261013/p3-pool-13/transfer-1023-os-task'
for f in ['r1-s2-proof.bin','r1-s2-public-asf8.bin']:
 p=n/'source-clean'/base/f;p.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(n/'fixtures'/f,p)
now=time.time()
for p in (n/'source-clean').rglob('*'):
 if p.is_file():os.utime(p,(now,now))
shutil.copyfile(old/'run-final-host.py',n/'run-final-host.py')
manifest={'source_revision':rev,'source_kind':'Clean exact current Gitsource plus pinned checkpointinclude fixtures only','files':{str(p.relative_to(n)):sha(p)for d in ['source-clean','fixtures','baseline']for p in sorted((n/d).rglob('*'))if p.is_file()}}
(n/'inputs-clean.json').write_text(json.dumps(manifest,indent=2)+'\n');(n/'setup.json').write_text(json.dumps({'source_revision':rev,'git_files':len(files),'source_mtimes_refreshed_after_private_cache_copy':True,'cache_origin':str(old/'cargo-target'),'expected_work':'Warm optimized compilation, then1233codec/583orderedcalls/23checkpointtests. No proof generation,SBF orruntimeharness.','setup_time_unix':now},indent=2)+'\n');print('staged',len(manifest['files']),sha(n/'inputs-clean.json'))
