from pathlib import Path
import json,re,hashlib,tarfile
p=Path("/home/dombarker/project-offloads/aspis-r1-begin-straightline-native-20261016")
def sha(raw):return hashlib.sha256(raw).hexdigest()
def j(f):return json.loads(f.read_text())
initial=j(p/"inputs-initial.json");final=j(p/"inputs.json")
assert initial["source_revision"]==final["source_revision"]=="63990fffe36c155ac3a0b435f39b7d326795a1a3"
assert len(initial["files"])==530 and len(final["files"])==532
assert all(final["files"][n]==h for n,h in initial["files"].items())
for name,digest in final["files"].items():assert sha((p/name).read_bytes())==digest,name
trace=(p/"runs/codec1233/stdout.log").read_bytes();assert trace==(p/"baseline/codec1233.stdout.log").read_bytes()
assert sha(trace)=="3ef16b12a329dd6d74b472cd75e5554c1ef8d98c618de3117f87b6c50d73e321" and trace.splitlines()[-1]==b"complete 1233"
a=j(p/"baseline/ordered-counter.json");b=j(p/"ordered-counter.json")
assert a["ordered_digest_calls"]==b["ordered_digest_calls"] and len(b["ordered_digest_calls"])==583
assert a["acceptance"]==b["acceptance"]
for x in [a,b]:x["hash_input_counts"]["repeated_exact_inputs"].sort(key=lambda r:r["input_hex"])
assert a["hash_input_counts"]==b["hash_input_counts"]
assert b["hash_input_counts"]["tx1_raw_calls"]==349 and b["hash_input_counts"]["tx2_raw_calls"]==234
checkpoint=(p/"runs/checkpoint23-staged-fixtures/stdout.log").read_text()
expected=re.findall(r"#\[test\]\s*fn\s+(\w+)",(p/"source/programs/r1-cost-probe/src/r1_checkpoint_tests.rs").read_text())
actual=re.findall(r"test r1_pool_adapter::checkpoint_tests::(\w+) \.\.\. ok",checkpoint)
assert len(expected)==len(actual)==23 and set(expected)==set(actual)
overlay=(p/"runs/begin-failure-overlay/stdout.log").read_text()
failures=re.findall(r"failure (Lookup|Semantic)\((\d+)\):",overlay)
assert set(failures)=={(kind,str(row)) for kind in ["Lookup","Semantic"] for row in range(3,13)} and len(failures)==20
assert "test result: ok. 2 passed; 0 failed;" in overlay
body=(p/"source/crates/aspis-r1-cost-probe/src/r1_wire.rs").read_text()
old=(p/"source/tools/r1-begin-failure-order-kit/old_begin.rs").read_text();new=(p/"source/tools/r1-begin-failure-order-kit/new_begin.rs").read_text()
assert new in body
results=[]
for label in ["codec1233","saved-proof-counter","checkpoint23-staged-fixtures","begin-failure-overlay"]:
 r=j(p/"runs"/label/"receipt.json");assert r["exit_status"]==0 and r["process_swaps"]==0
 assert r["limits"]=={"memory.high":"6442450944","memory.max":"8589934592","memory.swap.max":"0"}
 assert r["stdout_sha256"]==sha((p/"runs"/label/"stdout.log").read_bytes())
 assert r["stderr_sha256"]==sha((p/"runs"/label/"stderr.log").read_bytes())
 runner=p/"runs"/label/"failed-postprocess-runner.py" if r.get("wrapper_exit_status")==1 else p/"run-host.py"
 assert r["runner_sha256"]==sha(runner.read_bytes())
 manifest=p/"inputs.json" if label=="checkpoint23-staged-fixtures" else p/"inputs-initial.json"
 assert r["input_manifest_sha256"]==sha(manifest.read_bytes())
 for path,pin in r["artifacts"].items():assert sha(Path(path).read_bytes())==pin["sha256"]
 results.append(r)
failed=j(p/"runs/checkpoint23/receipt.json");assert failed["exit_status"]==101
summary={"status":"PASS_REQUIRED_NATIVE_RESULTS_WITH_RETAINED_WRAPPER_FAILURES","source_revision":final["source_revision"],"approved_begin_source_revision":"c16ab4d76619cf2cf80ece9d7e60e47975957af0","old_begin_revision":"99263bea08e00911b48ec51a06a7ca0bb8ff66c0","source_files":532,"native_results":results,"codec1233_byte_equal":True,"codec_trace_sha256":sha(trace),"saved_proof_ordered_digest_calls_equal":583,"tx1_raw_calls":349,"tx2_raw_calls":234,"checkpoint_bytes_identical":True,"checkpoint_tests":actual,"injected_failure_paths":failures,"overlay_success_control":True,"failure_scope":"Exact entire old/new begin declarations against shared instrumented interfaces; Rust Result propagation, prefix order and test state carry only. No actual production reachability of injected interface failures is claimed.","retained_failures":{"codec1233":"native childexit0; wrapperpostprocessexit1; recovered exactGNUtime/RSS/swaps/source/binary/stdout metrics, no rerun","saved-proof-counter":"native childexit0; wrapperpostprocessexit1; recovered exactGNUtime/RSS/swaps/source/binary/report metrics, no rerun","checkpoint23":"compileexit101 due missing2 declared include_bytes files; exact existing savedfixtures staged; only checkpoint target rerun"},"no_Lean":True,"no_SBF":True,"no_runtime_harness":True,"no_proof_generation":True}
(p/"SUMMARY.json").write_text(json.dumps(summary,indent=2)+"\n")
paths=["source","baseline","fixtures","runs","inputs-initial.json","inputs.json","setup.json","launch-native.py","r16-begin-launch-native.py","r16-begin-stage-fixtures.py","fixture-staging-repair.json","run-host.py","recover-counter.py","postflight.py","ordered-counter.json","SUMMARY.json"]
paths += [f.name for f in p.glob("*-reservation.json")]
archive=p/"begin-straightline-native-evidence.tar.gz"
with tarfile.open(archive,"w:gz") as tf:
 for name in paths:tf.add(p/name,arcname=name)
print(json.dumps({"status":summary["status"],"archive":str(archive),"bytes":archive.stat().st_size,"sha256":sha(archive.read_bytes()),"checkpoint_tests":len(actual),"injected_failures":len(failures)}))
