from pathlib import Path
import shutil,json,hashlib
p=Path("/home/dombarker/project-offloads/aspis-r1-begin-straightline-native-20261016")
(p/"inputs-initial.json").write_bytes((p/"inputs.json").read_bytes())
dst=p/"source/docs/research/100bit-spend-path-20261013/evidence/p3-private-leaf-salts-20261013/p3-pool-13/transfer-1023-os-task"
dst.mkdir(parents=True,exist_ok=True)
inputs=json.loads((p/"inputs.json").read_text())
repair={"reason":"Checkpoint test compile exposed2 missing include_bytes inputs in staged source; files already retained separately as saved proof fixtures. Added exact retained fixtures at declared source paths. No production source change or proof generation.","failed_attempt":"runs/checkpoint23/receipt.json","added":{}}
for name in ["r1-s2-proof.bin","r1-s2-public-asf8.bin"]:
 f=dst/name;shutil.copyfile(p/"fixtures"/name,f)
 digest=hashlib.sha256(f.read_bytes()).hexdigest();relative=str(f.relative_to(p));inputs["files"][relative]=digest;repair["added"][relative]=digest
(p/"inputs.json").write_text(json.dumps(inputs,indent=2)+"\n")
(p/"fixture-staging-repair.json").write_text(json.dumps(repair,indent=2)+"\n")
print(repair)
