from pathlib import Path
import json,subprocess,sys,time
p=Path("/home/dombarker/project-offloads/aspis-r1-begin-straightline-native-20261016")
label=sys.argv[1]
rev="63990fffe36c155ac3a0b435f39b7d326795a1a3"
cargo="/home/dombarker/.cargo/bin/cargo"
base=[cargo,"run","--verbose","--release","--locked","--offline","-j1"]
test=[cargo,"test","--verbose","--release","--locked","--offline","-j1"]
commands={
 "codec1233":base+["-p","aspis-statement","--features","r0,pool-v1-kernel","--example","j1_terminal_codec_trace"],
 "saved-proof-counter":base+["--manifest-path","tools/r1-hash-input-counter/Cargo.toml","--",str(p/"fixtures/r1-s2-proof.bin"),str(p/"fixtures/r1-s2-public-asf8.bin"),str(p/"ordered-counter.json"),rev],
 "checkpoint23":test+["-p","aspis-r1-cost-probe-program","--features","pool-adapter,private-leaf-salts","--lib","r1_pool_adapter::checkpoint_tests::","--","--test-threads=1"],
 "begin-failure-overlay":test+["--manifest-path","tools/r1-begin-failure-order-kit/Cargo.toml","--lib","--","--nocapture","--test-threads=1"]}
commands["checkpoint23-staged-fixtures"]=commands["checkpoint23"]
reservations=[]
for d in Path("/sys/fs/cgroup").rglob("*.scope"):
 try:
  maximum=(d/"memory.max").read_text().strip()
  if maximum!="max" and "populated 1" in (d/"cgroup.events").read_text():reservations.append({"scope":str(d),"memory_max_bytes":int(maximum)})
 except (FileNotFoundError,PermissionError):pass
current=sum(r["memory_max_bytes"] for r in reservations)
reservation={"time_unix":time.time(),"active_scope_reservations":reservations,"existing_scope_max_total_bytes":current,"new_scope_memory_max_bytes":8*2**30,"total_with_new_bytes":current+8*2**30,"safe_working_limit_bytes":55*2**30,"expected_work":"warm optimized compilation then named finite native gate; no proof generation, no SBF, no runtime harness","source_revision":rev}
assert reservation["total_with_new_bytes"]<reservation["safe_working_limit_bytes"],reservation
(p/(label+"-reservation.json")).write_text(json.dumps(reservation,indent=2)+"\n")
command=["systemd-run","--user","--scope","--quiet","--unit=r1-begin-"+label+"-20261016","-p","MemoryHigh=6G","-p","MemoryMax=8G","-p","MemorySwapMax=0","python3",str(p/"run-host.py"),"--root",str(p),"--label",label,"--cwd",str(p/"source"),"--kind","native","--timeout","600","--",*commands[label]]
print(json.dumps({"label":label,"reservation_bytes":reservation["total_with_new_bytes"],"safe_limit_bytes":reservation["safe_working_limit_bytes"]}),flush=True)
sys.exit(subprocess.run(command).returncode)
