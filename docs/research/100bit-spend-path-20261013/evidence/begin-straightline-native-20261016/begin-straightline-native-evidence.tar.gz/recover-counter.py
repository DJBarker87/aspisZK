from pathlib import Path
import json,re,hashlib
p=Path("/home/dombarker/project-offloads/aspis-r1-begin-straightline-native-20261016")
r=p/"runs/saved-proof-counter"
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
time=(r/"time.log").read_text()
def metric(label):return int(re.search(re.escape(label)+r":\s*(\d+)",time)[1])
wall=re.search(r"Elapsed \(wall clock\) time \(h:mm:ss or m:ss\):\s*([\d:.]+)",time)[1]
seconds=sum(float(x)*60**i for i,x in enumerate(reversed(wall.split(":"))))
assert metric("Exit status")==0
exe=p/"cargo-target/release/r1-hash-input-counter"
cmd=["/home/dombarker/.cargo/bin/cargo","run","--verbose","--release","--locked","--offline","-j1","--manifest-path","tools/r1-hash-input-counter/Cargo.toml","--",str(p/"fixtures/r1-s2-proof.bin"),str(p/"fixtures/r1-s2-public-asf8.bin"),str(p/"ordered-counter.json"),"63990fffe36c155ac3a0b435f39b7d326795a1a3"]
failed=p/"runs/codec1233/failed-postprocess-runner.py"
(r/"failed-postprocess-runner.py").write_bytes(failed.read_bytes())
receipt={"label":"saved-proof-counter","kind":"native","command":cmd,"cwd":str(p/"source"),"source_revision":"63990fffe36c155ac3a0b435f39b7d326795a1a3","input_manifest_sha256":sha(p/"inputs.json"),"exit_status":0,"wrapper_exit_status":1,"wall_seconds":seconds,"wall_measurement":"GNU time -v elapsed with0.01second precision; controller high-resolution wall lost before receipt write","peak_rss_kib":metric("Maximum resident set size (kbytes)"),"process_swaps":metric("Swaps"),"limits":{"memory.high":"6442450944","memory.max":"8589934592","memory.swap.max":"0"},"cgroup":"r1-begin-saved-proof-counter-20261016.scope","cgroup_swap_current":"not retained after scope exit; mandatory memory.swap.max0 prohibits swap","cgroup_memory_peak_bytes":None,"runner_sha256":sha(failed),"stdout_sha256":sha(r/"stdout.log"),"stderr_sha256":sha(r/"stderr.log"),"artifacts":{str(exe):{"sha256":sha(exe),"bytes":exe.stat().st_size}},"axioms":"N/A Rust native execution only","receipt_recovery":"Child cargo succeeded per retained GNU time exit0 and complete ordered-counter.json. The intended scanner correction had not applied because of shell quote removal; same postprocessing path failed. No rerun. Fixed runner was subsequently uploaded as a file and read back before remaining2jobs.","validation_failure":"Wrapper postprocessing filename-too-long; successful native child retained separately"}
(r/"receipt.json").write_text(json.dumps(receipt,indent=2)+"\n")
a=json.loads((p/"baseline/ordered-counter.json").read_text());b=json.loads((p/"ordered-counter.json").read_text())
assert a["acceptance"]==b["acceptance"]
assert a["ordered_digest_calls"]==b["ordered_digest_calls"] and len(b["ordered_digest_calls"])==583
assert b["hash_input_counts"]["tx1_raw_calls"]==349 and b["hash_input_counts"]["tx2_raw_calls"]==234
for value in [a,b]:value["hash_input_counts"]["repeated_exact_inputs"].sort(key=lambda r:r["input_hex"])
assert a["hash_input_counts"]==b["hash_input_counts"]
print({"child_exit":0,"wrapper_exit":1,"wall_seconds":seconds,"rss":receipt["peak_rss_kib"],"ordered_calls":583,"tx1":349,"tx2":234,"checkpoint_identical":True})
