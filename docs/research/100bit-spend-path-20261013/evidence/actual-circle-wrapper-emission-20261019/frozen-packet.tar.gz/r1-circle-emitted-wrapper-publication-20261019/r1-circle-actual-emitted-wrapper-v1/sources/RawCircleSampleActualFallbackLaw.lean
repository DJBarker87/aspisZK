import AspisR1CircleSampleWrapper.Funs
import AspisR1CircleFallback.RawCircleFallbackOutputBridge

set_option autoImplicit false
set_option maxHeartbeats 1000000
set_option maxRecDepth 2048
open Aeneas Aeneas.Std Result

namespace AspisR1CircleSampleWrapper
namespace RawCircleSampleActualFallbackLaw

open AspisV8R15.ExactTowerBase
open AspisV8R19.SamplerClosureCircleSourceExecution
open AspisV8R19.SamplerCirclePolicy
open AspisV8R19.SamplerClosureProductCorrectness
open AspisV8R19.SamplerClosureProductExecution (encode)
open R0P.SemSource

def fallbackPoint0 : circle.SecureCirclePoint :=
  fromFallbackPoint (AspisR1CircleFallback.fromR72Point
    (encodePoint (point AspisR1CircleFallback.RawCircleFallbackOutputBridge.fallbackParameter0)))

def fallbackPoint1 : circle.SecureCirclePoint :=
  fromFallbackPoint (AspisR1CircleFallback.fromR72Point
    (encodePoint (point AspisR1CircleFallback.RawCircleFallbackOutputBridge.fallbackParameter1)))

/-- The sample wrapper fallback now executes the extracted fallback owner. -/
theorem fallback_zero_output :
    transcript.circle_fallback_point 0#usize = .ok fallbackPoint0 := by
  unfold AspisR1CircleSampleWrapper.transcript.circle_fallback_point fallbackPoint0
  rw [AspisR1CircleFallback.RawCircleFallbackOutputBridge.fallback_zero_output]
  rfl

theorem fallback_one_output :
    transcript.circle_fallback_point 1#usize = .ok fallbackPoint1 := by
  unfold AspisR1CircleSampleWrapper.transcript.circle_fallback_point fallbackPoint1
  rw [AspisR1CircleFallback.RawCircleFallbackOutputBridge.fallback_one_output]
  rfl

theorem fallback_zero_coordinates_match :
    (algebraMap QM31Exact AspisWideTower.WideExact (decode (toR72QM fallbackPoint0.x)),
      algebraMap QM31Exact AspisWideTower.WideExact (decode (toR72QM fallbackPoint0.y))) =
      circleFallback0.1 := by
  simpa [fallbackPoint0, fromFallbackPoint, AspisR1CircleFallback.fromR72Point,
      fromR72Point, fromFallbackQM, AspisR1CircleFallback.fromR72QM,
      fromR72QM, fromFallbackCM, AspisR1CircleFallback.fromR72CM,
      toR72QM, toR72CM] using
    AspisR1CircleFallback.RawCircleFallbackOutputBridge.fallback_zero_coordinates_match

theorem fallback_one_coordinates_match :
    (algebraMap QM31Exact AspisWideTower.WideExact (decode (toR72QM fallbackPoint1.x)),
      algebraMap QM31Exact AspisWideTower.WideExact (decode (toR72QM fallbackPoint1.y))) =
      circleFallback1.1 := by
  simpa [fallbackPoint1, fromFallbackPoint, AspisR1CircleFallback.fromR72Point,
      fromR72Point, fromFallbackQM, AspisR1CircleFallback.fromR72QM,
      fromR72QM, fromFallbackCM, AspisR1CircleFallback.fromR72CM,
      toR72QM, toR72CM] using
    AspisR1CircleFallback.RawCircleFallbackOutputBridge.fallback_one_coordinates_match

theorem fallback_first_arm_actual
    (block : Array Std.U8 32#usize) (q : field.QM31) (err : circle.CirclePointError)
    (hsample : sampler.qm31_sample block = ok q)
    (hcircle : circle.secure_ood_circle_point_from_parameter q = ok (.Err err)) :
    sampler.circle_sample block .First = .ok fallbackPoint0 := by
  simp [sampler.circle_sample, hsample, hcircle, fallback_zero_output]

theorem fallback_second_arm_actual
    (block : Array Std.U8 32#usize) (q : field.QM31) (err : circle.CirclePointError)
    (hsample : sampler.qm31_sample block = ok q)
    (hcircle : circle.secure_ood_circle_point_from_parameter q = ok (.Err err)) :
    sampler.circle_sample block .Second = .ok fallbackPoint1 := by
  simp [sampler.circle_sample, hsample, hcircle, fallback_one_output]

#print axioms fallback_zero_output
#print axioms fallback_one_output
#print axioms fallback_zero_coordinates_match
#print axioms fallback_one_coordinates_match
#print axioms fallback_first_arm_actual
#print axioms fallback_second_arm_actual

end RawCircleSampleActualFallbackLaw
end AspisR1CircleSampleWrapper
