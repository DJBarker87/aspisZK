# Actual emitted `circle_sample` wrapper packet

This packet records the bounded patched-Aeneas extraction, Lean owner builds, proof receipt, and failed predecessors for the `sampler.circle_sample` wrapper. The generated function is the unchanged Rust wrapper: it invokes `qm31_sample`, then `secure_ood_circle_point_from_parameter`, and calls the actual `Result.unwrap_or_else` with the generated `FnOnce` closure. The closure maps `First`/`Second` to fallback indices 0/1. No hand-written match replaced the wrapper.

## Accepted checked owners

- `AspisR1CircleSampleWrapper.FunsExternal`: source SHA `333c99752d98b2b195203bddbb781549c8bd4114d6dc271f8897378230a38374`, object SHA `5051916f224b4ae074e637733c9166621ac8980d23abc4ed976438b9c015896b`, v3 external receipt.
- `AspisR1CircleSampleWrapper.Funs`: exact emitted source SHA `5d1b131ed8be869faa5814712dd46e684b205abe512a90c0272c41e957b4eed6`, object SHA `7abf97410a440730bfc40ad253cd5d3c2bb01c4a1cd09e4f4bfd89086cd09e9d`, v3 Funs receipt.
- `AspisR1CircleSampleWrapper.RawCircleSampleEmittedWrapperLaw`: source SHA `9dc2f64bef1a3677e6aa187f8cb2515b7b8206759a56606a0440ceba0de873b2`, object SHA `ff31a44963bfeafd3312956967571c44f81d66d42cc8d1de2153ba97594fef9a`, v4 law receipt.

The law proves adapter equalities for the public sampler, selected R72 secure mapper and extracted fallback; actual wrapper success on a secure result; both exact fallback arms after mapper error; and propagation of sampler/mapper failures. All printed axiom sets are `[propext, Classical.choice, Quot.sound]`.

## Toolchain/extraction provenance

- Aeneas base commit: `b59d5188c082f704a418c7cb4e52ad69328002d1`.
- Semantics-preserving recoverable-join patch: `aeneas-circle-joinfix.patch`, SHA `2b9574903d78749bffdaaf84caa892a4befa2127debb3569e4e306e9a3deecf8`; changed only the projection/join handling in `InterpReduceCollapse.ml`, its `.mli`, and `InterpJoin.ml`. The missing abstraction mapping now raises the established recoverable failure so the existing branch-duplication path can handle it; it does not substitute an identity mapping.
- Patched Aeneas executable SHA: `d037bd2dcd7784bdae2d3987926e1d04c12a51113242a05ffd7e6ad8ade76055`.
- Lean source extraction input `CircleSample.llbc` SHA: `a19e2bcbca71a3751cdfb67a48212f98f062632d633476bd24f4bb03588715b7`.
- Actual generated `Types.lean` raw snapshot SHA: `d9b61e938125ada9a08b5db46617ed369a483655466669160b27a0c495649100` (copied as `raw-generated-Types.lean`). For Lean, the canonical selected named-discriminant `Types` owner was reused; it has the same constructors/fields, and the generated closure type alias is carried in `FunsExternal`.
- Lean compiler SHA: `e8baaa71855a616dc351028f3ad2200051b0671f423a1696a100e809302d5550` (Lean 4.32.0).
- The source worktree snapshot is `original-dirty-worktree-snapshot.json`, SHA `4e4e2af5dd0e8927630cae16d664ba9e25928070c390eb397b89389daf22687f`. The command plan and source pins for the exact LLBC are in `actual-emission/original-command-plan.json` and `actual-emission/source-pins.json`; the patched-Aeneas invocation and timing are in `actual-emission/repro.log`.

The original release build of the patched executable succeeded in the bounded Docker build, but no external timing/RSS measurement was captured for that build. Therefore this packet records the binary hash and build provenance but does not claim measured build-resource metrics.

## Attempts and resource evidence

`v1`/`v2` preserve earlier Lean interpreter allocation-threshold failures at `-M1800`; scope peaks were about 221 MB, with no cgroup OOM events. The v3 heavy fallback-law import failed at Lean `-M3500` with an interpreter excessive-memory diagnostic (process RSS about 3.79 GiB, scope peak about 1.36 GB, swap 0, no cgroup memory events). These are Lean interpreter thresholds, not host/cgroup OOMs. The changed v4 law split imports only the actual wrapper owner and passed. Exact raw logs, preflight, command, time, admission, and receipt records are preserved in the attempt directories. `historical-explicit-match-extraction/` preserves the earlier candidate extraction only as diagnostic provenance.
