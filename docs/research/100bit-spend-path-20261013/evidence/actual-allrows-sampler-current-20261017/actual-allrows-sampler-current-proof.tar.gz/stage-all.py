from pathlib import Path
import json,hashlib,shutil,re,runpy
w=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-rounds-proof-20261017');c=Path('/home/dombarker/project-offloads/aspis-r1-worker-c-paired-current-20261017');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();runpy.run_path(str(w/'stage-opening.py'));external=json.loads((c/'external-inputs.json').read_text());mods=external['modules'];seen={};conflicts=[]
def visit(name):
 if name in seen:return
 ownsrc=c/'sources'/(name.replace('.','/')+'.lean')
 if ownsrc.exists():
  rec=c/'successful-targets'/(name+'.json');d=json.loads(rec.read_text());obj=c/'objects'/(name.replace('.','/')+'.olean');assert d['exit_status']==0 and d['key']['source_sha256']==sha(ownsrc)and d['objects']['.olean']['sha256']==sha(obj);meta={'source':str(ownsrc),'source_sha256':sha(ownsrc),'objects':{'.olean':{'path':str(obj),'sha256':sha(obj)}},'build_receipt':{'path':str(rec),'sha256':sha(rec)},'imports':re.findall(r'^import ([\w.]+)',ownsrc.read_text(),re.M),'root':'current_c_finish'}
 elif name in mods:meta=mods[name]
 else:
  assert name.startswith(('Init','Lean','Std','Lake')),name
  return
 seen[name]=meta
 if meta.get('root') in ['backend','runtime','mathlib','aesop','batteries','Qq','proofwidgets','plausible','LeanSearchClient','importGraph']:return
 if meta.get('root')!='backend':
  src=Path(meta['source']);obj=Path(meta['objects']['.olean']['path']);assert sha(src)==meta['source_sha256']and sha(obj)==meta['objects']['.olean']['sha256'];rec=Path(meta['build_receipt']['path'])if 'build_receipt'in meta else None
  if rec is not None:assert sha(rec)==meta['build_receipt']['sha256']
  for folder,ext,p in [('sources','.lean',src),('objects','.olean',obj)]:
   target=w/folder/(name.replace('.','/')+ext);target.parent.mkdir(parents=True,exist_ok=True)
   if target.exists():assert sha(target)==sha(p),(name,folder,'incompatible universe')
   else:shutil.copyfile(p,target)
  if rec is not None:shutil.copyfile(rec,w/'producing-inputs'/('c-paired-'+name+'.json'))
 for n in meta['imports']:visit(n)
for n in ['ExtractedFirstPairedReachability']:visit(n)
m=json.loads((w/'input-manifest.json').read_text());m['current_paired_import_closure']=seen;m['fresh_opening_predecessors']={n:json.loads((w/'runs'/a/'receipt.json').read_text())for n,a in [('ExtractedOpeningCalls','opening-calls-a'),('ExtractedOpeningQueriesReachability','query-carry-a'),('ExtractedCircleCalls','circle-calls-b'),('ExtractedOpeningRun','opening-run-a')]};m['sources']={str(p.relative_to(w/'sources')):sha(p)for p in(w/'sources').rglob('*.lean')};(w/'input-manifest.json').write_text(json.dumps(m,indent=2)+'\n');shutil.copyfile(c/'external-inputs.json',w/'producing-inputs/c-paired-external-inputs.json');print('pinned C paired import closure',len(seen),'conflicts',len(conflicts))
