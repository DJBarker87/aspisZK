from pathlib import Path
import json,hashlib,shutil,runpy
w=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-rounds-proof-20261017');old=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-prepared-3335-20261016/lean');canon=Path('/home/dombarker/project-offloads/aspis-r1-worker-c-tx1-proof-20261016');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();runpy.run_path(str(w/'stage.py'));manifest=json.loads((w/'input-manifest.json').read_text());pins={}
# Already producing exact current Type/Funs+PreparedModel closure; no older universe is mixed.
for name,attempt in [('ExtractedOpeningQueriesModel','query-model-a'),('ExtractedPreparedReachability','reach-d')]:
 src=old/'sources'/(name+'.lean');obj=old/'objects'/(name+'.olean');receipt=old/'runs'/attempt/'receipt.json';d=json.loads(receipt.read_text());m=json.loads((receipt.parent/'input-manifest.json').read_text());assert d['exit_status']==0 and d['source_sha256']==sha(src)and d['olean_sha256']==sha(obj)
 for dep in ['AspisR1PublicPreparation.Types','AspisR1PublicPreparation.Funs']:
  a=m['current_canonical_pins'][dep];b=manifest['current_canonical_and_begin_pins'][dep];assert a['source_sha256']==b['source_sha256']and a['object_sha256']==b['object_sha256']
 for folder,ext,p in [('sources','.lean',src),('objects','.olean',obj)]:shutil.copyfile(p,w/folder/(name+ext))
 shutil.copyfile(receipt,w/'producing-inputs'/(name+'.json'));shutil.copyfile(receipt.parent/'input-manifest.json',w/'producing-inputs'/(name+'-input-manifest.json'));pins[name]={'source':str(src),'source_sha256':sha(src),'object':str(obj),'object_sha256':sha(obj),'receipt':str(receipt),'receipt_sha256':sha(receipt)}
name='ExtractedPreparedModel';src=canon/'sources'/(name+'.lean');obj=canon/'objects'/(name+'.olean');receipt=canon/'successful-targets'/(name+'.json');d=json.loads(receipt.read_text());assert d['exit_status']==0 and d['key']['source_sha256']==sha(src)and d['objects']['.olean']['sha256']==sha(obj)
assert m['current_canonical_pins'][name]['source_sha256']==sha(src)and m['current_canonical_pins'][name]['object_sha256']==sha(obj)
for folder,ext,p in [('sources','.lean',src),('objects','.olean',obj)]:shutil.copyfile(p,w/folder/(name+ext))
shutil.copyfile(receipt,w/'producing-inputs'/(name+'.json'));pins[name]={'source':str(src),'source_sha256':sha(src),'object':str(obj),'object_sha256':sha(obj),'receipt':str(receipt),'receipt_sha256':sha(receipt)}
manifest['current_opening_pins']=pins;manifest['sources']={str(p.relative_to(w/'sources')):sha(p)for p in(w/'sources').rglob('*.lean')};(w/'input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('coherent opening dependencies pinned',list(pins))
