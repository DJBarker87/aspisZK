from pathlib import Path
import json,hashlib,shutil
w=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-rounds-proof-20261017');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();a=json.loads((w/'sampler-current-alignment-audit.json').read_text());cur=json.loads((w/'producing-inputs/c-paired-external-inputs.json').read_text())['modules'];mods=a['normalized_old_modules'];targets=set(a['rebuild_targets']);reused=[]
# Shared backend/library objects must agree before any old sampler cache is reused.
for n,old in mods.items():
 if old['root']in ['backend','runtime','mathlib','aesop','batteries','Qq','proofwidgets','plausible','LeanSearchClient','importGraph']and n in cur:assert old['objects']['.olean']['sha256']==cur[n]['objects']['.olean']['sha256'],('library conflict',n)
for n in a['custom_dependency_order']:
 old=mods[n];m=cur[n]if n in cur else old;src=Path(m['source']);assert sha(src)==m['source_sha256'];q=w/'sources'/(n.replace('.','/')+'.lean');q.parent.mkdir(parents=True,exist_ok=True)
 if q.exists():assert sha(q)==sha(src),('source conflict',n)
 else:shutil.copyfile(src,q)
 if n not in targets:
  obj=Path(m['objects']['.olean']['path']);assert sha(obj)==m['objects']['.olean']['sha256'];q=w/'objects'/(n.replace('.','/')+'.olean');q.parent.mkdir(parents=True,exist_ok=True)
  if q.exists():assert sha(q)==sha(obj),('object conflict',n)
  else:shutil.copyfile(obj,q)
  for ext,artifact in m['objects'].items():
   if ext=='.olean':continue
   origin=Path(artifact['path']);assert sha(origin)==artifact['sha256'];target=w/'objects'/(n.replace('.','/')+ext)
   if target.exists():assert sha(target)==sha(origin),('sidecar conflict',n,ext)
   else:shutil.copyfile(origin,target)
  reused.append(n)
 receipt=m.get('build_receipt')
 if receipt:
  p=Path(receipt['path']);assert sha(p)==receipt['sha256'];shutil.copyfile(p,w/'producing-inputs'/('sampler-'+n+'.json'))
m=json.loads((w/'input-manifest.json').read_text());m['sampler_alignment']=a;m['sampler_current_objects_reused']=reused;m['sources']={str(p.relative_to(w/'sources')):sha(p)for p in(w/'sources').rglob('*.lean')};(w/'input-manifest.json').write_text(json.dumps(m,indent=2)+'\n');print('sampler stage',len(reused),'cached',len(targets),'focused targets')
