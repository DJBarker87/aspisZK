from pathlib import Path
import json,subprocess,time
w=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-rounds-proof-20261017');a=json.loads((w/'sampler-current-alignment-audit.json').read_text());targets=a['rebuild_targets'][1:]+['ExtractedDigest32SamplerTransport']
for i,n in enumerate(targets):
 attempt='sampler-refresh-'+str(i);unit='aspis-a-sampler-refresh-'+str(i)+'-20261017'
 cmd=['systemd-run','--user','--wait','--pipe','--unit',unit,'-p','MemoryHigh=6G','-p','MemoryMax=8G','-p','MemorySwapMax=0','python3',str(w/'run-lean-host.py'),str(w),n,'--attempt',attempt,'--revision','a555c852664c80000942f0c911e16719a5493625']
 p=subprocess.run(cmd,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(w/('sampler-refresh-'+str(i)+'-wrapper.log')).write_text(p.stdout)
 assert p.returncode==0,(n,p.stdout[-2000:])
 r=json.loads((w/'runs'/attempt/'receipt.json').read_text());log=(w/'runs'/attempt/'lean.log').read_text();assert r['exit_status']==0 and'sorryAx'not in log and'depends on axioms:'in log
 print(json.dumps({k:r[k]for k in ['target','exit_status','wall_seconds','peak_process_rss_kib','process_swaps']}),flush=True)
 m=json.loads((w/'input-manifest.json').read_text());m.setdefault('sampler_refreshed_receipts',{})[n]=r;(w/'input-manifest.json').write_text(json.dumps(m,indent=2)+'\n')
print('QM31_CURRENT_ALIGNMENT_GREEN',flush=True)
