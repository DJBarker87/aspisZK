from pathlib import Path
import json,hashlib,re
w=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-rounds-proof-20261017');old=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-callers-c16-20261016/lean');a=json.loads((old/'external-sampler-pins.json').read_text())['modules'];cur=json.loads((w/'producing-inputs/c-paired-external-inputs.json').read_text())['modules'];seen={};order=[];libs={'backend','runtime','mathlib','aesop','batteries','Qq','proofwidgets','plausible','LeanSearchClient','importGraph'}
def normalize(n,m):
 m=dict(m)
 if 'root'not in m:m['root']='proof_cache'
 if 'objects'not in m:m['objects']={'.olean':{'path':m['object'],'sha256':m['object_sha256']}}
 if 'build_receipt'not in m and'receipt'in m:m['build_receipt']={'path':m['receipt'],'sha256':m['receipt_sha256']}
 if 'imports'not in m:m['imports']=[v for line in re.findall(r'^import (.+)$',Path(m['source']).read_text(),re.M)for v in line.split()]
 return m
def visit(n):
 if n in seen:return
 if n not in a:return
 m=normalize(n,a[n]);seen[n]=m
 if m['root']in libs:return
 for k in m['imports']:visit(k)
 order.append(n)
visit('ExtractedQM31SamplerCorrect');conflicts=[];dirty=set()
for n in order:
 m=seen[n]
 if n in cur and cur[n]['objects']['.olean']['sha256']!=m['objects']['.olean']['sha256']:
  conflicts.append({'module':n,'old_source_sha256':m['source_sha256'],'current_source_sha256':cur[n]['source_sha256'],'old_object_sha256':m['objects']['.olean']['sha256'],'current_object_sha256':cur[n]['objects']['.olean']['sha256'],'same_source':m['source_sha256']==cur[n]['source_sha256']});dirty.add(n)
 if any(i in dirty for i in m['imports']):dirty.add(n)
targets=[n for n in order if n in dirty and n not in cur];out={'custom_dependency_order':order,'normalized_old_modules':seen,'conflicts':conflicts,'rebuild_targets':targets,'reused_current_conflicts':[x['module']for x in conflicts],'old_snapshot_sha256':hashlib.sha256((old/'external-sampler-pins.json').read_bytes()).hexdigest(),'current_snapshot_sha256':hashlib.sha256((w/'producing-inputs/c-paired-external-inputs.json').read_bytes()).hexdigest()};(w/'sampler-current-alignment-audit.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({'custom_modules':len(order),'conflicts':conflicts,'targets':targets},indent=2))
