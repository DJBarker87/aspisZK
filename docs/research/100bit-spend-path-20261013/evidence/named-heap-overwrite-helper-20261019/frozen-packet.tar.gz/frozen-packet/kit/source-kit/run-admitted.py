from pathlib import Path
import argparse, contextlib, fcntl, io, json, runpy, subprocess, datetime
p=argparse.ArgumentParser();p.add_argument('--phase',choices=['charon','aeneas'],required=True);a=p.parse_args()
w=Path('/home/dombarker/project-offloads/heap-filled-overwrite-helper-v2')
collector=Path('/home/dombarker/project-offloads/r1-circle-sample-wrapper-extraction-v2/collect-cgroups.py')
with open('/tmp/aspis-global-extraction-admission-20261019.lock','a') as lock:
 fcntl.flock(lock,fcntl.LOCK_EX)
 buf=io.StringIO()
 with contextlib.redirect_stdout(buf):runpy.run_path(str(collector))
 inv=json.loads(buf.getvalue());rows=inv['all_populated_cgroups']
 uncapped=[r for r in rows if r['max']=='max' and (r['scope'] or (Path(r['path']).name.endswith('.service') and not any(Path(r['path']) in Path(s['path']).parents for s in rows)))]
 outer=[r for r in uncapped if not any(Path(s['path']) in Path(r['path']).parents for s in uncapped)]
 candidate=2*2**30;reserve=8*2**30;usage=sum(r['current_bytes'] or 0 for r in outer)
 checks={'finite_plus_candidate_below_48GiB':inv['effective_sum_bytes']+candidate<=48*2**30,'reservation_plus_uncapped_plus_OS_below_total':inv['effective_sum_bytes']+candidate+usage+reserve<=inv['MemTotal_kB']*1024,'available_at_least_14GiB':inv['MemAvailable_kB']*1024>=14*2**30}
 tag=datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')
 report={'inventory':inv,'outermost_uncapped_execution_nodes':outer,'candidate_bytes':candidate,'OS_reserve_bytes':reserve,'checks':checks,'scope':'prelaunch aggregate admission, lock held until scoped process terminates'}
 out=w/('admission-'+a.phase+'-'+tag+'.json');out.write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({'phase':a.phase,'checks':checks,'finite_reserved_GiB':inv['effective_sum_bytes']/2**30,'outer_uncapped_current_GiB':usage/2**30}),flush=True)
 assert all(checks.values()),'admission rejected; no job started'
 cmd=['systemd-run','--user','--scope','--quiet','-p','MemoryHigh=1G','-p','MemoryMax=2G','-p','MemorySwapMax=0','-p','TasksMax=128','python3',str(w/'run-host.py'),'--phase',a.phase,'--attempt','named-helper-v2-'+tag]
 raise SystemExit(subprocess.run(cmd).returncode)
