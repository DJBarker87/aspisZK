#!/usr/bin/env python3
from pathlib import Path
import argparse, hashlib, json, os, re, signal, subprocess, time, shutil
sha=lambda b:hashlib.sha256(b).hexdigest()
TOOLS=Path('/home/dombarker/project-offloads/aspis-r1-r18-tools-20261016')
STATIC=Path('/home/dombarker/project-offloads/v7-tag73-challenge-qm31-source-20260825-work/toolchain/output/aeneas-b59d5188-lean432-extended-static')
PINS={'charon-target/release/charon':'daad69bea1114042a2d2fbd3dfde99922b152d4f57023bf8edb83e5a6f336af8','charon-target/release/charon-driver':'efdbe5b86c9f5f70c93810af08f358d4ecbaecf6f3e87517b1176689a8c28c45','bin/aeneas':'4632746db1bf6c3953f2971078965a2a5a8ad6cf5f75636b46b397bc50c550b5'}
def dump(p,x):p.write_text(json.dumps(x,indent=2,sort_keys=True)+'\n')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('--phase',choices=['charon','aeneas'],required=True);ap.add_argument('--attempt',required=True);a=ap.parse_args()
 w=Path(__file__).resolve().parent;kit=w/'input';pins=json.loads((w/'source-pins.json').read_text())
 for name,h in json.loads((w/'kit-manifest.json').read_text())['files'].items():
  if name.startswith('input/'): assert sha((w/name).read_bytes())==h,name
 for name,h in PINS.items(): assert sha((STATIC if name=='bin/aeneas' else TOOLS/name).read_bytes())==h,name
 cgline=Path('/proc/self/cgroup').read_text().strip();assert cgline.startswith('0::'),cgline
 cg=Path('/sys/fs/cgroup')/cgline[3:].lstrip('/')
 limits={n:(cg/n).read_text().strip() for n in ['memory.high','memory.max','memory.swap.max']}
 assert limits=={'memory.high':str(1*2**30),'memory.max':str(2*2**30),'memory.swap.max':'0'},limits
 out=w/'runs'/(a.phase+'-'+a.attempt);out.mkdir(parents=True,exist_ok=False)
 shutil.copytree(kit,out/'input-snapshot')
 llbc=w/'HeapFilledOverwrite.llbc';gen=w/'generated'
 if a.phase=='charon':
  cmd=[str(TOOLS/'charon-target/release/charon'),'cargo','--preset','aeneas','--mir','built','--sysroot','default','--include','core::option::Option','--include','core::result::Result','--include','core::result::_::map_err','--start-from','crate::aspis_core::r0::heap::filled_overwrite','--dest-file',str(llbc),'--','--locked','--offline','--release','--lib','--no-default-features','--jobs','1']
 else:
  raw=json.loads(llbc.read_text());assert raw and not raw['has_errors'],'invalid LLBC not passed to Aeneas'
  cmd=[str(STATIC),'-sequential','-no-progress-bar','-abort-on-error','-backend','lean','-namespace','AspisR1HeapFilledOverwrite','-dest',str(gen),'-subdir','AspisR1HeapFilledOverwrite','-split-files','-emit-json',str(llbc)]
 env=dict(os.environ);env.update(PATH='/home/dombarker/.cargo/bin:/usr/bin:/bin',RUSTUP_TOOLCHAIN='nightly-2026-06-01',CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR=str(w/'target'),CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS='true')
 for k in ['RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_ENCODED_RUSTFLAGS','CHARON_TOOLCHAIN_IS_IN_PATH']:env.pop(k,None)
 dump(out/'environment.json',{n:env.get(n) for n in ['PATH','RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','CARGO_TARGET_DIR','CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS']});dump(out/'command.json',cmd)
 before=(cg/'memory.events').read_text();start=time.monotonic();peak=0;timed=False
 with (out/'stdout.log').open('x') as log:
  p=subprocess.Popen(['/usr/bin/time','-v','-o',str(out/'time.log'),*cmd],cwd=kit,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  while p.poll() is None:
   peak=max(peak,int((cg/'memory.current').read_text()))
   if time.monotonic()-start>180:
    timed=True;os.killpg(p.pid,signal.SIGTERM)
    try:p.wait(timeout=3)
    except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)
    break
   time.sleep(.2)
  p.wait()
 timing=(out/'time.log').read_text() if (out/'time.log').exists() else ''
 def val(label):
  m=re.search(re.escape(label)+r':\s*(\d+)',timing);return int(m[1]) if m else None
 outputs={}
 if llbc.is_file():outputs[str(llbc.relative_to(w))]=sha(llbc.read_bytes())
 if gen.exists():
  for f in gen.rglob('*'):
   if f.is_file():outputs[str(f.relative_to(w))]=sha(f.read_bytes())
 rec={'phase':a.phase,'exit_status':p.returncode,'wall_seconds':round(time.monotonic()-start,3),'peak_process_rss_kib':val('Maximum resident set size (kbytes)'),'process_swaps':val('Swaps'),'sampled_scope_peak_bytes':peak,'scope_limits':limits,'memory_events_before':before,'memory_events_after':(cg/'memory.events').read_text(),'scope_swap_current':int((cg/'memory.swap.current').read_text()),'timed_out':timed,'source_revision':pins['repository_revision'],'source_pins_sha256':sha((w/'source-pins.json').read_bytes()),'source_files':{'parent_heap_sha256':pins['parent_source_sha256'],'candidate_heap_sha256':pins['candidate_source_sha256'],'target':pins['target']},'tools':PINS,'command':cmd,'outputs':outputs,'scope':'1 GiB high / 2 GiB max / 0 swap; one isolated candidate helper root (module path shim directories are included), offline release Cargo invocation; no package-wide build; adds n writes after resize'}
 dump(out/'receipt.json',rec);print(json.dumps(rec,indent=2));raise SystemExit(p.returncode)
if __name__=='__main__':main()
