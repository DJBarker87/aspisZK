# Isolated BatchedWeights push-query and initialization extraction candidate

This candidate is based on the accepted v5 source-call extraction input. It retains its copied field implementation and push/value wrappers, adds a source-shaped ascending `push_query` helper plus one public root, and adds a `new_entry` root that copies the `BatchedWeights::new` lane initialization from the pinned verifier snapshot.

The `push_query` helper is new and has no production counterpart. The `new` lane copying is copied from verifier.rs, but the standalone kit uses a local `filled` implementation and `AllocationError` subset copied from the pinned `aspis-core/src/r0/heap.rs`; linkage of this subset to the production allocator remains explicit. The verifier's full caller is not being extracted in this target. Production files are unchanged.

The initial copy loop is an indexed, source-compatible expansion of the exact `raw.iter_mut().zip(weights)` loop. V6 Aeneas translation failed internally on the borrow-iterator loop; this changed copy-loop shape is separately tracked and is not source-identical.
