//! Source-exact verifier batching operations; only the wrapper is added.
use alloc::vec::Vec;
use crate::aspis_core;
use crate::aspis_core::field::{QM31 as K, M31};

/// Isolated copy of the allocation error variant needed by BatchedWeights::new.
#[derive(Clone, Copy, Debug)]
pub enum AllocationError { Allocation }

/// Source-shaped `heap::filled` subset from asp is_core::r0::heap.
fn filled<T: Copy>(n: usize, value: T) -> Result<Vec<T>, AllocationError> {
    let mut out = Vec::new();
    out.try_reserve_exact(n).map_err(|_| AllocationError::Allocation)?;
    out.resize(n, value);
    Ok(out)
}

struct BatchedWeights { raw:Vec<[u64;4]>, terms:usize }
impl BatchedWeights {
    fn new(weights: &[K]) -> Result<Self, AllocationError> {
        let mut raw = filled(weights.len(), [0u64; 4])?;
        for index in 0..weights.len() {
            let w = weights[index];
            raw[index] = [w.c0.a.0 as u64, w.c0.b.0 as u64,
                          w.c1.a.0 as u64, w.c1.b.0 as u64];
        }
        Ok(Self { raw, terms: 0 })
    }
    #[inline(always)]
    fn push(&mut self,index:usize,power:K,basis:M31) {
        let limbs=[power.c0.a.0,power.c0.b.0,power.c1.a.0,power.c1.b.0];
        for j in 0..4 {self.raw[index][j]+=u64::from(limbs[j])*u64::from(basis.0);}
        if self.terms&3==3 {
            let lane=self.raw[index];
            self.raw[index]=[
                (lane[0]&0x7fff_ffff)+(lane[0]>>31),
                (lane[1]&0x7fff_ffff)+(lane[1]>>31),
                (lane[2]&0x7fff_ffff)+(lane[2]>>31),
                (lane[3]&0x7fff_ffff)+(lane[3]>>31),
            ];
        }
    }
    /// Apply the source caller's complete ascending basis row, then advance
    /// the batch phase exactly once for this query.
    fn push_query(&mut self,power:K,basis:&[M31;256],len:usize) {
        for index in 0..len { self.push(index,power,basis[index]); }
        self.terms += 1;
    }
    fn value(&self,index:usize)->K {
        let lane=self.raw[index];
        let [a,b,c,d]=[
            M31::reduce_u64(lane[0]),
            M31::reduce_u64(lane[1]),
            M31::reduce_u64(lane[2]),
            M31::reduce_u64(lane[3]),
        ];
        K{c0:aspis_core::field::CM31{a,b},c1:aspis_core::field::CM31{a:c,b:d}}
    }
}

/// Isolated source entry for BatchedWeights::new. The heap/Error subset above
/// is copied into this extraction crate; its allocator correspondence remains
/// a separate Lean boundary.
pub fn new_entry(weights: &[K]) -> Result<(Vec<[u64;4]>, usize), AllocationError> {
    let state = BatchedWeights::new(weights)?;
    Ok((state.raw, state.terms))
}

/// Execute exactly the source push body over caller-provided raw lanes. The
/// wrapper exposes post-state and omits `new` allocation and verifier context.
pub fn push_entry(raw:Vec<[u64;4]>, terms:usize, index:usize, power:K, basis:M31) -> (Vec<[u64;4]>,usize) {
    let mut weights=BatchedWeights { raw, terms };
    weights.push(index,power,basis);
    (weights.raw,weights.terms)
}

/// Isolated Aeneas target for one actual caller query: four-limb row updates
/// in ascending `index`, followed by the single caller counter increment.
pub fn push_query_entry(
    raw:Vec<[u64;4]>, terms:usize, power:K, basis:[M31;256], len:usize
) -> (Vec<[u64;4]>,usize) {
    let mut weights=BatchedWeights { raw, terms };
    weights.push_query(power,&basis,len);
    (weights.raw,weights.terms)
}

/// Execute exactly the source value body on caller-provided raw lanes.
pub fn value_entry(raw:Vec<[u64;4]>, terms:usize, index:usize) -> K {
    let weights=BatchedWeights { raw, terms };
    weights.value(index)
}
