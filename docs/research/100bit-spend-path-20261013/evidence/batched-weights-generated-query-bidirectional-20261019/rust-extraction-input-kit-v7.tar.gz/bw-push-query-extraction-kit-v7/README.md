# BatchedWeights isolated push-query and constructor extraction candidate

This v6 kit is based on the accepted v5 BatchedWeights extraction packet. It adds two isolated roots: `push_query_entry`, an ascending indexed loop over `0..len` that calls the existing push method and increments `terms` once, and `new_entry`, a copy of the `BatchedWeights::new` field initialization using a minimal local `filled`/allocation-error subset.

The new method `push_query` has no production counterpart and is a model candidate. The initializer arithmetic and zero counter follow verifier.rs, but the exact `aspis_core::r0::heap::filled` dependency and allocation failure behavior are not yet tied to this isolated subset. Production files are unchanged.
