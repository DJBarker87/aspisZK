/home/dombarker/project-offloads/aspis-r1-digest32-native-20261016/cargo-target/release/deps/aspis_core-3fdc848af5f3cff8.d: crates/aspis-core/src/lib.rs crates/aspis-core/src/circle.rs crates/aspis-core/src/circle_fri.rs crates/aspis-core/src/circle_hiding_prefix.rs crates/aspis-core/src/circle_hiding_query.rs crates/aspis-core/src/circle_line_merkle.rs crates/aspis-core/src/circle_merkle.rs crates/aspis-core/src/circle_openings.rs crates/aspis-core/src/circle_pcs_shape.rs crates/aspis-core/src/circle_prefix.rs crates/aspis-core/src/circle_query.rs crates/aspis-core/src/digest.rs crates/aspis-core/src/field.rs crates/aspis-core/src/field/wide_exact.rs crates/aspis-core/src/merkle.rs crates/aspis-core/src/params.rs crates/aspis-core/src/proof.rs crates/aspis-core/src/r0/mod.rs crates/aspis-core/src/r0/basis.rs crates/aspis-core/src/r0/chord.rs crates/aspis-core/src/r0/domain.rs crates/aspis-core/src/r0/encoder.rs crates/aspis-core/src/r0/fold.rs crates/aspis-core/src/r0/heap.rs crates/aspis-core/src/r0/onchain.rs crates/aspis-core/src/r0/merkle.rs crates/aspis-core/src/r0/opening.rs crates/aspis-core/src/r0/prover.rs crates/aspis-core/src/r0/scalar.rs crates/aspis-core/src/r0/structured.rs crates/aspis-core/src/r0/transcript.rs crates/aspis-core/src/r0/transport.rs crates/aspis-core/src/r0/verifier.rs crates/aspis-core/src/r0/wire.rs crates/aspis-core/src/r0_transcript.rs crates/aspis-core/src/state_only_hiding.rs crates/aspis-core/src/state_only_masked_switch.rs crates/aspis-core/src/state_only_masked_switch_basis.rs crates/aspis-core/src/state_only_prefix.rs crates/aspis-core/src/state_only_private_merkle.rs crates/aspis-core/src/state_only_private_openings.rs crates/aspis-core/src/state_only_query.rs crates/aspis-core/src/state_only_relation.rs crates/aspis-core/src/state_only_spend_openings.rs crates/aspis-core/src/state_only_spend_query.rs crates/aspis-core/src/state_only_spend_relation.rs crates/aspis-core/src/state_only_sumcheck.rs crates/aspis-core/src/statement_hiding.rs crates/aspis-core/src/statement_sumcheck.rs crates/aspis-core/src/sumcheck.rs crates/aspis-core/src/transcript.rs crates/aspis-core/src/v6_onefold.rs crates/aspis-core/src/v6_query_batch.rs crates/aspis-core/src/v6_transcript.rs crates/aspis-core/src/v7_code_switch.rs crates/aspis-core/src/v7_compact_onefold.rs crates/aspis-core/src/v7_lane_zeta.rs crates/aspis-core/src/v7_merkle.rs crates/aspis-core/src/v7_merkle208.rs crates/aspis-core/src/v7_onefold.rs crates/aspis-core/src/v7_profile.rs crates/aspis-core/src/v7_staged_pair.rs crates/aspis-core/src/verify.rs /home/dombarker/project-offloads/aspis-r1-digest32-native-20261016/cargo-target/release/build/aspis-core-b53b2eb2ea3fa916/out/circle_tables.rs crates/aspis-core/src/r0/top_overflow.rs crates/aspis-core/src/r0/transport_pads.rs

/home/dombarker/project-offloads/aspis-r1-digest32-native-20261016/cargo-target/release/deps/libaspis_core-3fdc848af5f3cff8.rlib: crates/aspis-core/src/lib.rs crates/aspis-core/src/circle.rs crates/aspis-core/src/circle_fri.rs crates/aspis-core/src/circle_hiding_prefix.rs crates/aspis-core/src/circle_hiding_query.rs crates/aspis-core/src/circle_line_merkle.rs crates/aspis-core/src/circle_merkle.rs crates/aspis-core/src/circle_openings.rs crates/aspis-core/src/circle_pcs_shape.rs crates/aspis-core/src/circle_prefix.rs crates/aspis-core/src/circle_query.rs crates/aspis-core/src/digest.rs crates/aspis-core/src/field.rs crates/aspis-core/src/field/wide_exact.rs crates/aspis-core/src/merkle.rs crates/aspis-core/src/params.rs crates/aspis-core/src/proof.rs crates/aspis-core/src/r0/mod.rs crates/aspis-core/src/r0/basis.rs crates/aspis-core/src/r0/chord.rs crates/aspis-core/src/r0/domain.rs crates/aspis-core/src/r0/encoder.rs crates/aspis-core/src/r0/fold.rs crates/aspis-core/src/r0/heap.rs crates/aspis-core/src/r0/onchain.rs crates/aspis-core/src/r0/merkle.rs crates/aspis-core/src/r0/opening.rs crates/aspis-core/src/r0/prover.rs crates/aspis-core/src/r0/scalar.rs crates/aspis-core/src/r0/structured.rs crates/aspis-core/src/r0/transcript.rs crates/aspis-core/src/r0/transport.rs crates/aspis-core/src/r0/verifier.rs crates/aspis-core/src/r0/wire.rs crates/aspis-core/src/r0_transcript.rs crates/aspis-core/src/state_only_hiding.rs crates/aspis-core/src/state_only_masked_switch.rs crates/aspis-core/src/state_only_masked_switch_basis.rs crates/aspis-core/src/state_only_prefix.rs crates/aspis-core/src/state_only_private_merkle.rs crates/aspis-core/src/state_only_private_openings.rs crates/aspis-core/src/state_only_query.rs crates/aspis-core/src/state_only_relation.rs crates/aspis-core/src/state_only_spend_openings.rs crates/aspis-core/src/state_only_spend_query.rs crates/aspis-core/src/state_only_spend_relation.rs crates/aspis-core/src/state_only_sumcheck.rs crates/aspis-core/src/statement_hiding.rs crates/aspis-core/src/statement_sumcheck.rs crates/aspis-core/src/sumcheck.rs crates/aspis-core/src/transcript.rs crates/aspis-core/src/v6_onefold.rs crates/aspis-core/src/v6_query_batch.rs crates/aspis-core/src/v6_transcript.rs crates/aspis-core/src/v7_code_switch.rs crates/aspis-core/src/v7_compact_onefold.rs crates/aspis-core/src/v7_lane_zeta.rs crates/aspis-core/src/v7_merkle.rs crates/aspis-core/src/v7_merkle208.rs crates/aspis-core/src/v7_onefold.rs crates/aspis-core/src/v7_profile.rs crates/aspis-core/src/v7_staged_pair.rs crates/aspis-core/src/verify.rs /home/dombarker/project-offloads/aspis-r1-digest32-native-20261016/cargo-target/release/build/aspis-core-b53b2eb2ea3fa916/out/circle_tables.rs crates/aspis-core/src/r0/top_overflow.rs crates/aspis-core/src/r0/transport_pads.rs

/home/dombarker/project-offloads/aspis-r1-digest32-native-20261016/cargo-target/release/deps/libaspis_core-3fdc848af5f3cff8.rmeta: crates/aspis-core/src/lib.rs crates/aspis-core/src/circle.rs crates/aspis-core/src/circle_fri.rs crates/aspis-core/src/circle_hiding_prefix.rs crates/aspis-core/src/circle_hiding_query.rs crates/aspis-core/src/circle_line_merkle.rs crates/aspis-core/src/circle_merkle.rs crates/aspis-core/src/circle_openings.rs crates/aspis-core/src/circle_pcs_shape.rs crates/aspis-core/src/circle_prefix.rs crates/aspis-core/src/circle_query.rs crates/aspis-core/src/digest.rs crates/aspis-core/src/field.rs crates/aspis-core/src/field/wide_exact.rs crates/aspis-core/src/merkle.rs crates/aspis-core/src/params.rs crates/aspis-core/src/proof.rs crates/aspis-core/src/r0/mod.rs crates/aspis-core/src/r0/basis.rs crates/aspis-core/src/r0/chord.rs crates/aspis-core/src/r0/domain.rs crates/aspis-core/src/r0/encoder.rs crates/aspis-core/src/r0/fold.rs crates/aspis-core/src/r0/heap.rs crates/aspis-core/src/r0/onchain.rs crates/aspis-core/src/r0/merkle.rs crates/aspis-core/src/r0/opening.rs crates/aspis-core/src/r0/prover.rs crates/aspis-core/src/r0/scalar.rs crates/aspis-core/src/r0/structured.rs crates/aspis-core/src/r0/transcript.rs crates/aspis-core/src/r0/transport.rs crates/aspis-core/src/r0/verifier.rs crates/aspis-core/src/r0/wire.rs crates/aspis-core/src/r0_transcript.rs crates/aspis-core/src/state_only_hiding.rs crates/aspis-core/src/state_only_masked_switch.rs crates/aspis-core/src/state_only_masked_switch_basis.rs crates/aspis-core/src/state_only_prefix.rs crates/aspis-core/src/state_only_private_merkle.rs crates/aspis-core/src/state_only_private_openings.rs crates/aspis-core/src/state_only_query.rs crates/aspis-core/src/state_only_relation.rs crates/aspis-core/src/state_only_spend_openings.rs crates/aspis-core/src/state_only_spend_query.rs crates/aspis-core/src/state_only_spend_relation.rs crates/aspis-core/src/state_only_sumcheck.rs crates/aspis-core/src/statement_hiding.rs crates/aspis-core/src/statement_sumcheck.rs crates/aspis-core/src/sumcheck.rs crates/aspis-core/src/transcript.rs crates/aspis-core/src/v6_onefold.rs crates/aspis-core/src/v6_query_batch.rs crates/aspis-core/src/v6_transcript.rs crates/aspis-core/src/v7_code_switch.rs crates/aspis-core/src/v7_compact_onefold.rs crates/aspis-core/src/v7_lane_zeta.rs crates/aspis-core/src/v7_merkle.rs crates/aspis-core/src/v7_merkle208.rs crates/aspis-core/src/v7_onefold.rs crates/aspis-core/src/v7_profile.rs crates/aspis-core/src/v7_staged_pair.rs crates/aspis-core/src/verify.rs /home/dombarker/project-offloads/aspis-r1-digest32-native-20261016/cargo-target/release/build/aspis-core-b53b2eb2ea3fa916/out/circle_tables.rs crates/aspis-core/src/r0/top_overflow.rs crates/aspis-core/src/r0/transport_pads.rs

crates/aspis-core/src/lib.rs:
crates/aspis-core/src/circle.rs:
crates/aspis-core/src/circle_fri.rs:
crates/aspis-core/src/circle_hiding_prefix.rs:
crates/aspis-core/src/circle_hiding_query.rs:
crates/aspis-core/src/circle_line_merkle.rs:
crates/aspis-core/src/circle_merkle.rs:
crates/aspis-core/src/circle_openings.rs:
crates/aspis-core/src/circle_pcs_shape.rs:
crates/aspis-core/src/circle_prefix.rs:
crates/aspis-core/src/circle_query.rs:
crates/aspis-core/src/digest.rs:
crates/aspis-core/src/field.rs:
crates/aspis-core/src/field/wide_exact.rs:
crates/aspis-core/src/merkle.rs:
crates/aspis-core/src/params.rs:
crates/aspis-core/src/proof.rs:
crates/aspis-core/src/r0/mod.rs:
crates/aspis-core/src/r0/basis.rs:
crates/aspis-core/src/r0/chord.rs:
crates/aspis-core/src/r0/domain.rs:
crates/aspis-core/src/r0/encoder.rs:
crates/aspis-core/src/r0/fold.rs:
crates/aspis-core/src/r0/heap.rs:
crates/aspis-core/src/r0/onchain.rs:
crates/aspis-core/src/r0/merkle.rs:
crates/aspis-core/src/r0/opening.rs:
crates/aspis-core/src/r0/prover.rs:
crates/aspis-core/src/r0/scalar.rs:
crates/aspis-core/src/r0/structured.rs:
crates/aspis-core/src/r0/transcript.rs:
crates/aspis-core/src/r0/transport.rs:
crates/aspis-core/src/r0/verifier.rs:
crates/aspis-core/src/r0/wire.rs:
crates/aspis-core/src/r0_transcript.rs:
crates/aspis-core/src/state_only_hiding.rs:
crates/aspis-core/src/state_only_masked_switch.rs:
crates/aspis-core/src/state_only_masked_switch_basis.rs:
crates/aspis-core/src/state_only_prefix.rs:
crates/aspis-core/src/state_only_private_merkle.rs:
crates/aspis-core/src/state_only_private_openings.rs:
crates/aspis-core/src/state_only_query.rs:
crates/aspis-core/src/state_only_relation.rs:
crates/aspis-core/src/state_only_spend_openings.rs:
crates/aspis-core/src/state_only_spend_query.rs:
crates/aspis-core/src/state_only_spend_relation.rs:
crates/aspis-core/src/state_only_sumcheck.rs:
crates/aspis-core/src/statement_hiding.rs:
crates/aspis-core/src/statement_sumcheck.rs:
crates/aspis-core/src/sumcheck.rs:
crates/aspis-core/src/transcript.rs:
crates/aspis-core/src/v6_onefold.rs:
crates/aspis-core/src/v6_query_batch.rs:
crates/aspis-core/src/v6_transcript.rs:
crates/aspis-core/src/v7_code_switch.rs:
crates/aspis-core/src/v7_compact_onefold.rs:
crates/aspis-core/src/v7_lane_zeta.rs:
crates/aspis-core/src/v7_merkle.rs:
crates/aspis-core/src/v7_merkle208.rs:
crates/aspis-core/src/v7_onefold.rs:
crates/aspis-core/src/v7_profile.rs:
crates/aspis-core/src/v7_staged_pair.rs:
crates/aspis-core/src/verify.rs:
/home/dombarker/project-offloads/aspis-r1-digest32-native-20261016/cargo-target/release/build/aspis-core-b53b2eb2ea3fa916/out/circle_tables.rs:
crates/aspis-core/src/r0/top_overflow.rs:
crates/aspis-core/src/r0/transport_pads.rs:

# env-dep:OUT_DIR=/home/dombarker/project-offloads/aspis-r1-digest32-native-20261016/cargo-target/release/build/aspis-core-b53b2eb2ea3fa916/out
