/home/dombarker/project-offloads/aspis-r1-digest32-native-20261016/cargo-target/release/deps/aspis_prover-ced0284b27f3bdb1.d: crates/aspis-prover/src/lib.rs crates/aspis-prover/src/circle_candidate.rs crates/aspis-prover/src/circle_candidate_openings.rs crates/aspis-prover/src/pow.rs crates/aspis-prover/src/state_only_candidate.rs crates/aspis-prover/src/state_only_candidate_prefix.rs crates/aspis-prover/src/state_only_circle_relation.rs crates/aspis-prover/src/state_only_entropy.rs crates/aspis-prover/src/state_only_good_spend.rs crates/aspis-prover/src/state_only_hiding.rs crates/aspis-prover/src/state_only_hiding_rank.rs crates/aspis-prover/src/state_only_hiding_rank/spend_polynomial_kernel_rank.rs crates/aspis-prover/src/state_only_hiding_rank/spend_zero_factor_root_neutral.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_affine_slice_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_claim_aggregation_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_complete_shared_mask_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_extra_mask_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_joint_aux_claim_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_native_full_x_affine_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_reduced_high_switch_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_two_variable_slice_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_variable_permutation_rank.rs crates/aspis-prover/src/state_only_private_openings.rs crates/aspis-prover/src/state_only_proof.rs crates/aspis-prover/src/state_only_spend.rs crates/aspis-prover/src/state_only_spend_candidate.rs crates/aspis-prover/src/state_only_spend_openings.rs crates/aspis-prover/src/state_only_spend_release.rs crates/aspis-prover/src/state_only_zerocheck.rs crates/aspis-prover/src/v6_onefold_prover.rs crates/aspis-prover/src/v8_privacy_affine_gate.rs crates/aspis-prover/src/v8_privacy_publication.rs crates/aspis-prover/src/v8_six_mask_hiding_rank.rs crates/aspis-prover/src/v7_pair_forest_fixture.rs crates/aspis-prover/src/pool_v1_pair_forest_honest.rs crates/aspis-prover/src/r0.rs crates/aspis-prover/src/r0_fixture.rs

/home/dombarker/project-offloads/aspis-r1-digest32-native-20261016/cargo-target/release/deps/libaspis_prover-ced0284b27f3bdb1.rmeta: crates/aspis-prover/src/lib.rs crates/aspis-prover/src/circle_candidate.rs crates/aspis-prover/src/circle_candidate_openings.rs crates/aspis-prover/src/pow.rs crates/aspis-prover/src/state_only_candidate.rs crates/aspis-prover/src/state_only_candidate_prefix.rs crates/aspis-prover/src/state_only_circle_relation.rs crates/aspis-prover/src/state_only_entropy.rs crates/aspis-prover/src/state_only_good_spend.rs crates/aspis-prover/src/state_only_hiding.rs crates/aspis-prover/src/state_only_hiding_rank.rs crates/aspis-prover/src/state_only_hiding_rank/spend_polynomial_kernel_rank.rs crates/aspis-prover/src/state_only_hiding_rank/spend_zero_factor_root_neutral.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_affine_slice_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_claim_aggregation_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_complete_shared_mask_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_extra_mask_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_joint_aux_claim_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_native_full_x_affine_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_reduced_high_switch_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_two_variable_slice_rank.rs crates/aspis-prover/src/state_only_hiding_rank/state_only_variable_permutation_rank.rs crates/aspis-prover/src/state_only_private_openings.rs crates/aspis-prover/src/state_only_proof.rs crates/aspis-prover/src/state_only_spend.rs crates/aspis-prover/src/state_only_spend_candidate.rs crates/aspis-prover/src/state_only_spend_openings.rs crates/aspis-prover/src/state_only_spend_release.rs crates/aspis-prover/src/state_only_zerocheck.rs crates/aspis-prover/src/v6_onefold_prover.rs crates/aspis-prover/src/v8_privacy_affine_gate.rs crates/aspis-prover/src/v8_privacy_publication.rs crates/aspis-prover/src/v8_six_mask_hiding_rank.rs crates/aspis-prover/src/v7_pair_forest_fixture.rs crates/aspis-prover/src/pool_v1_pair_forest_honest.rs crates/aspis-prover/src/r0.rs crates/aspis-prover/src/r0_fixture.rs

crates/aspis-prover/src/lib.rs:
crates/aspis-prover/src/circle_candidate.rs:
crates/aspis-prover/src/circle_candidate_openings.rs:
crates/aspis-prover/src/pow.rs:
crates/aspis-prover/src/state_only_candidate.rs:
crates/aspis-prover/src/state_only_candidate_prefix.rs:
crates/aspis-prover/src/state_only_circle_relation.rs:
crates/aspis-prover/src/state_only_entropy.rs:
crates/aspis-prover/src/state_only_good_spend.rs:
crates/aspis-prover/src/state_only_hiding.rs:
crates/aspis-prover/src/state_only_hiding_rank.rs:
crates/aspis-prover/src/state_only_hiding_rank/spend_polynomial_kernel_rank.rs:
crates/aspis-prover/src/state_only_hiding_rank/spend_zero_factor_root_neutral.rs:
crates/aspis-prover/src/state_only_hiding_rank/state_only_affine_slice_rank.rs:
crates/aspis-prover/src/state_only_hiding_rank/state_only_claim_aggregation_rank.rs:
crates/aspis-prover/src/state_only_hiding_rank/state_only_complete_shared_mask_rank.rs:
crates/aspis-prover/src/state_only_hiding_rank/state_only_extra_mask_rank.rs:
crates/aspis-prover/src/state_only_hiding_rank/state_only_joint_aux_claim_rank.rs:
crates/aspis-prover/src/state_only_hiding_rank/state_only_native_full_x_affine_rank.rs:
crates/aspis-prover/src/state_only_hiding_rank/state_only_reduced_high_switch_rank.rs:
crates/aspis-prover/src/state_only_hiding_rank/state_only_two_variable_slice_rank.rs:
crates/aspis-prover/src/state_only_hiding_rank/state_only_variable_permutation_rank.rs:
crates/aspis-prover/src/state_only_private_openings.rs:
crates/aspis-prover/src/state_only_proof.rs:
crates/aspis-prover/src/state_only_spend.rs:
crates/aspis-prover/src/state_only_spend_candidate.rs:
crates/aspis-prover/src/state_only_spend_openings.rs:
crates/aspis-prover/src/state_only_spend_release.rs:
crates/aspis-prover/src/state_only_zerocheck.rs:
crates/aspis-prover/src/v6_onefold_prover.rs:
crates/aspis-prover/src/v8_privacy_affine_gate.rs:
crates/aspis-prover/src/v8_privacy_publication.rs:
crates/aspis-prover/src/v8_six_mask_hiding_rank.rs:
crates/aspis-prover/src/v7_pair_forest_fixture.rs:
crates/aspis-prover/src/pool_v1_pair_forest_honest.rs:
crates/aspis-prover/src/r0.rs:
crates/aspis-prover/src/r0_fixture.rs:
