impl SemanticTranscript {
