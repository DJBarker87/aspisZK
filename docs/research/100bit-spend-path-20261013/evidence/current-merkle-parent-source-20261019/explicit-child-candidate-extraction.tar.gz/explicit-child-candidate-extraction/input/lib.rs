#![no_std]

pub trait Digest32: Copy {
    fn digest(&self, parts: &[&[u8]]) -> [u8; 32];
}

pub mod merkle {
use crate::Digest32;
pub type Digest = [u8;32];
pub fn parent_with_digest<H: Digest32>(hash: H, children: &[Digest; 8]) -> Digest {
    hash.digest(&[
        &[0x18],
        &children[0],
        &children[1],
        &children[2],
        &children[3],
        &children[4],
        &children[5],
        &children[6],
        &children[7],
    ])
}
}

pub mod verifier {
use crate::{Digest32,merkle};
#[inline(always)]
fn merkle_child(slot:usize,node:[u8;32],path:&[u8],d:usize,s:usize)->[u8;32] {
    if s==slot {node}else{let j=s-usize::from(s>slot);path[d*224+j*32..d*224+j*32+32].try_into().unwrap()}
}

fn merkle_path<H:Digest32>(hash:H,root:&[u8;32],mut index:usize,mut node:[u8;32],path:&[u8])->bool {
    for d in 0..6 {
        let slot=index%8;
        let children=[merkle_child(slot,node,path,d,0),merkle_child(slot,node,path,d,1),merkle_child(slot,node,path,d,2),merkle_child(slot,node,path,d,3),merkle_child(slot,node,path,d,4),merkle_child(slot,node,path,d,5),merkle_child(slot,node,path,d,6),merkle_child(slot,node,path,d,7)];
        node=merkle::parent_with_digest(hash,&children);index/=8;
    }
    node==*root&&index==0
}
}
