from pathlib import Path
import hashlib,json,os,re,signal,subprocess,sys,time
W=Path(__file__).resolve().parent;K=W/'input'; phase=sys.argv[1]
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def need(x,msg):
 if not x: raise SystemExit(msg)
plan=json.loads((K/'command-plan.json').read_text());pins=json.loads((K/'source-pins.json').read_text())
for f,h in pins['kit_file_sha256'].items():need(sha(K/f)==h,'kit hash mismatch '+f)
for f,h in [(plan['tools']['charon'],plan['tools']['charon_sha256']),(str(Path(plan['tools']['charon']).with_name('charon-driver')),plan['tools']['charon_driver_sha256']),(plan['tools']['aeneas'],plan['tools']['aeneas_sha256'])]:need(sha(f)==h,'tool hash mismatch '+f)
G=1024**3; cgline=Path('/proc/self/cgroup').read_text().strip();need(cgline.startswith('0::'),'unexpected cgroup')
cg=Path('/sys/fs/cgroup')/cgline[3:].lstrip('/');limits={n:(cg/n).read_text().strip() for n in ['memory.high','memory.max','memory.swap.max']}
need(limits=={'memory.high':str(1*G),'memory.max':str(2*G),'memory.swap.max':'0'},'wrong scope limits '+repr(limits))
run_dir=W/'attempt'/phase;run_dir.mkdir(parents=True,exist_ok=False)
llbc=W/'MerklePath.llbc';gen=W/'generated'
if phase=='charon': cmd=[x.replace(plan['kit_dir'],str(K)) for x in plan['charon_command']];cmd[cmd.index('--dest-file')+1]=str(llbc)
else:
 prev=json.loads((W/'attempt/charon/receipt.json').read_text());need(prev['exit_status']==0,'Charon predecessor not green')
 need(sha(llbc)==prev['outputs']['MerklePath.llbc'],'LLBC hash mismatch')
 cmd=[x.replace(plan['kit_dir'],str(K)) for x in plan['aeneas_command']];cmd[cmd.index('-dest')+1]=str(gen);cmd[-1]=str(llbc)
env=dict(os.environ);env.update(PATH='/home/dombarker/.cargo/bin:/usr/bin:/bin',RUSTUP_TOOLCHAIN=plan['tools']['rustup_toolchain'],CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR=str(W/'target'),CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS='true')
for key in ['RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_ENCODED_RUSTFLAGS','CHARON_TOOLCHAIN_IS_IN_PATH']:env.pop(key,None)
cmdj=['/usr/bin/time','-v','-o',str(run_dir/'time.log'),*cmd]
(run_dir/'command.json').write_text(json.dumps({'argv':cmdj,'cwd':str(K),'env':{k:env.get(k) for k in ['PATH','RUSTUP_TOOLCHAIN','CARGO_BUILD_JOBS','CARGO_NET_OFFLINE','CARGO_TARGET_DIR','CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS']},'phase':phase,'scope':'focused source-cut extraction; 1G high / 2G max / swap 0','source_revision':pins['source_revision'],'source_pins_sha256':sha(K/'source-pins.json')},indent=2)+'\n')
before=(cg/'memory.events').read_text();start=time.monotonic();peak=sw=0;stopped=None
with (run_dir/'stdout.log').open('x') as log:
 p=subprocess.Popen(cmdj,cwd=K,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while p.poll() is None:
  peak=max(peak,int((cg/'memory.peak').read_text()));sw=max(sw,int((cg/'memory.swap.current').read_text()))
  if time.monotonic()-start>180:
   stopped='180s timeout';os.killpg(p.pid,signal.SIGTERM)
   try:p.wait(timeout=3)
   except subprocess.TimeoutExpired:os.killpg(p.pid,signal.SIGKILL)
   break
  time.sleep(.2)
 status=p.wait()
peak=max(peak,int((cg/'memory.peak').read_text()));sw=max(sw,int((cg/'memory.swap.current').read_text()))
timing=(run_dir/'time.log').read_text();m=re.search(r'Maximum resident set size \(kbytes\):\s*(\d+)',timing)
outputs={}
if llbc.is_file():outputs['MerklePath.llbc']=sha(llbc)
if gen.exists():
 for f in gen.rglob('*'):
  if f.is_file():outputs[str(f.relative_to(W))]=sha(f)
rec={'phase':phase,'exit_status':status,'wall_seconds':round(time.monotonic()-start,3),'peak_process_rss_kib':int(m[1]) if m else None,'cgroup_memory_peak_bytes':peak,'cgroup_swap_peak_bytes':sw,'memory_events_before':before,'memory_events_after':(cg/'memory.events').read_text(),'stopped_reason':stopped,'limits':limits,'source_revision':pins['source_revision'],'source_pins_sha256':sha(K/'source-pins.json'),'outputs':outputs,'print_axioms':'N/A (Aeneas extraction only; Lean consumer required)'}
(run_dir/'receipt.json').write_text(json.dumps(rec,indent=2)+'\n');print(json.dumps(rec),flush=True);raise SystemExit(status)
