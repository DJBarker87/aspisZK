extern crate alloc;
pub mod aspis_core {
  pub mod r0 {
    #[derive(Clone, Copy, Debug, PartialEq, Eq)]
    pub enum Error {
        IndexOutOfRange,
        WrongLength,
        ZeroDenominator,
        Allocation,
        NonCanonical,
        WrongField,
        InvalidPoints,
        QuotientNotInImage,
        RankDeficient,
        Parse,
        Semantic,
        Schedule,
        Sampler,
        Commitment,
        Authentication,
        V1,
        V2,
    }
    #[path = "../../heap.rs"] pub mod heap;
  }
}
