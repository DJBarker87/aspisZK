import CompPolyFactorRawDivisionBridge
import CompPolyFactorTotalDivisionCost
import CompPolyFactorCounted
import ActualCompPolyModPowerStepCount
import Mathlib.Tactic.Ring
import Lean.Elab.Tactic.Omega

namespace ActualFactorPolynomialOperationCharge
open CompPoly Polynomial
open AspisR1.CompPolyFactorCounted
open AspisR1.CompPolyFactorTotalDivisionCost
open AspisR1.CompPolyFactorRawDivisionBridge

variable {K : Type*} [Field K] [BEq K] [LawfulBEq K]
  [DecidableEq K] [Fintype K]

/-- Per retry-site upper charge for the actual binary-recursive modular
powering call: at most `t` trial attempts, one `modPower` per attempt. -/
def modularPowerSiteCharge (q t : Nat) : Nat :=
  t * (3 * (Nat.log2 (q / 2) + 1))

/-- The factor tree's actual split-site bound composes with both cost ledgers:
the exact Raw division mirror is quartic, and the actual `modPower` binary
recursion count is logarithmic in the field-size parameter. This is an
operation-count theorem; it does not charge the internal GCD/remainder array
arithmetic or bit costs of a field operation. -/
theorem factor_division_and_modular_power_charge
    (q t fuel node : Nat) (coins : Nat → Fin t → K × K)
    (f : CPolynomial K) (hf : f.toPoly.Monic) :
    (factorCosted q t coins actualDivisionCharge fuel node f).2 +
      (factorCounted q t coins fuel node f).2 * modularPowerSiteCharge q t ≤
      (f.toPoly.natDegree - 1) *
        ((f.toPoly.natDegree + 1) *
            (100 * (f.toPoly.natDegree + 5) * (f.toPoly.natDegree + 5)) +
          modularPowerSiteCharge q t) := by
  have hdiv := actual_factor_division_cost_le q t fuel node coins f hf
  have hsites := actual_retry_calls_le_degree q t coins fuel node f hf
  have hpow := Nat.mul_le_mul_right (modularPowerSiteCharge q t) hsites
  have hsum := Nat.add_le_add hdiv hpow
  calc
    _ ≤ (f.toPoly.natDegree - 1) *
        ((f.toPoly.natDegree + 1) *
            (100 * (f.toPoly.natDegree + 5) * (f.toPoly.natDegree + 5))) +
        (f.toPoly.natDegree - 1) * modularPowerSiteCharge q t := hsum
    _ = _ := by rw [← Nat.mul_add]

/-- Per trial, the factorizer invokes at most one modular power and no more
than `t` independent trial attempts occur at a split site. -/
theorem try_attempt_modular_power_bound (q t : Nat) :
    t * (3 * (Nat.log2 (q / 2) + 1)) = modularPowerSiteCharge q t := rfl

#print axioms factor_division_and_modular_power_charge
end ActualFactorPolynomialOperationCharge
