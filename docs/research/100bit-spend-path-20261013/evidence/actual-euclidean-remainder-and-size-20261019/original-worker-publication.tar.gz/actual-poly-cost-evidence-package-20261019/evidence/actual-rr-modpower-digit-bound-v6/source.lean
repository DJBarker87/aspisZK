import RRFixedTapeRecovery
import ActualCompPolyModPowerStepCount

namespace ActualRRRecoveryModPowerDigitBound
open AspisR1.RRFixedTapeRecovery
open AspisR1.RRConcreteState RRDenseCoeffVector RRVectorRowPolynomialBridge

variable {K : Type} [Field K] [BEq K] [LawfulBEq K] [DecidableEq K]
  [Fintype K]

/-- The actual fixed-tape RR recovery has at most `d*ell` asks over the entire
recursive traversal: each child root is traversed by `collectProgram` and
`walkChildren`, and each positive-degree factor node contributes its own ask.
At each ask, `retry` consumes at most `t` trial entries. Each trial's actual
`modPower h f (q/2)` uses at most the proved logarithmic number of binary
recursion digits. This theorem is specifically an upper-bound budget for retry-trial calls to
`modPower h f (q/2)`. It does not include the separate deterministic
`rootFactor` call to `modPower ... q`, nor charge polynomial/GCD internals.
The link from this budget to a measured runtime counter remains open. -/
theorem recover_modPower_digit_bound
    (ell q t d : Nat) (s : RawState K)
    (hd : ∀ i ≤ s.maxX, (inputPolynomial s.rows i).natDegree ≤ ell)
    (hn : model s ≠ 0) (hq : q = Fintype.card K)
    (H : {i : Nat // i ∈ Finset.range (d * ell)} → Fin t → K × K) :
    (recover ell q t d s hd hn H).2 *
        (t * (3 * (Nat.log2 (q / 2) + 1))) ≤
      d * ell * (t * (3 * (Nat.log2 (q / 2) + 1))) := by
  have hcursor := recover_cursor_le ell q t d s hd hn hq H
  exact Nat.mul_le_mul_right _ hcursor

#print axioms recover_modPower_digit_bound
end ActualRRRecoveryModPowerDigitBound
