# Actual CompPoly polynomial-cost evidence

These focused Lean artifacts track selected operations in the retained CompPoly factor/recovery path. The package includes exact frozen sources, `.olean` files, receipts, and Lean logs.

The green size lemmas establish that normalization products do not increase raw-array length, the exact raw `%` implementation returns a remainder no longer than its canonical divisor, and the actual Euclidean GCD output length is bounded by the maximum input length. This supplies a closed size invariant for the Euclidean state.

The GCD cost mirror currently records a **partial coefficient-operation charge**: it includes the scaled remainder products and the exact costed monic long-division mirror. It does not yet charge trims, zero tests, array copies/control, or machine-level inversion cost. Do not cite it as total GCD runtime or full bit-PPT. The modular-power digit theorem covers retry-trial calls only; deterministic `rootFactor` exponent-q powering remains separate.

All accepted theorem axioms are listed in receipts/logs and are standard (`propext`, `Classical.choice`, `Quot.sound`) except where specifically noted in each receipt.
