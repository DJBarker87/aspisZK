# Current terminal caller canonicality with H1 (V5)

`TerminalV4CompositionCallerCanonicalV5.lean` proves that the actual generated `composition_parts_with_callers` success implies both (1) canonicality of its returned composition and (2) canonicality of the selected `h1Z`. It reuses the current-source continuation extraction and two-fold canonicality theorem, and contains the selected-width/index proof against the same current TowerAdd V1 owner to avoid mixing duplicate V1/V2 declarations.

The additional premise is pointwise canonicality of the 84-element `claims` array. This packet does not derive that premise from verifier acceptance. The theorem also retains explicit successful callback results for array construction, selectors, Poseidon, semantic evaluation, selected claims, and copy evaluation. Copy-active, residual, and mu canonicality are not claimed by this theorem.

Compile: module `AspisR1.TerminalV4CompositionCallerCanonicalV5`; exit 0; wall 1.805s; process peak RSS 3,005,664 KiB; cgroup peak 336,019,456 bytes; cgroup swap 0. Printed axioms: `[propext, Classical.choice, Quot.sound]`. The full 110-file object closure used as dependencies is included under `dependency-objects/`, along with exact direct-import hashes and raw NUC receipt/log in `attempt/`.
