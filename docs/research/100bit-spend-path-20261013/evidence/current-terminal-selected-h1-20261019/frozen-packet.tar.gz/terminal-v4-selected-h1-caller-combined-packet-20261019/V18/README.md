# Terminal v4 selected H1 canonicality (V18)

This packet freezes the V18 source, its exact OLean, direct-import pins, the transitive Lean object closure used for the NUC compile, and the original compile/audit receipts. The transitive closure is copied verbatim from `/tmp/terminal-v4-intoiter-overlay/objects` (110 OLean files); dependency sources are not all present locally, so the pinned object set is the reproducible dependency artifact. The config and admission snapshots preserve the ordered LEAN_PATH and resource gate.

V18 proves selected-column/selected-claim canonicality for the actual current generated caller source, conditional on `hclaims : ∀ i : Fin 84, Canonical (claims[i])`. The body of `selected_claim` at the current source and the legacy Funs source was separately compared byte-for-byte. This does not prove all-claims canonicality from verifier acceptance; that remains an explicit caller premise. It also does not close canonicality of copy-active, residual, or mu operands.

Compile receipt: module `AspisR1.TerminalV4SelectedClaimCanonicalV18`, exit 0, wall 2.708 s, process peak RSS 2,987,760 KiB, cgroup peak 742,522,880 bytes, cgroup swap 0. Axiom audit: four declarations, each `[propext, Classical.choice, Quot.sound]`. No global swap-byte claim is made.

`selected-claim-evidence/` and `audit-run/axiom-audit-evidence/` retain raw logs and receipts. `dependency-manifest.sha256` inventories each copied OLean. `config.json`, runner scripts and admission report are evidence of the exact selected environment; they are not intended as a launcher outside the original NUC setup.
