# Provisional selected-mask concrete bridge evidence

This directory preserves the six focused attempts for `ExtractedMaskSemanticBridgeConcrete` and the final green source/object, together with the generic bridge source/object, Lean 4.32 environment and runner, and cache-overlay/import-resolution records used by the green attempt.

The concrete target is provisional. Attempt f succeeded with two `#print axioms` reports (both standard Lean axioms: `propext`, `Classical.choice`, `Quot.sound`). Attempts a–e are retained with their original outcomes. The overlay files document object resolution; they are not source/output binding receipts for every transitive object. The queue/index files preserve the separate 102-module provenance recheck plan. This artifact alone does not establish final admission of the imported historical dependency closure or any Rust/source/security result.

Bundle archive hash for the original remote attempt collection: `e0740aafb1cf3e3ce1aa2f0bc8c7e5f240d76056dcfe59c8a78549280e26ae38`.
