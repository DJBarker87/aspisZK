import Aeneas
import ExtractedTx1Model
import AspisR1HeapFilledOverwriteTx1.TypesExternal
namespace AspisR1HeapFilledOverwriteTx1
abbrev aspis_core.r0.Error := AspisR1PublicPreparation.aspis_core.r0.Error
abbrev aspis_core.r0.Error.Allocation := AspisR1PublicPreparation.aspis_core.r0.Error.Allocation
@[reducible] def aspis_core.r0.heap.filled_overwrite.closure (T : Type) := Unit
end AspisR1HeapFilledOverwriteTx1
