import Aeneas
import AspisR1HeapFilledOverwriteTx1.Types
open Aeneas Aeneas.Std Result ControlFlow Error
set_option linter.dupNamespace false
open AspisR1HeapFilledOverwriteTx1
@[rust_fun "alloc::vec::{alloc::vec::Vec<@T>}::try_reserve_exact"]
axiom alloc.vec.Vec.try_reserve_exact
  {T : Type} (A : Type) :
  (alloc.vec.Vec T) → Std.Usize → Result ((core.result.Result Unit
    alloc.collections.TryReserveError) × (alloc.vec.Vec T))
