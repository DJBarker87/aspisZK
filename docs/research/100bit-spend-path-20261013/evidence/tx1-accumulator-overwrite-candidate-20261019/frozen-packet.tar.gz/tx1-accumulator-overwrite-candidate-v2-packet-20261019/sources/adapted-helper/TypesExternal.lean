import Aeneas
open Aeneas Aeneas.Std Result ControlFlow Error
set_option linter.dupNamespace false
@[rust_type "alloc::collections::TryReserveError"]
axiom alloc.collections.TryReserveError : Type
