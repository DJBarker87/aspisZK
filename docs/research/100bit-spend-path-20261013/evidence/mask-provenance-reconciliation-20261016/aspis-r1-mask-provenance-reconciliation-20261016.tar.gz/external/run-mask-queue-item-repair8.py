from pathlib import Path
import hashlib,json,os,subprocess,sys
ws=Path('/home/dombarker/project-offloads/aspis-r1-mask-lean432-20261015')
qpath=Path('/tmp/focused-recheck-queue.json')
indexpath=Path('/tmp/index-v1.json')
source_root=ws/'sources-recheck-uniform-repair7-v6fix1'
frozen_source_root=ws/'sources-recheck'
staging=json.loads((frozen_source_root/'queue-source-staging.json').read_text().removesuffix('\\n'))
queue=json.loads(qpath.read_text()); index=json.loads(indexpath.read_text())
qsha=hashlib.sha256(qpath.read_bytes()).hexdigest(); isha=hashlib.sha256(indexpath.read_bytes()).hexdigest()
assert qsha==staging['queue_sha256'] and isha==staging['index_sha256'], 'queue/index changed after source staging'
try: order=int(sys.argv[1])
except: raise SystemExit('usage: run-mask-queue-item.py ORDER')
assert 1 <= order <= len(queue['items'])
item=queue['items'][order-1]; assert item['order']==order
module=item['module']; src=source_root/Path(*module.split('.')); src=src.with_suffix('.lean')
assert src.is_file() and hashlib.sha256(src.read_bytes()).hexdigest()==item['source_sha256'], 'source changed'
obj=ws/'objects'/Path(*module.split('.')); obj=obj.with_suffix('.olean')
companions=[obj,Path(str(obj)+'.private'),Path(str(obj)+'.server'),obj.with_suffix('.ir')]
link_records=[]
for p in companions:
    if p.exists() and p.is_symlink():
        rec={'order':order,'module':module,'link_path':str(p),'target':str(p.resolve()),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'kind':'symlink'}
        if p == obj:
            assert rec['sha256']==item['object_sha256'], 'target object link hash differs from pinned object'
        link_records.append(rec)
    elif p.exists():
        raise SystemExit(f'refusing regular output already exists: {p}')
assert obj.is_symlink(), f'no pinned prior symlink for {module}'
log=ws/'attempts'/'queue144-link-removals.jsonl';log.parent.mkdir(exist_ok=True,parents=True)
with log.open('a') as f:
    for r in link_records: f.write(json.dumps(r,sort_keys=True)+'\n')
for p in companions:
    if p.is_symlink(): p.unlink()
label=f'queue144-repair8-{order:03d}'
env=os.environ.copy();env['MASK432_SOURCES']=str(source_root)
cmd=['python3',str(ws/'run-mask432-one-comment-aware.py'),module,label]
proc=subprocess.run(cmd,cwd=ws,env=env,text=True,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
runlog=ws/'attempts'/f'{label}-driver.log';runlog.write_text(proc.stdout)
rec={'order':order,'module':module,'label':label,'source_root':str(source_root),'queue_sha256':qsha,'index_sha256':isha,'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'exit_status_controller':proc.returncode,'link_removals':link_records,'controller_output':str(runlog)}
results=ws/'attempts'/'queue144-driver-results.jsonl'
with results.open('a') as f:f.write(json.dumps(rec,sort_keys=True)+'\n')
print(proc.stdout,end='')
print(json.dumps({'driver_order':order,'module':module,'controller_exit':proc.returncode,'attempt_log':str(runlog)}))
raise SystemExit(proc.returncode)
