# Equality-value terminal proof evidence

This bundle records seven focused Lean 4.32 targets: `EqualityValueSlice`, `EqualityValueAdapter`, `EqualityValueProduct`, `EqualityValueLoop`, `ExtractedMaskTerminalArithmetic`, `TerminalHornerCore`, and `ExtractedMaskTerminalHorner`.

There are 31 recorded attempt directories, 8 successful compile receipts (including two successful receipts for the same `EqualityValueProduct` source/output), and 7 selected final target outputs. The selected targets account for 13 `#print axioms` reports. The slice target has zero reports; the remaining targets report standard Lean axioms only. Each attempt retains its source snapshot, receipt, log, time record, import pins, and axiom report. Failures remain in the bundle, including the broad `SourceHorner` import attempt that exited 134 under the 6 GiB cap. That attempt was replaced by the minimal `TerminalHornerCore` declaration slice, without an unchanged retry.

All runs used Lean 4.32.0, one at a time, with `MemoryHigh=4G`, `MemoryMax=6G`, `MemorySwapMax=0`, `TasksMax=128`, and a 300 second timeout. `process_swaps` is reported from the attempt receipts. Mathlib artifacts are pinned by the receipts but not copied into the compact object archive.

The equality-value slice’s four declaration bodies match the retained generated source blocks after stripping surrounding whitespace only. The source of those generated blocks and the current selected-mask Funs module are distinct pins; the latter is an imported dependency and does not contain the equality-value blocks. `TerminalHornerCore` retains three generic declaration blocks from `SourceMixing` with a small import/namespace wrapper; `provenance/terminal-horner-core-source-slice-manifest.json` records the original source hash and block hashes. Neither selected final Horner target imports the old `SourceMixing` object. Its archived object is retained solely as failed-attempt evidence. The imported `R0P.SemDecision` object is reconciled with its already published, source-bound successful queue144 target 067; its original receipt and snapshot are included under `provenance/semdecision-prior-success`.

These are focused mathematical/compiler results. They do not establish a Rust-source refinement, full selected-mask correspondence, or protocol/security closure.

Run `python3 verify_bundle.py` from this directory to check the checksum list, target source hashes, selected output object hashes, and archive member hashes.
