#!/usr/bin/env python3
import hashlib, json, os, tarfile
ROOT=os.path.dirname(os.path.abspath(__file__))
def sha(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1<<20),b''): h.update(chunk)
    return h.hexdigest()
# Check all entries listed in SHA256SUMS.
for line in open(os.path.join(ROOT,'SHA256SUMS')):
    expected, rel=line.rstrip('\n').split('  ',1)
    path=os.path.join(ROOT,rel)
    assert os.path.isfile(path), f'missing checksum member: {rel}'
    assert sha(path)==expected, f'checksum mismatch: {rel}'
m=json.load(open(os.path.join(ROOT,'manifest.json')))
assert m['selected_target_count']==7
assert m['selected_axiom_report_count']==13
for target, rec in m['targets'].items():
    p=os.path.join(ROOT,'sources',target+'.lean')
    assert sha(p)==rec['source_sha256'], f'source hash mismatch: {target}'
    obj=os.path.join(ROOT,'objects',target+'.olean')
    assert sha(obj)==rec['output_sha256'], f'object hash mismatch: {target}'
# The archive must contain the same stored object files byte-for-byte.
with tarfile.open(os.path.join(ROOT,'objects.tar.gz'),'r:gz') as tf:
    members={x.name:x for x in tf.getmembers() if x.isfile()}
    for base,dirs,files in os.walk(os.path.join(ROOT,'objects')):
        for fn in files:
            p=os.path.join(base,fn); rel=os.path.relpath(p,ROOT)
            member=members.get(rel); assert member, f'archive missing {rel}'
            f=tf.extractfile(member); assert f and hashlib.sha256(f.read()).hexdigest()==sha(p), f'archive mismatch {rel}'
print('bundle integrity PASS')
