#!/usr/bin/env python3
"""Copy three named G declarations verbatim; supply only module framing."""
import hashlib, json, re
from pathlib import Path

ROOT = Path('/Users/dominic/ZK/.worktrees/100bit-spend-path')
SOURCE = ROOT / 'docs/research/100bit-spend-path-20261013/evidence/terminal-qm31-extraction-20261016/attempt-g-name-adapt/output/generated/AspisR1SelectedMaskProbe/Funs.lean'
PIN = '8a612e11ee96c7a5a909c40bc09ef1f99e4e515b2b129f64059b5c033aa426fb'
OUT = Path(__file__).resolve().parent
sha = lambda b: hashlib.sha256(b).hexdigest()
raw = SOURCE.read_bytes()
assert sha(raw) == PIN
text = raw.decode()
starts = [m.start() for m in re.finditer(r'(?m)^/--', text)]
blocks = [text[a:b] for a, b in zip(starts, starts[1:] + [len(text)])]
names = ['field.M31.reduce_u62', 'state_only_poseidon.extension_from_raw_limbs',
         'state_only_poseidon.extension_limbs']
selected = []
for name in names:
    found = [b for b in blocks if re.search(r'(?m)^def\s+' + re.escape(name) + r'(?=\s|\()', b)]
    assert len(found) == 1, (name, len(found))
    selected.append((name, found[0]))
prelude = '''-- Exact named declaration slice from terminal extraction G.
import AspisR1SelectedMaskProbe.Funs
open Aeneas Aeneas.Std Result ControlFlow Error
set_option linter.dupNamespace false
set_option linter.hashCommand false
set_option linter.unusedVariables false
namespace AspisR1SelectedMaskProbe

'''
output = (prelude + ''.join(b for _, b in selected) + '\nend AspisR1SelectedMaskProbe\n').encode()
(OUT/'RawPoseidonExtensionSlice.lean').write_bytes(output)
manifest = {
    'scope': 'Generated component slice only; not the terminal or row wrapper',
    'input': {'path': str(SOURCE), 'sha256': PIN},
    'selected_declarations': [{'name': name, 'block_sha256': sha(b.encode()),
        'start_line': text[:text.index(b)].count('\n')+1,
        'end_line': text[:text.index(b)+len(b)].count('\n')} for name,b in selected],
    'output_sha256': sha(output),
    'framing': 'Only module import/prelude and namespace delimiters supplied separately; declaration blocks copied verbatim.',
    'shared_dependency': 'Existing selected-mask Funs; these three names must not already be defined there.',
    'boundary': 'No from_fn, map, callback or parent loop semantics supplied.'}
(OUT/'include-manifest.json').write_text(json.dumps(manifest, indent=2)+'\n')
print(json.dumps(manifest, indent=2))
