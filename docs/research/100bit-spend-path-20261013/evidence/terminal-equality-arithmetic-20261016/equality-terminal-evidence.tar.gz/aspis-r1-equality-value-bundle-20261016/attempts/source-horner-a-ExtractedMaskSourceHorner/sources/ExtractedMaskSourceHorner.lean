import Mathlib

/-!
A two-lemma source slice of the generic Horner identities already checked in
`LiteralSemanticPolynomialChecks` (source SHA bbc09b9f6edc92fc75370956857cdb41e157b156fd08f31ab0c34cec298b6b86).
This avoids importing the older generated `AspisV8R17.SourceMixing` graph,
which has no source-bound Lean 4.32 object in the current workspace.
-/
set_option autoImplicit false

namespace AspisR1.ExtractedMaskSourceHorner

open scoped BigOperators

def sourceHorner {F : Type*} [Field F] (x : F) (cs : List F) : F :=
  cs.reverse.foldl (fun acc c => acc * x + c) 0

theorem sourceHorner_cons {F : Type*} [Field F] (x c : F) (cs : List F) :
    sourceHorner x (c :: cs) = sourceHorner x cs * x + c := by
  simp [sourceHorner, List.reverse_cons, List.foldl_append]

theorem sourceHorner_ofFn_eq_sum {F : Type*} [Field F]
    (n : Nat) (cs : Fin n → F) (x : F) :
    sourceHorner x (List.ofFn cs) = ∑ i, cs i * x ^ i.val := by
  induction n with
  | zero => simp [sourceHorner]
  | succ n ih =>
      rw [List.ofFn_succ, sourceHorner_cons, ih]
      simp only [Fin.sum_univ_succ, Fin.val_zero, pow_zero, mul_one,
        Fin.val_succ, pow_succ]
      simp only [← mul_assoc, ← Finset.sum_mul]
      exact add_comm _ _

#print axioms sourceHorner_cons
#print axioms sourceHorner_ofFn_eq_sum

end AspisR1.ExtractedMaskSourceHorner
