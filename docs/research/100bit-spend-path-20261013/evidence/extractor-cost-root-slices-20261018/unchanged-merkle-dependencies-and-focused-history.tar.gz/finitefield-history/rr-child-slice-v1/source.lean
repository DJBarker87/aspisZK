import RRRootMultiplicityTaylorV3
import Mathlib.Algebra.Polynomial.Taylor

open Polynomial
noncomputable section

namespace RRChildSliceTaylor

variable {K : Type*} [Field K]

/-- The coefficient of `X^n` in the child polynomial after substituting
`Y ↦ a + X*Y` into `Σ_i X^i g_i(Y)`. -/
def childCoeff (g : Nat → K[X]) (a : K) (n : Nat) : K[X] :=
  ∑ i ∈ Finset.range (n + 1),
    C ((Polynomial.taylor a (g i)).coeff (n - i)) * X ^ (n - i)

theorem childCoeff_natDegree_le (g : Nat → K[X]) (a : K) (n : Nat)
    (hne : childCoeff g a n ≠ 0) :
    (childCoeff g a n).natDegree ≤ n := by
  unfold childCoeff
  apply Polynomial.natDegree_le_iff_coeff_zero.mpr
  intro k hk
  simp only [Polynomial.coeff_sum, Finset.sum_eq_zero_iff]
  intro i hi
  simp only [Polynomial.coeff_C_mul_X_pow]
  split
  · rename_i h
    omega
  · rfl

theorem childCoeff_top_coeff (g : Nat → K[X]) (a : K) (n : Nat) :
    (childCoeff g a n).coeff n = (Polynomial.taylor a (g 0)).coeff n := by
  unfold childCoeff
  simp [Polynomial.coeff_sum, Polynomial.coeff_C_mul_X_pow]

end RRChildSliceTaylor
