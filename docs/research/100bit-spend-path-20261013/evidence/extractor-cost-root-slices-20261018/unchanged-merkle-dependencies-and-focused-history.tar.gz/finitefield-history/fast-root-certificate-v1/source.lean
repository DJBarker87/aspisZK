import Mathlib.FieldTheory.Finite.Basic
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Algebra.Polynomial.Roots

open Polynomial
noncomputable section

universe u
variable {K : Type u} [Field K] [Fintype K] [DecidableEq K]

def finiteFieldRootModulus (K : Type u) [Field K] [Fintype K] : K[X] :=
  X ^ Fintype.card K - X

def linearRootsProduct (s : Finset K) : K[X] :=
  s.prod fun a => X - C a

def CompleteRootCertificate (p : K[X]) (s : Finset K) : Prop :=
  EuclideanDomain.gcd p (finiteFieldRootModulus K) = linearRootsProduct s

theorem complete_root_certificate_iff
    (p : K[X]) (s : Finset K)
    (hcert : CompleteRootCertificate p s) (x : K) :
    IsRoot p x ↔ x ∈ s := by
  constructor
  · intro hx
    have hpx : X - C x ∣ p := Polynomial.dvd_iff_isRoot.mpr hx
    have hfx : X - C x ∣ finiteFieldRootModulus K := by
      apply Polynomial.dvd_iff_isRoot.mpr
      rw [IsRoot, finiteFieldRootModulus, eval_sub, eval_pow, eval_X]
      rw [FiniteField.pow_card]
      simp
    have hdiv : X - C x ∣ EuclideanDomain.gcd p (finiteFieldRootModulus K) :=
      EuclideanDomain.dvd_gcd hpx hfx
    rw [hcert] at hdiv
    have hprod : IsRoot (linearRootsProduct s) x :=
      Polynomial.dvd_iff_isRoot.mp hdiv
    rw [IsRoot, linearRootsProduct, eval_prod] at hprod
    simp only [eval_sub, eval_X, eval_C] at hprod
    rcases Finset.prod_eq_zero_iff.mp hprod with ⟨a, ha, hax⟩
    have hxa : x = a := sub_eq_zero.mp hax
    simpa [hxa] using ha
  · intro hx
    have hprod : IsRoot (linearRootsProduct s) x := by
      rw [IsRoot, linearRootsProduct, eval_prod]
      exact Finset.prod_eq_zero_iff.mpr ⟨x, hx, by simp⟩
    have hline : X - C x ∣ EuclideanDomain.gcd p (finiteFieldRootModulus K) := by
      rw [hcert]
      exact Polynomial.dvd_iff_isRoot.mpr hprod
    exact Polynomial.dvd_iff_isRoot.mp
      (hline.trans (EuclideanDomain.gcd_dvd_left _ _))

theorem complete_root_certificate_card_le_degree
    (p : K[X]) (hp : p ≠ 0) (s : Finset K)
    (hcert : CompleteRootCertificate p s) : s.card ≤ p.natDegree := by
  apply Polynomial.card_le_degree_of_subset_roots
  intro a ha
  rw [Polynomial.mem_roots hp]
  exact (complete_root_certificate_iff p s hcert a).2 (Finset.mem_val.mp ha)

#print axioms complete_root_certificate_iff
#print axioms complete_root_certificate_card_le_degree
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.Algebra.Polynomial.Div
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Data.Nat.BinaryRec

open Polynomial
noncomputable section

universe u
variable {K : Type u} [Field K] [Fintype K] [DecidableEq K]

def polynomialModPower (a m : K[X]) : Nat → K[X] :=
  Nat.binaryRec 1 (fun b _ z => (z * z * (if b then a else 1)) %ₘ m)

theorem polynomialModPower_congruent (a m : K[X]) (hm : m.Monic)
    (hdeg : (0 : WithBot Nat) < degree m) (n : Nat) :
    m ∣ polynomialModPower a m n - a ^ n := by
  refine Nat.binaryRec (motive := fun k => m ∣ polynomialModPower a m k - a ^ k) ?_ ?_ n
  · simp [polynomialModPower]
  · intro b n ih
    change m ∣
      (Nat.binaryRec 1 (fun b _ z => (z * z * (if b then a else 1)) %ₘ m)
        (Nat.bit b n)) - a ^ Nat.bit b n
    have hbase :
        (fun b _ z => (z * z * (if b then a else 1)) %ₘ m) false 0 1 = 1 := by
      simp only [Bool.false_eq_true, ↓reduceIte, mul_one, one_mul]
      rw [(Polynomial.modByMonic_eq_self_iff hm).2 ?_]
      simpa using hdeg
    rw [Nat.binaryRec_eq b n (Or.inl hbase)]
    have hpow : a ^ Nat.bit b n = a ^ n * a ^ n * (if b then a else 1) := by
      calc
        a ^ Nat.bit b n = a ^ (2 * n + b.toNat) := by rw [Nat.bit_val]
        _ = a ^ n * a ^ n * (if b then a else 1) := by
          cases b <;> simp [pow_add, pow_mul, mul_pow, pow_two, Nat.mul_comm] <;> ring
    have hprod : m ∣
        polynomialModPower a m n * polynomialModPower a m n * (if b then a else 1) -
          (a ^ n * a ^ n * (if b then a else 1)) := by
      have hfac :
          polynomialModPower a m n * polynomialModPower a m n * (if b then a else 1) -
            (a ^ n * a ^ n * (if b then a else 1)) =
            (polynomialModPower a m n - a ^ n) *
              ((polynomialModPower a m n + a ^ n) * (if b then a else 1)) := by ring
      rw [hfac]
      exact dvd_mul_of_dvd_left ih _
    have hmod : m ∣
        (polynomialModPower a m n * polynomialModPower a m n * (if b then a else 1)) %ₘ m -
          (polynomialModPower a m n * polynomialModPower a m n * (if b then a else 1)) :=
      Polynomial.dvd_modByMonic_sub _ _
    have htotal : m ∣
        ((polynomialModPower a m n * polynomialModPower a m n * (if b then a else 1)) %ₘ m) -
          a ^ Nat.bit b n := by
      rw [hpow]
      have hsum :
          ((polynomialModPower a m n * polynomialModPower a m n * (if b then a else 1)) %ₘ m) -
            (polynomialModPower a m n * polynomialModPower a m n * (if b then a else 1)) +
            ((polynomialModPower a m n * polynomialModPower a m n * (if b then a else 1)) -
              (a ^ n * a ^ n * (if b then a else 1))) =
          ((polynomialModPower a m n * polynomialModPower a m n * (if b then a else 1)) %ₘ m) -
            (a ^ n * a ^ n * (if b then a else 1)) := by ring
      rw [← hsum]
      exact dvd_add hmod hprod
    simpa [polynomialModPower] using htotal

theorem polynomialModPower_remainder (a m : K[X]) (hm : m.Monic)
    (hdeg : (0 : WithBot Nat) < degree m) (n : Nat) :
    polynomialModPower a m n %ₘ m = a ^ n %ₘ m := by
  apply Polynomial.modByMonic_eq_of_dvd_sub hm
  exact polynomialModPower_congruent a m hm hdeg n

#print axioms polynomialModPower_congruent
#print axioms polynomialModPower_remainder

def finiteFieldFastRootResidue (p : K[X]) : K[X] :=
  (polynomialModPower (X : K[X]) (Fintype.card K) p - X) %ₘ p

def CompleteFastRootCertificate (p : K[X]) (s : Finset K) : Prop :=
  EuclideanDomain.gcd p (finiteFieldFastRootResidue p) = linearRootsProduct s

theorem finiteFieldFastRootResidue_eq_modulus (p : K[X]) (hp : p.Monic)
    (hdeg : (0 : WithBot Nat) < degree p) :
    finiteFieldFastRootResidue p %ₘ p = finiteFieldRootModulus K %ₘ p := by
  rw [finiteFieldFastRootResidue, Polynomial.sub_modByMonic, Polynomial.sub_modByMonic,
    polynomialModPower_remainder (X : K[X]) p hp hdeg (Fintype.card K)]

theorem fast_complete_root_certificate_iff (p : K[X]) (hp : p.Monic)
    (hdeg : (0 : WithBot Nat) < degree p) (s : Finset K)
    (hcert : CompleteFastRootCertificate p s) (x : K) :
    IsRoot p x ↔ x ∈ s := by
  constructor
  · intro hx
    have hmodroot : IsRoot (finiteFieldRootModulus K) x := by
      rw [IsRoot, finiteFieldRootModulus, eval_sub, eval_pow, eval_X]
      rw [FiniteField.pow_card]
      simp
    have hrem := finiteFieldFastRootResidue_eq_modulus p hp hdeg
    have hdivres : p ∣ finiteFieldFastRootResidue p - finiteFieldRootModulus K := by
      have hres1 : p ∣ finiteFieldFastRootResidue p %ₘ p - finiteFieldFastRootResidue p :=
        Polynomial.dvd_modByMonic_sub _ _
      have hres2 : p ∣ finiteFieldRootModulus K %ₘ p - finiteFieldRootModulus K :=
        Polynomial.dvd_modByMonic_sub _ _
      have hmid : p ∣ finiteFieldFastRootResidue p %ₘ p - finiteFieldRootModulus K %ₘ p := by
        rw [hrem]
        exact dvd_zero p
      have hres1' : p ∣ finiteFieldFastRootResidue p - finiteFieldFastRootResidue p %ₘ p := by
        have := dvd_neg.mpr hres1
        simpa only [neg_sub] using this
      have hsum :
          finiteFieldFastRootResidue p - finiteFieldRootModulus K =
            (finiteFieldFastRootResidue p - finiteFieldFastRootResidue p %ₘ p) +
              (finiteFieldFastRootResidue p %ₘ p - finiteFieldRootModulus K %ₘ p) +
              (finiteFieldRootModulus K %ₘ p - finiteFieldRootModulus K) := by ring
      rw [hsum]
      exact dvd_add (dvd_add hres1' hmid) hres2
    have hlin : X - C x ∣ p := Polynomial.dvd_iff_isRoot.mpr hx
    have hlinres : X - C x ∣ finiteFieldFastRootResidue p := by
      have hdiff := hlin.trans hdivres
      have hdiffroot : IsRoot (finiteFieldFastRootResidue p - finiteFieldRootModulus K) x :=
        Polynomial.dvd_iff_isRoot.mp hdiff
      have heval : (finiteFieldFastRootResidue p).eval x =
          (finiteFieldRootModulus K).eval x := by
        exact sub_eq_zero.mp (by simpa [IsRoot] using hdiffroot)
      rw [heval]
      exact Polynomial.dvd_iff_isRoot.mpr hmodroot
    have hdiv : X - C x ∣ EuclideanDomain.gcd p (finiteFieldFastRootResidue p) :=
      EuclideanDomain.dvd_gcd hlin hlinres
    rw [hcert] at hdiv
    have hprod : IsRoot (linearRootsProduct s) x := Polynomial.dvd_iff_isRoot.mp hdiv
    rw [IsRoot, linearRootsProduct, eval_prod] at hprod
    simp only [eval_sub, eval_X, eval_C] at hprod
    rcases Finset.prod_eq_zero_iff.mp hprod with ⟨a, ha, hax⟩
    have hxa : x = a := sub_eq_zero.mp hax
    simpa [hxa] using ha
  · intro hx
    have hprod : IsRoot (linearRootsProduct s) x := by
      rw [IsRoot, linearRootsProduct, eval_prod]
      exact Finset.prod_eq_zero_iff.mpr ⟨x, hx, by simp⟩
    have hline : X - C x ∣ EuclideanDomain.gcd p (finiteFieldFastRootResidue p) := by
      rw [hcert]
      exact Polynomial.dvd_iff_isRoot.mpr hprod
    exact Polynomial.dvd_iff_isRoot.mp
      (hline.trans (EuclideanDomain.gcd_dvd_left _ _))

#print axioms finiteFieldFastRootResidue_eq_modulus
#print axioms fast_complete_root_certificate_iff
