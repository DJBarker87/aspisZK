import RRRootMultiplicityTaylorV3
import RRChildSliceTaylorV4

open Polynomial
noncomputable section
namespace RRChildSliceTaylor
variable {K : Type*} [Field K]

theorem exists_child_slice_bounded_by_rootMultiplicity
    (g : Nat → K[X]) (a : K) (p : K[X]) (hp : p ≠ 0)
    (hzero : g 0 = p) :
    ∃ v, v ≤ p.rootMultiplicity a ∧ childCoeff g a v ≠ 0 ∧
      (childCoeff g a v).natDegree ≤ p.rootMultiplicity a := by
  have htop : childCoeff g a (p.rootMultiplicity a) ≠ 0 := by
    rw [childCoeff_top_coeff, hzero]
    exact RRRootMultiplicityTaylor.taylor_coeff_ne_zero_at_rootMultiplicity p a hp
  let v := Nat.find ⟨p.rootMultiplicity a, htop⟩
  have hv : childCoeff g a v ≠ 0 := Nat.find_spec ⟨p.rootMultiplicity a, htop⟩
  have hbound : v ≤ p.rootMultiplicity a := Nat.find_min' ⟨p.rootMultiplicity a, htop⟩ htop
  refine ⟨v, hbound, hv, ?_⟩
  exact (childCoeff_natDegree_le g a v).trans hbound

end RRChildSliceTaylor
