# Prepared-mask multiplier audit (read-only)

Worktree: `/Users/dominic/ZK/.worktrees/100bit-spend-path`.

Audited current drafts:

- `lean/ExtractedMaskPreparedState.lean` SHA-256 `df7d7c33573821d097fd863ad6a680dee15e486211301be0efa8dc3900e7614e`
- `lean/ExtractedMaskPreparedMul.lean` SHA-256 `c3a640dfe6afdb16f432f2e52a8e2769032fab303d50c8bd78df8133479ab43c`
- Generated attempt-b `Funs.lean` SHA-256 `a9798fcd2e62b3443745dbc2ae9e2694cd18975e8f509ffe54d7e2c38402661a`

## Findings

`PreparedFor` captures the complete data read by the extracted prepared multiplier. The actual `new` implementation at generated lines 446–468 stores exactly three 3-element arrays: `(x.c0.a, x.c0.b, add(x.c0.a,x.c0.b))`, the corresponding `x.c1` array, and the array for `CM31.add x.c0 x.c1`. `PreparedFor` records the successful CM addition and canonicality of that combined value, `ComponentFor` for each array, and equality of the entire outer array with `[a,b,c]`. `ComponentFor` fixes each entire inner array to `[x.a,x.b,s]` and records the modular-sum value and canonical bound for `s`. Thus the invariant covers all indices 0, 1, and 2 that the generated closure reads; no extra unused-cell premise is missing.

`current_component_new` matches the extracted constructor closure at generated lines 446–454: the retained `current_add_mod` success/value/bound theorem supplies the third cell, and the closure creates the same `Array.make`. `current_prepared_new` composes those three results with the outer `Array.make` and the extracted `CM31.add` success for `c0+c1`. I found no ordering mismatch.

The multiplication composition also matches the generated reads. At lines 398–415 the closure reads exactly the three stored cells and computes the Karatsuba terms `x.a*y.a`, `x.b*y.b`, and `(x.a+x.b)*(y.a+y.b)`, then subtracts in the prescribed order. `current_component_mul_words` uses `ComponentFor` for the stored third cell, the existing `current_add_mod` for the runtime right-hand sum, and current M31 multiplication/subtraction modular contracts. This yields the same `mulWords` used by `ExtractedMaskCM31Mul.current_mul_words`. `component_eq_mul` then identifies results by both canonical limb values. At lines 420–439 the outer method reads all three arrays, invokes the closure on `(a,y.c0)`, `(b,y.c1)`, and `(c, CM31.add y.c0 y.c1)`, then applies `mul_by_r` and the same add/sub sequence as ordinary `QM31.mul` (generated lines 930–945). `prepared_mul_eq` supplies precisely those three closure equalities and the right-hand sum; `prepared_mul_exact` reuses the existing `current_qm_mul_exact` theorem rather than reproving tower arithmetic.

The generated caller at lines 592–628 constructs `prepared_linear` once with `PreparedQm31Multiplier.new linear`, then repeatedly calls `.mul prepared_linear shared` in loop2. The present draft proves constructor-plus-one-multiply correctness under explicit canonicality of the input and multiplier. It does not yet establish loop-level selected-mask equivalence, which is outside these two modules.

## Exact items to verify during the focused compile

I found no statement or invariant change needed. If elaboration fails, keep repairs at proof plumbing:

1. The generated inner-array reads are discharged by `ExtractedMaskArrayThree.index0/index1/index2`; the outer array reads use the same helpers after `harr` rewrites it to `Array.make 3 [a,b,c]`.
2. In `prepared_mul_eq`, retain `ht` (stored precomputation `x.c0+x.c1`) and `hs` (runtime `y.c0+y.c1`) as separate rewrites. They serve different operand sides.
3. The value-pair equality in `component_eq_mul` is enough because `UScalar.val_eq_imp` proves equality of each M31 limb; do not replace it with an assumption that prepared and ordinary operation results are definitionally equal.

This is a structural/source-generated operation audit only; it makes no Rust-to-Lean source refinement or verifier-acceptance claim.
