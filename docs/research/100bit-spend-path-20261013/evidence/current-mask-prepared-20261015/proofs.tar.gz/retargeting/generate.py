#!/usr/bin/env python3
"""Retarget nine checked proof sources by exactly two literal substitutions."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

ROOT = Path('/Users/dominic/ZK/.worktrees/100bit-spend-path')
SOURCE_DIR = ROOT / 'docs/research/100bit-spend-path-20261013/lean'
OUT = Path(__file__).resolve().parent
NAMES = [
    'M31AddSub', 'ReducerOps', 'Reducer', 'TowerAdd', 'CM31Mul',
    'QM31Mul', 'QM31Tower', 'QM31Exact', 'QM31Equality',
]
REPLACEMENTS = (
    ('AspisR1Qm31ArithmeticProbe', 'AspisR1SelectedMaskProbe'),
    ('ExtractedCurrent', 'ExtractedMask'),
)

def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()

def expected(old: bytes) -> bytes:
    text = old.decode('utf-8')
    for before, after in REPLACEMENTS:
        text = text.replace(before, after)
    return text.encode('utf-8')

def build_manifest() -> dict:
    entries = []
    for suffix in NAMES:
        old_name = f'ExtractedCurrent{suffix}.lean'
        new_name = f'ExtractedMask{suffix}.lean'
        old = (SOURCE_DIR / old_name).read_bytes()
        new = expected(old)
        entries.append({
            'source_path': str((SOURCE_DIR / old_name).relative_to(ROOT)),
            'source_sha256': sha(old),
            'output_path': new_name,
            'output_sha256': sha(new),
            'bytes_unchanged_outside_two_literal_replacements': True,
        })
    return {
        'description': 'Mechanical namespace/module retargeting only; no Lean compilation performed.',
        'source_worktree': str(ROOT),
        'replacements_in_order': [{'from': a, 'to': b} for a, b in REPLACEMENTS],
        'files': entries,
    }

def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument('--check', action='store_true', help='verify outputs and manifest against current source inputs')
    args = p.parse_args()
    manifest = build_manifest()
    manifest_path = OUT / 'manifest.json'
    if args.check:
        for entry in manifest['files']:
            out = OUT / entry['output_path']
            want = expected((ROOT / entry['source_path']).read_bytes())
            if not out.exists() or out.read_bytes() != want:
                raise SystemExit(f'output mismatch: {entry["output_path"]}')
        if not manifest_path.exists() or manifest_path.read_text() != json.dumps(manifest, indent=2, sort_keys=True) + '\n':
            raise SystemExit('manifest mismatch')
        print(f'check OK: {len(manifest["files"])} files')
        return 0
    for entry in manifest['files']:
        old = (ROOT / entry['source_path']).read_bytes()
        (OUT / entry['output_path']).write_bytes(expected(old))
    manifest_path.write_text(json.dumps(manifest, indent=2, sort_keys=True) + '\n')
    print(f'generated {len(manifest["files"])} files')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
