from pathlib import Path
import hashlib, json
root=Path('/tmp/ExtractedMaskQmPackBase4Kit-20261016')
groot=Path('/Users/dominic/ZK/.worktrees/100bit-spend-path/docs/research/100bit-spend-path-20261013/evidence/terminal-qm31-extraction-20261016/attempt-g-name-adapt/output/generated/AspisR1SelectedMaskProbe')
types=groot/'Types.lean'; funs=groot/'Funs.lean'
tb=types.read_bytes(); fb=funs.read_bytes()
def extract(data,token):
    tok=token.encode(); assert data.count(tok)==1,token
    p=data.index(tok); s=data.rfind(b'/--',0,p); e=data.find(b'/--',p)
    assert s>=0 and e>p
    return s,e,data[s:e]
t1,e1,b1=extract(tb,'def field.qm31_pack_base4.closure := Unit')
f1,e2,b2=extract(fb,'def field.qm31_pack_base4.closure.Insts.CoreOpsFunctionFnTupleM31U64.call')
f2,e3,b3=extract(fb,'def field.qm31_pack_base4 (values : Slice field.QM31) : Result field.QM31 := do')
assert b'core.array.from_fn' not in b3 and b'array_from_fn_copy' not in b3
header=b'''-- Exact generated declarations from the pinned G packer output; framing only.\nimport Aeneas.Std\nimport Aeneas.Tactic.RustAttributes\nimport AspisR1SelectedMaskProbe.Types\nimport AspisR1SelectedMaskProbe.Funs\nopen Aeneas Aeneas.Std Result ControlFlow Error\nset_option linter.dupNamespace false\nset_option linter.hashCommand false\nset_option linter.unusedVariables false\nset_option maxHeartbeats 1000000\nset_option maxRecDepth 2048\nnamespace AspisR1SelectedMaskProbe\n\n'''
out=root/'Qm31PackBase4Slice.lean'
out.write_bytes(header+b1+b'\n'+b2+b'\n'+b3+b'\nend AspisR1SelectedMaskProbe\n')
manifest={
 'kind':'source-only exact generated declaration slice; no compilation claimed',
 'generated_revision':'terminal-qm31-extraction-20261016 attempt-g-name-adapt',
 'source_files':{
  'Types':{'path':str(types),'sha256':hashlib.sha256(tb).hexdigest()},
  'Funs':{'path':str(funs),'sha256':hashlib.sha256(fb).hexdigest()}},
 'declarations':[
  {'name':'field.qm31_pack_base4.closure','source_file':'Types','byte_range':[t1,e1],'sha256':hashlib.sha256(b1).hexdigest()},
  {'name':'field.qm31_pack_base4.closure.Insts.CoreOpsFunctionFnTupleM31U64.call','source_file':'Funs','byte_range':[f1,e2],'sha256':hashlib.sha256(b2).hexdigest()},
  {'name':'field.qm31_pack_base4','source_file':'Funs','byte_range':[f2,e3],'sha256':hashlib.sha256(b3).hexdigest()}],
 'output':str(out),'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),
 'imports':['AspisR1SelectedMaskProbe.Types','AspisR1SelectedMaskProbe.Funs'],
 'import_notes':'These are the maintained selected-mask modules, not the full G-generated Types/Funs pair. The slice adds only the G pack-closure type, its Fn call, and qm31_pack_base4; it does not import the full G module.'}
(root/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
(root/'README.md').write_text('''# Exact current qm31_pack_base4 source slice\n\nThis source-only slice copies three named generated declarations from the pinned G Aeneas output: the pack closure alias, its `Fn` conversion call, and the current `field.qm31_pack_base4` function. Declaration byte spans are unchanged; only module framing/imports are added. It uses the maintained selected-mask `Types` and `Funs` modules for shared field/runtime declarations and does not import the large G generated files.\n\nThis is not a proof result. See `manifest.json` for source revisions, spans, and hashes.\n''')
print(json.dumps(manifest,indent=2))
