# Exact current qm31_pack_base4 source slice

This source-only slice copies three named generated declarations from the pinned G Aeneas output: the pack closure alias, its `Fn` conversion call, and the current `field.qm31_pack_base4` function. Declaration byte spans are unchanged; only module framing/imports are added. It uses the maintained selected-mask `Types` and `Funs` modules for shared field/runtime declarations and does not import the large G generated files.

This is not a proof result. See `manifest.json` for source revisions, spans, and hashes.
