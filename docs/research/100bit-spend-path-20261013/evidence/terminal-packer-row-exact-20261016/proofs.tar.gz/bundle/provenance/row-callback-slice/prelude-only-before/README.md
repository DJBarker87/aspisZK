# G row callback source slice

`RowCallbackSlice.lean` is a deterministic, minimal source slice for the generated G callback used by the single-limb output-0 theorem. It contains the exact closure type alias from G `Types.lean`, then the exact `FnMut.call_mut`, `FnOnce.call_once`, and `FnOnce`/`FnMut` trait-instance spans from G `Funs.lean`. The definitions are byte-identical source slices; only the module/import prelude and namespace wrapper needed to make the extract standalone were supplied.

The slice has only `import Aeneas`. It defines no field types or arithmetic helpers. Its explicit closure alias is `Array (Array Std.U32 4#usize) 4#usize × Std.Usize`, matching G. The callback reads four rows at the supplied limb index, widens each U32 to U64, applies the selected output branch's checked arithmetic, and returns the same closure state.

`include-manifest.json` pins both complete generated source files, the exact selected line spans and span hashes, the assembled slice hash, and its runtime API dependencies. `extract_slice.py` deterministically re-extracts the spans and verifies their inclusion. This is a source-slice artifact only; it has not been compiled and proves no full `from_fn`, `Array.map`, or row-helper result. Do not import it together with G's whole `Funs.lean`, which defines the same names.
