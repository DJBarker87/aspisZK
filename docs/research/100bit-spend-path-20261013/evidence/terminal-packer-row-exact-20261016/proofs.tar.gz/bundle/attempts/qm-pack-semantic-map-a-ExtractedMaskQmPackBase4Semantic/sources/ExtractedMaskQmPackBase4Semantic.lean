import ExtractedMaskQmPackBase4Arithmetic
import ExtractedMaskSemanticBridgeConcrete

/-! Transport of the exact mathematical four-QM31 packing formula into the
existing concrete `WideExact`/`R0P.pack4` model. This is algebraic plumbing,
not a source refinement result. -/
set_option autoImplicit false
namespace AspisR1.ExtractedMaskQmPackBase4Semantic

open AspisV8R15.ExactTowerBase

abbrev CurrentQM := AspisR1.ExtractedMaskQM31Exact.CurrentQM
abbrev ExactQM := AspisV8R15.ExactTowerBase.QM31Exact
abbrev Wide := AspisWideTower.WideExact
abbrev PackB := AspisR1.ExtractedMaskSemanticBridgeConcrete.packBasis
abbrev f := AspisR1.ExtractedMaskSemanticBridgeConcrete.qm31ToWide

theorem map_mathPack (v : Fin 4 → CurrentQM) :
    f (AspisR1.ExtractedMaskQmPackBase4Arithmetic.mathematicalPack v) =
      R0P.pack4 PackB (fun j =>
        f (AspisR1.ExtractedMaskQM31Exact.decode (v j))) := by
  have hi : f AspisR1.ExtractedMaskQmPackBase4Arithmetic.iBasis = PackB.i := by
    have h := AspisR1.ExtractedMaskSemanticBridgeConcrete.basisCompatible
      (1 : Fin 4)
    simpa [AspisR1.ExtractedMaskQmPackBase4Arithmetic.iBasis,
      AspisR1.ExtractedMaskTowerBasisExact.basisElement, R0P.Mask.towerBasis]
      using h
  have hu : f AspisR1.ExtractedMaskQmPackBase4Arithmetic.uBasis = PackB.u := by
    have h := AspisR1.ExtractedMaskSemanticBridgeConcrete.basisCompatible
      (2 : Fin 4)
    simpa [AspisR1.ExtractedMaskQmPackBase4Arithmetic.uBasis,
      AspisR1.ExtractedMaskTowerBasisExact.basisElement, R0P.Mask.towerBasis]
      using h
  have hiu : f (AspisR1.ExtractedMaskQmPackBase4Arithmetic.iBasis *
      AspisR1.ExtractedMaskQmPackBase4Arithmetic.uBasis) = PackB.i * PackB.u := by
    rw [map_mul, hi, hu]
  simp only [AspisR1.ExtractedMaskQmPackBase4Arithmetic.mathematicalPack,
    map_add, map_mul, hi, hu, hiu, R0P.pack4]

#print axioms map_mathPack
end AspisR1.ExtractedMaskQmPackBase4Semantic
