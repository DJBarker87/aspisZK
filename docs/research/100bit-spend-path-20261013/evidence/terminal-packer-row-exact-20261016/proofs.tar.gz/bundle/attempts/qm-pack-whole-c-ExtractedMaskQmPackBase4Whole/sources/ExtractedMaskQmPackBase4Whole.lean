import Qm31PackBase4Slice
import ExtractedMaskQmPackBase4InitCopy
import ExtractedMaskQmPackBase4Fragments

/-! Composition of the exact generated length-four packer with the checked
array/copy prelude and its checked arithmetic tail. -/
set_option autoImplicit false
namespace AspisR1.ExtractedMaskQmPackBase4Whole

open Aeneas.Std Result

abbrev CurrentQM := AspisR1.ExtractedMaskQM31Exact.CurrentQM
abbrev CurrentCanonicalQM := AspisR1.ExtractedMaskQM31Exact.CurrentCanonicalQM

def inputAt (values : Slice AspisR1SelectedMaskProbe.field.QM31)
    (hlen : values.length = 4) (j : Fin 4) : CurrentQM :=
  values.val[j.val]'(by
    have hvalues : values.val.length = 4 := by simpa using hlen
    exact Nat.lt_of_lt_of_eq j.isLt hvalues.symm)

def afterArray (a : Array AspisR1SelectedMaskProbe.field.QM31 4#usize) :
    Result CurrentQM := do
  let v0 ← Array.index_usize a 0#usize
  let v1 ← Array.index_usize a 1#usize
  let v2 ← Array.index_usize a 2#usize
  let v3 ← Array.index_usize a 3#usize
  AspisR1.ExtractedMaskQmPackBase4Tail.run (fun j =>
    if j.val = 0 then v0 else if j.val = 1 then v1 else if j.val = 2 then v2 else v3)

theorem generated_eq_prefix_after
    (values : Slice AspisR1SelectedMaskProbe.field.QM31) :
    AspisR1SelectedMaskProbe.field.qm31_pack_base4 values = (do
      let i := Slice.len values
      massert (i ≤ 4#usize)
      let copied ← AspisR1.ExtractedMaskQmPackBase4InitCopy.copyPrefixWith
        AspisR1SelectedMaskProbe.field.QM31.ZERO
        AspisR1SelectedMaskProbe.field.QM31.Insts.CoreMarkerCopy values
      afterArray copied) := by
  rfl

private theorem index_input
    (a : Array AspisR1SelectedMaskProbe.field.QM31 4#usize)
    (values : Slice AspisR1SelectedMaskProbe.field.QM31)
    (ha : a.val = values.val) (i : Usize) (hi : i.val < 4) :
    Array.index_usize a i = .ok (values.val.get ⟨i.val, by
      have hvalues : values.val.length = 4 := by
        rw [← ha]
        exact a.property
      rw [hvalues]
      exact hi⟩) := by
  have hbound : i.val < a.length := by
    have := a.property
    scalar_tac
  obtain ⟨x, hx, hxval⟩ :=
    WP.spec_imp_exists (Array.index_usize_spec a i hbound)
  have hiValues : i.val < values.val.length := by
    have hvalues : values.val.length = 4 := by
      rw [← ha]
      exact a.property
    rw [hvalues]
    exact hi
  have hxval' : x = values.val.get ⟨i.val, hiValues⟩ := by
    simpa [ha] using hxval
  exact hx.trans (congrArg Result.ok hxval')

theorem after_eq_run
    (a : Array AspisR1SelectedMaskProbe.field.QM31 4#usize)
    (values : Slice AspisR1SelectedMaskProbe.field.QM31)
    (ha : a.val = values.val) (hlen : values.length = 4) :
    afterArray a = AspisR1.ExtractedMaskQmPackBase4Tail.run (inputAt values hlen) := by
  have h0 := index_input a values ha 0#usize (by decide)
  have h1 := index_input a values ha 1#usize (by decide)
  have h2 := index_input a values ha 2#usize (by decide)
  have h3 := index_input a values ha 3#usize (by decide)
  simp only [afterArray, h0, h1, h2, h3, bind_tc_ok]
  congr 1
  funext j
  fin_cases j <;> simp [inputAt]

theorem qm31_pack_base4_success
    (values : Slice AspisR1SelectedMaskProbe.field.QM31)
    (hlen : values.length = 4)
    (hcanonical : ∀ j : Fin 4, CurrentCanonicalQM (inputAt values hlen j)) :
    ∃ out : CurrentQM,
      AspisR1SelectedMaskProbe.field.qm31_pack_base4 values = .ok out ∧
      CurrentCanonicalQM out ∧
      AspisR1.ExtractedMaskQM31Exact.decode out =
        AspisR1.ExtractedMaskQmPackBase4Arithmetic.mathematicalPack
          (inputAt values hlen) := by
  obtain ⟨copied, hcopy, hcopied⟩ :=
    AspisR1.ExtractedMaskQmPackBase4InitCopy.copyPrefixWith_eq_source
      AspisR1SelectedMaskProbe.field.QM31.ZERO
      AspisR1SelectedMaskProbe.field.QM31.Insts.CoreMarkerCopy values hlen
  have hassert : massert (Slice.len values ≤ 4#usize) = .ok () := by
    apply (Aeneas.Std.massert_ok _).2
    have hv : (Slice.len values).val = 4 := by simp [Slice.len_val, hlen]
    scalar_tac
  have hrun := after_eq_run copied values hcopied hlen
  have hprefix :
      (do
        let i := Slice.len values
        massert (i ≤ 4#usize)
        let copied ← AspisR1.ExtractedMaskQmPackBase4InitCopy.copyPrefixWith
          AspisR1SelectedMaskProbe.field.QM31.ZERO
          AspisR1SelectedMaskProbe.field.QM31.Insts.CoreMarkerCopy values
        afterArray copied) =
      AspisR1.ExtractedMaskQmPackBase4Tail.run (inputAt values hlen) := by
    simp only [hassert, hcopy, hrun, bind_tc_ok]
  rw [generated_eq_prefix_after, hprefix]
  obtain ⟨out, hout, hcanon, hdecode⟩ :=
    AspisR1.ExtractedMaskQmPackBase4Fragments.run_success
      (inputAt values hlen) hcanonical
  exact ⟨out, hout, hcanon, hdecode⟩

#print axioms qm31_pack_base4_success
end AspisR1.ExtractedMaskQmPackBase4Whole
