#!/usr/bin/env python3
import hashlib, json
from pathlib import Path
root=Path(__file__).resolve().parent
m=json.loads((root/"manifest.json").read_text())
def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
for group in (m["maintained_proof_modules"], m["scalar_addition_sources"], m["pure_oldtower_sources"], m["unverified_drafts"]):
    for item in group:
        rel=item.get("stage_path",item.get("module_path",item.get("path")))
        p=root/(Path(rel) if "stage_path" in item else ("pure-sources"/Path(rel) if "module_path" in item else Path(rel)))
        assert digest(p)==item["source_sha256"], (rel,"hash mismatch")
for rawrel,normrel,kind in [("generated/raw/AspisR1SelectedMaskProbe/Types.lean","generated/lean432/AspisR1SelectedMaskProbe/Types.lean","types"),("generated/raw/AspisR1SelectedMaskProbe/Funs.lean","generated/lean432/AspisR1SelectedMaskProbe/Funs.lean","funs")]:
    raw=(root/rawrel).read_bytes(); norm=(root/normrel).read_bytes()
    old=b"import Aeneas\n"; new=b"import Aeneas.Std\n"; attr=b"import Aeneas.Tactic.RustAttributes\n"
    assert raw.count(old)==1
    if kind=="types": reconstructed=norm.replace(new,old,1)
    else: reconstructed=norm.replace(new+attr,new,1).replace(new,old,1)
    assert reconstructed==raw, (kind,"normalization not reversible")
    assert digest(root/rawrel)==next(x["sha256"] for x in m["extraction_provenance"]["normalization"]["raw_sources"] if x["path"]==rawrel)
    assert digest(root/normrel)==next(x["sha256"] for x in m["extraction_provenance"]["normalization"]["normalized_sources"] if x["path"]==normrel)
assert not list(root.rglob("*.olean")), "source kit unexpectedly contains Lean objects"
print("source hashes and generated normalization: PASS; no olean objects")
