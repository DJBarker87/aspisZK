#!/usr/bin/env python3
"""Run one focused Lean 4.32 target in a capped user systemd scope."""
import hashlib
import json
import os
import re
import shlex
import subprocess
import sys
import time
from pathlib import Path

WORKSPACE = Path(os.environ.get(
    "MASK432_WORKSPACE", "/home/dombarker/project-offloads/aspis-r1-mask-lean432-20261015"
)).resolve()
SOURCES = Path(os.environ.get("MASK432_SOURCES", str(WORKSPACE / "sources"))).resolve()
ATTEMPTS = WORKSPACE / "attempts"
OBJECTS = WORKSPACE / "objects"
ENVIRONMENT = WORKSPACE / "environment.json"
EXECUTOR = Path(__file__).resolve().with_name("exec-mask432-lean.py")
MEMORY_HIGH = "4G"
MEMORY_MAX = "6G"
TIMEOUT_SECONDS = 300


def sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def die(message: str, code: int = 78) -> None:
    print(f"mask432 controller: {message}", file=sys.stderr)
    raise SystemExit(code)


def imports_of(source: str) -> list[str]:
    found = []
    for line in source.splitlines():
        match = re.match(r"^\s*(?:public\s+)?import\s+([A-Za-z0-9_.]+)(?:\s|$)", line)
        if match:
            found.append(match.group(1))
    return found


def env_lean_path(doc: dict) -> list[Path]:
    raw = doc.get("LEAN_PATH") or doc.get("lean_path")
    if raw is None:
        vals = doc.get("environment", doc.get("env", {}))
        raw = vals.get("LEAN_PATH") if isinstance(vals, dict) else None
    if isinstance(raw, list):
        parts = [str(x) for x in raw]
    elif isinstance(raw, str):
        parts = raw.split(os.pathsep)
    else:
        die("environment.json must pin LEAN_PATH")
    paths = []
    for item in parts:
        p = Path(item)
        paths.append((WORKSPACE / p).resolve() if not p.is_absolute() else p.resolve())
    return paths


def resolve_direct_import(module: str, search: list[Path], sources: Path) -> dict:
    rel = Path(*module.split("."))
    source_candidates = [sources / (str(rel) + ".lean")]
    for root in search:
        source_candidates.append(root / (str(rel) + ".lean"))
    source_pin = next((p for p in source_candidates if p.is_file()), None)
    for root in search:
        obj = root / (str(rel) + ".olean")
        if obj.is_file():
            return {
                "module": module,
                "object_path": str(obj),
                "object_sha256": sha(obj),
                "source_path": str(source_pin) if source_pin else None,
                "source_sha256": sha(source_pin) if source_pin else None,
            }
    die(f"missing cached direct-import object for {module}; refusing any dependency build")


def parse_time(path: Path) -> dict:
    text = path.read_text(errors="replace") if path.exists() else ""
    patterns = {
        "elapsed_wall_clock": r"Elapsed \(wall clock\) time \(h:mm:ss or m:ss\):\s*(.+)",
        "max_rss_kib": r"Maximum resident set size \(kbytes\):\s*(\d+)",
        "process_swaps": r"Swaps:\s*(\d+)",
        "exit_status_time": r"Exit status:\s*(\d+)",
    }
    result = {}
    for key, pattern in patterns.items():
        match = re.search(pattern, text)
        result[key] = (int(match.group(1)) if key != "elapsed_wall_clock" else match.group(1)) if match else None
    return result


def parse_axioms(log: Path) -> list[dict]:
    reports=[]
    for m in re.finditer(r"'([^']+)' (?:depends on axioms: \[([^\]]*)\]|does not depend on any axioms)", log.read_text(errors="replace"), re.S):
        items=[] if m[2] is None else [x.strip() for x in m[2].split(",") if x.strip()]
        reports.append({"declaration":m[1],"axioms":items})
    return reports


def populated_scope_reservations() -> dict:
    cgroup_root = Path("/sys/fs/cgroup")
    external_docker = 0
    other_scope_max = 0
    active = []
    for max_file in cgroup_root.rglob("memory.max"):
        scope = max_file.parent
        if not scope.name.endswith(".scope"):
            continue
        value = max_file.read_text().strip()
        events_file = scope / "cgroup.events"
        if value == "max" or not events_file.is_file():
            continue
        events = dict(line.split() for line in events_file.read_text().splitlines() if len(line.split()) == 2)
        if events.get("populated") != "1":
            continue
        limit = int(value)
        active.append({"scope": str(scope), "memory_max_bytes": limit})
        if scope.name.startswith("docker-") or "docker" in scope.name.lower():
            external_docker += limit
        else:
            other_scope_max += limit
    external_reserved = max(24 * 2**30, external_docker)
    required = external_reserved + other_scope_max + 6 * 2**30
    return {
        "external_docker_populated_max_bytes": external_docker,
        "external_docker_reserved_floor_bytes": 24 * 2**30,
        "external_reserved_bytes": external_reserved,
        "other_populated_scope_max_bytes": other_scope_max,
        "new_scope_memory_max_bytes": 6 * 2**30,
        "total_reserved_bytes": required,
        "host_safe_limit_bytes": 50 * 2**30,
        "active_populated_scopes": active,
    }


def main() -> None:
    if len(sys.argv) != 3:
        die("usage: run-mask432-one.py MODULE UNIQUE_LABEL")
    module, label = sys.argv[1:]
    if not re.fullmatch(r"[A-Za-z][A-Za-z0-9_.]*", module):
        die("MODULE must be a Lean module name")
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_-]*", label):
        die("UNIQUE_LABEL must be a simple unique identifier")
    if not WORKSPACE.is_dir() or not ENVIRONMENT.is_file():
        die(f"pinned workspace/environment unavailable: {WORKSPACE}")
    if not SOURCES.is_dir():
        die(f"source directory unavailable: {SOURCES}")
    if not EXECUTOR.is_file():
        die(f"executor missing: {EXECUTOR}")

    env_doc = json.loads(ENVIRONMENT.read_text())
    version_pin = str(env_doc.get("LEAN_VERSION", env_doc.get("lean_version", "")))
    if "4.32" not in version_pin:
        die("environment.json does not declare the pinned Lean 4.32 version")
    source = SOURCES / Path(*module.split("."))
    source = source.with_suffix(".lean")
    if not source.is_file():
        die(f"module source missing: {source}")

    ATTEMPTS.mkdir(parents=True, exist_ok=True)
    OBJECTS.mkdir(parents=True, exist_ok=True)
    stem = f"{label}-{module.replace('.', '_')}"
    attempt_dir = ATTEMPTS / stem
    if attempt_dir.exists():
        die(f"refusing existing attempt directory: {attempt_dir}")
    attempt_dir.mkdir()
    output = OBJECTS / Path(*module.split("."))
    output = output.with_suffix(".olean")
    output.parent.mkdir(parents=True, exist_ok=True)
    companions = [output, Path(str(output)+".private"), Path(str(output)+".server"), output.with_suffix(".ir")]
    if any(p.exists() for p in companions):
        die(f"refusing to overwrite existing target output: {output}")

    original = source.read_bytes()
    snapshot_root = attempt_dir / "sources"
    snapshot = snapshot_root / source.relative_to(SOURCES)
    snapshot.parent.mkdir(parents=True, exist_ok=True)
    snapshot.write_bytes(original)
    source_hash = sha(snapshot)
    env_hash = sha(ENVIRONMENT)
    path_roots = env_lean_path(env_doc)
    imports = [resolve_direct_import(name, [OBJECTS, *path_roots], SOURCES) for name in imports_of(original.decode())]

    budget = populated_scope_reservations()
    (attempt_dir / "reservation.json").write_text(json.dumps(budget, indent=2) + "\n")
    if budget["total_reserved_bytes"] > budget["host_safe_limit_bytes"]:
        die("reservation hold: populated scopes plus 6 GiB exceed 50 GiB")
    # Do not permit simultaneous mask432 target scopes on the same workspace.
    if any(x["scope"].rsplit("/", 1)[-1].startswith("aspis-mask432-") for x in budget["active_populated_scopes"]):
        die("another populated mask432 scope exists; one Lean job at a time")

    source_base = subprocess.run(["git", "rev-parse", "HEAD"], cwd=WORKSPACE, text=True, capture_output=True)
    source_base_revision = source_base.stdout.strip() if source_base.returncode == 0 else env_doc.get("source_revision")
    if not source_base_revision: die("missing source revision pin")
    import_pins_path = attempt_dir / "direct-import-pins.json"
    import_pins_path.write_text(json.dumps(imports, indent=2) + "\n")
    runner_hashes = {
        "controller_sha256": sha(Path(__file__).resolve()),
        "executor_sha256": sha(EXECUTOR),
    }
    preflight = {
        "target": module,
        "attempt": label,
        "source_base_revision": source_base_revision,
        "source_path": str(source),
        "source_sha256": source_hash,
        "snapshot_path": str(snapshot),
        "environment_path": str(ENVIRONMENT),
        "environment_sha256": env_hash,
        "lean_version_pin": version_pin,
        "lean_path_roots": [str(x) for x in path_roots],
        "output_path": str(output),
        "direct_imports": imports,
        "reservation": budget,
        "cgroup": {"MemoryHigh": MEMORY_HIGH, "MemoryMax": MEMORY_MAX, "MemorySwapMax": "0", "TasksMax": 128},
        "lean_memory_threshold_mb": 5000,
        "timeout_seconds": TIMEOUT_SECONDS,
        "runner_hashes": runner_hashes,
        "no_outer_flock": True,
        "no_dependency_build": True,
    }
    (attempt_dir / "preflight.json").write_text(json.dumps(preflight, indent=2) + "\n")

    log_path = attempt_dir / "lean.log"
    time_path = attempt_dir / "time.log"
    unit = "aspis-mask432-" + label
    command = [
        "systemd-run", "--user", "--scope", "--quiet", "--unit=" + unit,
        "-p", "MemoryHigh=" + MEMORY_HIGH,
        "-p", "MemoryMax=" + MEMORY_MAX,
        "-p", "MemorySwapMax=0",
        "-p", "TasksMax=128",
        "/usr/bin/time", "-v", "-o", str(time_path),
        "/usr/bin/timeout", str(TIMEOUT_SECONDS),
        sys.executable, str(EXECUTOR), str(ENVIRONMENT), str(OBJECTS), str(snapshot_root), str(output), str(snapshot),
    ]
    wall_start = time.monotonic()
    with log_path.open("x") as log:
        result = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT, check=False)
    wall_seconds = round(time.monotonic() - wall_start, 3)
    metrics = parse_time(time_path)
    axiom_reports = parse_axioms(log_path)
    (attempt_dir / "axiom-reports.json").write_text(json.dumps(axiom_reports, indent=2) + "\n")
    unchanged = source.read_bytes() == original and sha(snapshot) == source_hash
    receipt = {
        **preflight,
        "command": command,
        "exit_status": result.returncode,
        "controller_elapsed_wall_seconds": wall_seconds,
        **metrics,
        "axiom_reports": axiom_reports,
        "axiom_report_count": len(axiom_reports),
        "source_unchanged_after": unchanged,
        "output_exists": output.is_file(),
        "output_sha256": sha(output) if output.is_file() else None,
    }
    (attempt_dir / "receipt.json").write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({k:receipt[k] for k in ["target","attempt","exit_status","controller_elapsed_wall_seconds","max_rss_kib","process_swaps","axiom_report_count","output_sha256"]}),flush=True)
    if result.returncode == 0:
        assert output.is_file(), "successful exit without output"
        assert all(set(r["axioms"]) <= {"propext","Classical.choice","Quot.sound"} for r in axiom_reports)
        assert len(axiom_reports) == len(re.findall(r"^#print axioms ", original.decode(), re.M)), "missing axiom reports"
    if not unchanged:
        die("source changed during attempt", 79)
    raise SystemExit(result.returncode)


if __name__ == "__main__":
    main()
