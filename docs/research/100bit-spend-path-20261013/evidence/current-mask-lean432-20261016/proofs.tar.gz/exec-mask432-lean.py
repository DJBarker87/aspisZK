#!/usr/bin/env python3
"""Executor for one already-cached Lean 4.32 target; never builds imports."""
import json
import os
import subprocess
import sys
from pathlib import Path


def die(message: str) -> None:
    print(f"mask432 executor: {message}", file=sys.stderr)
    raise SystemExit(78)


def main() -> None:
    if len(sys.argv) != 6:
        die("usage: exec-mask432-lean.py ENVIRONMENT OBJECTS SOURCES OUTPUT SOURCE")
    env_path, objects_s, sources_s, output_s, source_s = map(Path, sys.argv[1:])
    if not env_path.is_file():
        die(f"environment file missing: {env_path}")
    env_doc = json.loads(env_path.read_text())
    objects, sources, output, source = map(
        lambda p: p.resolve(), (objects_s, sources_s, output_s, source_s)
    )
    if not source.is_file() or not sources in source.parents:
        die("source must be a file under the supplied source root")
    if output.exists():
        die(f"refusing to overwrite output: {output}")

    # Environment files may carry metadata alongside variables. Apply only the
    # explicit environment map, then resolve the pinned Lean executable.
    values = dict(env_doc.get("environment", env_doc.get("env", {})))
    # Also accept flat, uppercase process variables in the pinned manifest.
    values.update({k: v for k, v in env_doc.items() if isinstance(k, str) and k.isupper()})
    if not isinstance(values, dict):
        die("environment/env entry must be a JSON object")
    for key, value in values.items():
        if not isinstance(key, str) or not key.isupper():
            continue
        if value is None:
            os.environ.pop(key, None)
        elif isinstance(value, (str, int, float)):
            os.environ[key] = str(value)

    lean = env_doc.get("LEAN") or env_doc.get("lean") or os.environ.get("LEAN")
    if not isinstance(lean, str) or not Path(lean).is_file():
        die("pinned Lean executable is absent from environment.json")
    version_run = subprocess.run([lean, "--version"], text=True, capture_output=True, check=False)
    version = (version_run.stdout + version_run.stderr).strip()
    if version_run.returncode != 0:
        die(f"Lean version probe failed: {version}")
    if "4.32" not in version:
        die(f"expected pinned Lean 4.32, got: {version}")

    base_path = env_doc.get("LEAN_PATH") or env_doc.get("lean_path") or os.environ.get("LEAN_PATH")
    if isinstance(base_path, list):
        base_path = os.pathsep.join(str(x) for x in base_path)
    if not isinstance(base_path, str) or not base_path:
        die("LEAN_PATH must identify the pinned Aeneas/Mathlib object roots")
    os.environ["LEAN_PATH"] = str(objects) + os.pathsep + base_path

    output.parent.mkdir(parents=True, exist_ok=True)
    argv = [
        lean,
        "-j1",
        "-M5000",
        "-DElab.async=false",
        "-R",
        str(sources),
        "-o",
        str(output),
        str(source),
    ]
    print(json.dumps({"lean_version": version, "lean_path": os.environ["LEAN_PATH"], "argv": argv}), flush=True)
    os.execv(lean, argv)


if __name__ == "__main__":
    main()
