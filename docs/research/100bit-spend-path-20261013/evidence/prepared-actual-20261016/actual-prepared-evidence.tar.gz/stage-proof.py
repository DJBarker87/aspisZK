from pathlib import Path
import hashlib,json,shutil
base=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-prepared-3335-20261016');w=base/'lean';producer=Path('/home/dombarker/project-offloads/aspis-r1-worker-c-tx1-proof-20261016');old=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-callers-c16-20261016/lean');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={}
for name,source_hash,object_hash in [('AspisR1PublicPreparation.Types','a2b07cd99a3fe7d085a11b059d2d209ad8d01f526b3a008cc85e7423ad9ef47e','e1d3e2db77e3e3730db804bb1a32d75546a18b4929a4e38a3017afd489450922'),('AspisR1PublicPreparation.Funs','c3dd345a41c971c00dcae53a4799eaeebccfd953abda3ad7390da78a5a07995b','063480804f71daba2bf1775526611da2bbe0d3e943ba865f571fc91039420359'),('ExtractedPreparedModel','f91731f3e5102fb5e7b16a38a736f5309d5b87e28fa9627383ef4552218d4b5a','6befe2c556246c95404cf0f5f327040621eff78f776af1cd0119ac56fb7df8eb')]:
 stem=name.replace('.','/');source=producer/'sources'/(stem+'.lean');obj=producer/'objects'/(stem+'.olean');receipt=producer/'successful-targets'/(name+'.json');d=json.loads(receipt.read_text());assert d['exit_status']==0 and sha(source)==source_hash and sha(obj)==object_hash
 for folder,ext,src in [('sources','.lean',source),('objects','.olean',obj)]:
  dest=w/folder/(stem+ext);dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(src,dest)
 target=w/'producing-inputs'/(name+'.json');target.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(receipt,target)
 pins[name]={'source':str(source),'source_sha256':source_hash,'object':str(obj),'object_sha256':object_hash,'receipt':str(receipt),'receipt_sha256':sha(receipt)}
shutil.copyfile(old/'run-lean-host.py',w/'run-lean-host.py');(w/'producing-inputs/current-canonical-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
manifest={'source_revision':'96aad8ef209cb69d7667ab5d8728bd4584a86d16','backend_object_pins':json.loads((old/'input-manifest.json').read_text())['backend_object_pins'],'current_canonical_pins':pins,'dependency_rebuild':False,'sources':{str(p.relative_to(w/'sources')):sha(p) for p in sorted((w/'sources').rglob('*.lean'))}}
(w/'input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n');print('pinned current',list(pins))
