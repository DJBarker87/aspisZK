# Candidate12 M31 batched-fold proof extension

This packet adds the source-shaped flush/counter/reducer composition to the prior Nat arithmetic packet. Lean target is pinned 4.32.0 via the focused runner. All checks below were exit 0, no swap, and `#print axioms` reports contain only propext, Classical.choice and Quot.sound.

The source excerpt is `pins/BatchedWeights.verifier.rs`, taken from `/Users/dominic/ZK/crates/aspis-r1-cost-probe/src/verifier.rs` lines 230–255. Excerpt SHA256: `3ac0f3b2c5ec4ddfc456c52d6afd26853dcd6593e98038e2660f00170d174e01`. The excerpt directly ties this mathematical model to `BatchedWeights::push`: it adds four canonical products, flushes on `terms & 3 == 3`, folds with mask/shift, and `value()` subsequently calls `M31::reduce_u64` for each retained limb.

Accepted Lean targets: `AspisR1BatchedFoldArithmetic` (Nat bounds/residue), `AspisR1BatchedFoldSourceStep` (four pushes and repeated batches), `AspisR1BatchedUsizeFlushBridgePublic` (actual Aeneas `UScalar.and` mask ↔ modulo-four), `AspisR1BatchedSourceCadence` (Nat cadence projection), `AspisR1BatchedReducerBridge` (actual extracted reducer modulo), `AspisR1BatchedActualCounter` (actual checked Usize increments plus four actual mask tests/fold bounds), and `AspisR1BatchedActualReducerFinish` (four pushes followed by the retained actual `M31.reduce_u64`).

Each target receipt records exact source/object hashes, Lean version, elapsed time, peak RSS, swap, imports and axioms. `pins/nuc-current-reducer432-pinned-cache.tar.gz` and the copied accepted-target receipts provide the exact reducer cache lineage.

Scope boundary: each query product is supplied as a Nat bounded by `(2^31-2)^2`; the initial lane accumulator is supplied below `2^34`. The packet does not yet prove the Rust loop selects the corresponding `power`/`basis` lane values or that each selected M31 operand is canonical. It also does not prove the full Vec/index schedule or `finish` iteration correspondence. Thus it closes arithmetic, actual fold cadence, checked term-counter increments and final reducer behavior, with those caller/data-layout facts still explicit.

Current worktree HEAD when packet was assembled: `899a6055c065121d0ebbb48b2450424c1e13802c`. Candidate12 source revision recorded by the accepted task discussion: `16a39d2a8a5124e25c787f2b9fcaf8449fb84611`. The exact source excerpt hash above is stable across candidate12, candidate14 and current HEAD.
