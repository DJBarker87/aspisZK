#![no_std]
extern crate self as aspis_core;

pub mod field {
/// M31 base field element, canonical representation in [0, P).
#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct M31(pub u32);
/// CM31 = M31[i] / (i^2 + 1). Element a + b*i.
#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct CM31 {
    pub a: M31,
    pub b: M31,
}
/// QM31 = CM31[u] / (u^2 - (2 + i)). Element c0 + c1*u. (stwo parameterization)
#[derive(Clone, Copy, PartialEq, Eq, Debug, Default)]
pub struct QM31 {
    pub c0: CM31,
    pub c1: CM31,
}
 }

pub mod circle {
    use crate::field::QM31;
/// A point `(x, y)` on `x^2 + y^2 = 1` over QM31.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub struct SecureCirclePoint {
    pub x: QM31,
    pub y: QM31,
}
/// Rejection reasons for the rational parameterization.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CirclePointError {
    /// `1 + t^2 = 0`, so the rational map has no finite value.
    SingularParameter,
    /// OOD policy rejects the whole CM31 parameter subfield. This is stronger
    /// than merely excluding the M31 circle domain and matches the existing
    /// line-point policy of sampling from `QM31 \ CM31`.
    ParameterInCm31Subfield,
}
    pub fn secure_ood_circle_point_from_parameter(
        _parameter: QM31,
    ) -> Result<SecureCirclePoint, CirclePointError> {
        unreachable!()
    }
}

pub mod r0_transcript {
/// Selects the existing row fallback: parameter u for row 25, 1+u for 26.
#[derive(Clone, Copy, Debug, PartialEq, Eq)]
pub enum CircleRow {
    First,
    Second,
}
 }

pub mod transcript {
    use crate::circle::SecureCirclePoint;
    pub fn circle_fallback_point(_sample: usize) -> SecureCirclePoint {
        unreachable!()
    }
}

pub mod sampler {
    use crate::circle::{secure_ood_circle_point_from_parameter, SecureCirclePoint};
    use crate::field::QM31;
    pub use crate::r0_transcript::CircleRow;
    pub fn qm31_sample(_block: &[u8; 32]) -> QM31 {
        unreachable!()
    }
pub fn circle_sample(block: &[u8; 32], row: CircleRow) -> SecureCirclePoint {
    secure_ood_circle_point_from_parameter(qm31_sample(block)).unwrap_or_else(|_| {
        aspis_core::transcript::circle_fallback_point(match row {
            CircleRow::First => 0,
            CircleRow::Second => 1,
        })
    })
}
}
