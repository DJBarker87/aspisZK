import Mathlib.NumberTheory.LegendreSymbol.QuadraticChar.Basic
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring
import Mathlib.Tactic.NormNum
import Mathlib.Tactic.Linarith

noncomputable section
namespace AspisR1.CantorZassenhausPair
variable {K : Type*} [Field K]

/-- The first two random coefficients make evaluations at distinct points
uniform and independent, even after fixing every higher coefficient. -/
def pairEvaluationEquiv (a b ta tb : K) (hab : a ≠ b) : (K × K) ≃ (K × K) where
  toFun c := (c.1 + c.2 * a + ta, c.1 + c.2 * b + tb)
  invFun v := (v.1 - ta - ((v.2 - tb - (v.1 - ta)) / (b-a)) * a,
    (v.2 - tb - (v.1-ta)) / (b-a))
  left_inv c := by
    have h : b-a ≠ 0 := sub_ne_zero.mpr (Ne.symm hab)
    apply Prod.ext <;> dsimp <;> field_simp <;> ring
  right_inv v := by
    have h : b-a ≠ 0 := sub_ne_zero.mpr (Ne.symm hab)
    apply Prod.ext <;> dsimp <;> field_simp <;> ring

variable [Fintype K] [DecidableEq K]
def chi (x : K) : ℚ := (quadraticChar K x : ℤ)
def zeroIndicator (x : K) : ℚ := if x=0 then 1 else 0

theorem chi_sum (hodd : ringChar K ≠ 2) : ∑ x : K, chi x = 0 := by
  simpa [chi] using congrArg (fun z : ℤ => (z : ℚ)) (quadraticChar_sum_zero hodd)

theorem chi_square (x : K) : chi x * chi x = 1 - zeroIndicator x := by
  by_cases hx : x=0
  · simp [chi,zeroIndicator,hx]
  · have h := quadraticChar_sq_one (F := K) hx
    have hc : chi x ^ 2 = 1 := by exact_mod_cast h
    simpa [pow_two,zeroIndicator,hx] using hc

theorem zeroIndicator_sum : ∑ x : K, zeroIndicator x = 1 := by
  simp [zeroIndicator]

theorem chi_square_sum : (∑ x : K, chi x * chi x) = (Fintype.card K : ℚ) - 1 := by
  simp_rw [chi_square]
  rw [Finset.sum_sub_distrib,zeroIndicator_sum]
  simp

def sameCategory (x y : K) : ℚ := if quadraticChar K x=quadraticChar K y then 1 else 0

theorem sameCategory_identity (x y : K) :
    2 * sameCategory x y = (chi x * chi x) * (chi y * chi y) + chi x * chi y +
      2 * zeroIndicator x * zeroIndicator y := by
  by_cases hx : x=0
  · subst x
    by_cases hy : y=0
    · simp [sameCategory,chi,zeroIndicator,hy]
    · have hcy := quadraticChar_eq_zero_iff (F := K) |>.not.mpr hy
      simp [sameCategory,chi,zeroIndicator,hy,Ne.symm hcy]
  · by_cases hy : y=0
    · subst y
      have hcx := quadraticChar_eq_zero_iff (F := K) |>.not.mpr hx
      simp [sameCategory,chi,zeroIndicator,hx,hcx]
    · rcases quadraticChar_dichotomy (F := K) hx with hpx|hnx <;>
      rcases quadraticChar_dichotomy (F := K) hy with hpy|hny <;>
      norm_num [sameCategory,chi,zeroIndicator,hx,hy,*]

#print axioms pairEvaluationEquiv
#print axioms chi_sum
#print axioms sameCategory_identity
end AspisR1.CantorZassenhausPair
