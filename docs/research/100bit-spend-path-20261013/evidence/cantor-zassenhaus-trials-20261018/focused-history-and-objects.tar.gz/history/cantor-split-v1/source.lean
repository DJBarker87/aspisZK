import CantorZassenhausPair
import Mathlib.Algebra.Polynomial.FieldDivision

noncomputable section
namespace AspisR1.CantorZassenhausSplit
open Polynomial
variable {K : Type*} [Field K] [Fintype K] [DecidableEq K]

def ProperFactor (d f : K[X]) : Prop := d ∣ f ∧ d ≠ 1 ∧ d ≠ f

theorem proper_gcd_of_separated_roots (f h : K[X]) (a b : K)
    (hfa : IsRoot f a) (hfb : IsRoot f b)
    (hha : IsRoot h a) (hhb : ¬ IsRoot h b) :
    ProperFactor (EuclideanDomain.gcd f h) f := by
  refine ⟨EuclideanDomain.gcd_dvd_left _ _, ?_, ?_⟩
  · intro heq
    have hr := Polynomial.isRoot_gcd_iff_isRoot_left_right.mpr ⟨hfa,hha⟩
    rw [heq] at hr
    simpa [IsRoot] using hr
  · intro heq
    have hr : IsRoot (EuclideanDomain.gcd f h) b := by rw [heq]; exact hfb
    exact hhb (Polynomial.isRoot_gcd_iff_isRoot_left_right.mp hr).2

/-- Both gcd checks are necessary for the clean one-half trial bound. -/
def TwoGCDSplit (f h : K[X]) : Prop :=
  ProperFactor (EuclideanDomain.gcd f h) f ∨
  ProperFactor (EuclideanDomain.gcd f (h^(Fintype.card K / 2)-1)) f

theorem different_categories_split (f h : K[X]) (a b : K)
    (hodd : ringChar K ≠ 2) (hfa : IsRoot f a) (hfb : IsRoot f b)
    (hchi : quadraticChar K (h.eval a) ≠ quadraticChar K (h.eval b)) :
    TwoGCDSplit f h := by
  by_cases ha : h.eval a=0
  · have hb : h.eval b ≠ 0 := by
      intro hb
      exact hchi (by rw [ha,hb])
    exact Or.inl (proper_gcd_of_separated_roots f h a b hfa hfb ha hb)
  · by_cases hb : h.eval b=0
    · exact Or.inl (proper_gcd_of_separated_roots f h b a hfb hfa hb ha)
    · have hpa := quadraticChar_eq_pow_of_char_ne_two' hodd (h.eval a)
      have hpb := quadraticChar_eq_pow_of_char_ne_two' hodd (h.eval b)
      have hnot : (-1 : K) ≠ 1 := Ring.neg_one_ne_one_of_char_ne_two hodd
      rcases quadraticChar_dichotomy (F := K) ha with hca|hca <;>
      rcases quadraticChar_dichotomy (F := K) hb with hcb|hcb
      · exact (hchi (hca.trans hcb.symm)).elim
      · apply Or.inr
        apply proper_gcd_of_separated_roots f (h^(Fintype.card K / 2)-1) a b hfa hfb
        · rw [IsRoot,eval_sub,eval_pow,eval_one,←hpa,hca]
          simp
        · rw [IsRoot,eval_sub,eval_pow,eval_one,←hpb,hcb]
          simpa only [Int.cast_neg,Int.cast_one,sub_eq_zero] using hnot
      · apply Or.inr
        apply proper_gcd_of_separated_roots f (h^(Fintype.card K / 2)-1) b a hfb hfa
        · rw [IsRoot,eval_sub,eval_pow,eval_one,←hpb,hcb]
          simp
        · rw [IsRoot,eval_sub,eval_pow,eval_one,←hpa,hca]
          simpa only [Int.cast_neg,Int.cast_one,sub_eq_zero] using hnot
      · exact (hchi (hca.trans hcb.symm)).elim

#print axioms proper_gcd_of_separated_roots
#print axioms different_categories_split
end AspisR1.CantorZassenhausSplit
