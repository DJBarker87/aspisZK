fn polynomial_boundary(polynomial:&[QM31;28])->QM31 {
    polynomial.iter().copied().fold(polynomial[0], QM31::add)
}

fn polynomial_value(polynomial:&[QM31;28], alpha:QM31)->QM31 {
    polynomial
            .iter()
            .rev()
            .fold(QM31::ZERO, |a, &c| a.mul(alpha).add(c))
}
