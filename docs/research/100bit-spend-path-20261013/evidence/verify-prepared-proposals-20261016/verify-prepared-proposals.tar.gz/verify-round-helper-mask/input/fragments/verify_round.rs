fn verify_round<H:Digest32>(prefix:&Prefix<'_>, transcript:&mut SemanticTranscript<H>, round:usize, running:QM31)->Result<(QM31,QM31,QM31),Error> {
        let row = 15 + round as u8;
        let polynomial = prefix.validated_record(row)?.decode_k::<28>(0)?;
        let boundary = polynomial_boundary(&polynomial);
        if boundary != running {
            return Err(Error::Boundary { round });
        }
        let alpha = transcript.semantic_validated(prefix.validated_record(row)?)?;
        let value = polynomial_value(&polynomial, alpha);
        Ok((alpha,boundary,value))
}
