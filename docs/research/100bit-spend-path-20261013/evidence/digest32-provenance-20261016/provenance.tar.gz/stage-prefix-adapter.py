from pathlib import Path
import hashlib,json,shutil
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-callers-c16-20261016');w=base/'prefix-adapter';w.mkdir(exist_ok=True);s=w/'sources';o=w/'objects';s.mkdir(exist_ok=True);o.mkdir(exist_ok=True)
old=Path('/home/dombarker/project-offloads/aspis-r1-r18-prefix-20261016/lean-bridge');m=json.loads((old/'input-manifest-typed-full-b.json').read_text());pins={}
for p in sorted((old/'objects').rglob('*.olean')):
 rel=p.relative_to(old/'objects');name=str(rel)[:-6].replace('/','.');h=sha(p)
 if str(rel) in m['new_import_objects']:assert h==m['new_import_objects'][str(rel)]
 elif name in ['ExtractedPrefixTypedFull','ExtractedPrefixCompletedDecode']:
  target='typed-full-b' if name=='ExtractedPrefixTypedFull' else 'completed-decode-a'
  r=json.loads((old/'runs'/target/'receipt.json').read_text());assert r['exit_status']==0 and r['olean_sha256']==h
 else:raise AssertionError(name)
 source=old/'sources'/rel.with_suffix('.lean');expected=m['new_sources'][str(rel.with_suffix('.lean'))] if str(rel.with_suffix('.lean')) in m['new_sources'] else r['source_sha256'];assert sha(source)==expected
 pins[name]={'source':str(source),'source_sha256':sha(source),'object':str(p),'object_sha256':h}
for mod in ['Types','Funs']:
 for folder,ext in [('sources','.lean'),('objects','.olean')]:
  dest=w/folder/'AspisR1PublicPreparation'/f'{mod}{ext}';dest.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(base/'lean'/folder/'AspisR1PublicPreparation'/f'{mod}{ext}',dest)
shutil.copyfile(base/'lean/run-lean-host.py',w/'run-lean-host.py');p=w/'run-lean-host.py';text=p.read_text();text=text.replace("extra_file = Path(__file__).resolve().parent / \"external-sampler-pins.json\"", "extra_file = Path(__file__).resolve().parent / \"external-prefix-pins.json\"");text=text.replace("'/home/dombarker/project-offloads/aspis-r1-worker-a-callers-c16-20261016/lean/sampler-import-objects'",repr(str(old/'objects')));p.write_text(text)
(w/'external-prefix-pins.json').write_text(json.dumps({'modules':pins,'original_manifest':str(old/'input-manifest-typed-full-b.json'),'original_manifest_sha256':sha(old/'input-manifest-typed-full-b.json'),'typed_full_receipt':str(old/'runs/typed-full-b/receipt.json'),'typed_full_receipt_sha256':sha(old/'runs/typed-full-b/receipt.json'),'input_environment':'Isolated prefix closure; no sampler cache inserted. Existing prefix objects and sources are read-only pinned inputs.'},indent=2)+'\n')
shutil.copyfile(old/'input-manifest-typed-full-b.json',w/'prefix-producing-manifest.json');shutil.copyfile(old/'runs/typed-full-b/receipt.json',w/'prefix-producing-receipt.json')
print('prefix inputs',len(pins))
