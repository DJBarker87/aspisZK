#![no_std]

pub trait Digest32: Copy {
    fn digest(&self, parts: &[&[u8]]) -> [u8; 32];
}

pub mod state_only_private_merkle {
use crate::Digest32;
const DOM_LEAF: u8 = 0x10;
pub const STATE_ONLY_PRIVATE_LEAF_SALT_BYTES: usize = 32;
pub fn private_leaf_hash_with_digest<H: Digest32>(
    hash: H,
    tree_tag: u8,
    value: &[u8],
    salt: &[u8; STATE_ONLY_PRIVATE_LEAF_SALT_BYTES],
) -> [u8; 32] {
    hash.digest(&[&[DOM_LEAF, tree_tag], value, salt])
}
}
