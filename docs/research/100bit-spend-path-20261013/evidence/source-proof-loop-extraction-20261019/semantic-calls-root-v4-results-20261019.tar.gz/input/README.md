# Focused semantic-only call-body extraction input

This is a distinct source-pinned Charon/Aeneas attempt packet derived from the validated v2 source kit. It retains the same exact current Rust files and exact `aspis-core` field sources. The selected roots are only `semantic_boundary_entry` and `semantic_value_entry`; the pinned `decode_k` source remains present but is deliberately not selected because the v2 combined extraction stopped in Aeneas Iterator::Enumerate trait-signature sanity before emitting Lean.

`semantic_boundary` is byte-for-byte current production. `semantic_value` keeps its iterator/fold expression and adds only `let value: QM31` to constrain the standalone root crate. The field add/mul operations are copied from the exact pinned current `field.rs`, so the generated calls can be transported to the existing selected-probe `current_qm_add_exact` / `current_qm_mul_exact` proofs.

This packet changes only selected extraction roots, output paths, and explanatory metadata. It does not edit or replace v2. Resource limits and tool pins remain in `command-plan.json`; take fresh aggregate admission before each capped stage.
