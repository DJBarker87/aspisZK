# BatchedWeights source-compatible extraction candidate v4

This isolated kit copies the pinned BatchedWeights carrier and two method bodies from `crates/aspis-r1-cost-probe/src/verifier.rs` at revision `efa2ddcecdb76c8633b1dbbd40a6e8fe2348308a`, together with the pinned `aspis-core` field implementation. It changes no production file.

The candidate makes two explicit, source-compatible rewrites to avoid Aeneas external-template axioms: the flush normalizes four coordinates by indexed expressions instead of mutable-array IntoIterator, and `value` makes four ordered `M31::reduce_u64` calls instead of array `.map`. The original source spans and hashes remain in `source-pins.json`; the candidate method bodies are explicitly marked transformed. A Lean correspondence proof is still required before treating the transformed methods as the production implementation.

The wrappers accept an existing `Vec<[u64;4]>` and invoke one method, excluding constructor allocation and the verifier's surrounding query loop. Run the exact pinned Charon/Aeneas commands from `command-plan.json` using the reviewed capped runner.
