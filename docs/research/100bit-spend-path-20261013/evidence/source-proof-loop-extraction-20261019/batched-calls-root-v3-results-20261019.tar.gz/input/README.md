# Focused semantic round call-body extraction input

This is a temporary, source-pinned Charon/Aeneas input. `source-pins.json` records the current branch revision, full-file pins, exact source spans, hashes, and the standalone type-only adjustment. `semantic_boundary` and `semantic_value` are copied from current production `r1_semantic.rs`; the accumulator binder in `semantic_value` receives an explicit `QM31` annotation because this standalone crate leaves Rust method resolution less constrained. The iterator/fold expression and calls are otherwise unchanged. The `Error`, `ValidatedRecord`, and `ValidatedRecord` implementation (including current `decode_k`) are copied byte-for-byte from current production `r1_wire.rs`.

The full current `aspis-core/src/field.rs` and `field/wide_exact.rs` are copied byte-for-byte, so `QM31.add`, `QM31.mul`, and `QM31.from_le_bytes` are extracted as their actual definitions in the same crate rather than left as opaque calls. `decode_k_entry` is a one-call wrapper that constructs the copied carrier and invokes `decode_k`; framing and parsed-record validity remain separate caller obligations.

Rust preflight: `cargo check --locked --offline --release` passes. The Aeneas extraction itself has not yet been run.
