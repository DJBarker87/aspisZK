# Focused semantic round call-body extraction input

This is a temporary, source-pinned Charon/Aeneas input. `source-pins.json` records the current branch revision, full-file pins, exact source spans, hashes, and the standalone type-only adjustment. `semantic_boundary` is copied byte-for-byte from current production `r1_semantic.rs`. `semantic_value` keeps the current iterator/fold expression and adds only an explicit `QM31` type to the local accumulator result because the reduced standalone root crate otherwise leaves its fold result underconstrained. The `Error`, `ValidatedRecord`, and `ValidatedRecord` implementation (including current `decode_k`) are copied byte-for-byte from current production `r1_wire.rs`.

The full current `aspis-core/src/field.rs` and `field/wide_exact.rs` are copied byte-for-byte, so `QM31.add`, `QM31.mul`, and `QM31.from_le_bytes` are extracted as their actual definitions in the same crate rather than left as opaque calls. `decode_k_entry` is a one-call wrapper that constructs the copied carrier and invokes `decode_k`; framing and parsed-record validity remain separate caller obligations.

Rust preflight: `cargo check --locked --offline --release` passes. The Aeneas extraction itself has not yet been run.
