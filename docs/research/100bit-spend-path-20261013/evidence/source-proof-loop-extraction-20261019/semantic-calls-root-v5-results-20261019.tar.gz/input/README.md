# Experimental explicit-loop semantic-call extraction candidate

The v2/v4 Aeneas runs stopped at a sanity assertion for Iterator trait signatures. This distinct packet keeps exact full source pins for production `r1_semantic.rs`, `r1_wire.rs`, and `aspis-core` fields, and adds a diff showing the extraction-candidate change. Only the semantic roots are selected.

The candidate `semantic_boundary` uses an index loop from 0 through 27, seeded with coefficient 0, and calls the same `QM31::add` operation in left-fold order. The candidate `semantic_value` uses an index loop from 27 down through 0 and performs the same `QM31::mul` followed by `QM31::add` at each step. These intended equivalences are not yet proved; a Lean bridge must establish them against the pinned production function spans before the generated bodies are used as production refinement evidence.

`semantic-candidate.diff` is the exact standalone source change. `source-pins.json` distinguishes production source pins from candidate source hashes. No decoder root is selected because the iterator trait-signature failure persisted without it. Tool and resource pins are in `command-plan.json`; this is not a request to raise the prior cap.
