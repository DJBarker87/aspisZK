#![no_std]
pub mod transcript {
/// Failure of bounded exact-uniform query sampling without replacement.
#[derive(Clone, Copy, PartialEq, Eq, Debug)]
pub enum QuerySampleError {
    /// Masking is exact only when the domain size is a nonzero power of two.
    BoundNotPowerOfTwo { bound: u32 },
    /// A without-replacement sample cannot contain more points than its domain.
    CountExceedsBound { count: usize, bound: u32 },
    /// The configured candidate-draw cap was reached before `count` distinct
    /// positions were accepted. This is an explicit completeness abort.
    DrawLimitExhausted { accepted: usize, max_draws: usize },
}
}
pub mod r0_transcript {
use crate::transcript::QuerySampleError;
// Little-endian base-2^32 limbs. Keeping the moduli private ensures the
// reducer's invariant 0 < n < 2^248 holds for every caller.
type Rank = [u32; 8];
pub const QUERY_COUNT: usize = 22;
pub const QUERY_BOUND: u32 = 1 << 18;
pub const QUERY_MAX_DRAWS: usize = 64;
fn block_rank(block: &[u8; 32]) -> Rank {
    core::array::from_fn(|i| {
        let j = 4 * i;
        u32::from_le_bytes([block[j], block[j + 1], block[j + 2], block[j + 3]])
    })
}
fn query_words(block: &[u8; 32]) -> [u32; 8] {
    block_rank(block).map(|word| word & (QUERY_BOUND - 1))
}
// Fixed-capacity implementation of Q22WordScan.ScanState. Private fields
// preserve accepted_len <= 22 and draws <= 64 without public preconditions.
#[derive(Default)]
struct QueryScan {
    accepted: [u32; QUERY_COUNT],
    accepted_len: usize,
    draws: usize,
}
impl QueryScan {
    /// Checks before each word, with no check after the last word. In
    /// particular, success on word 8 is detected in the next block.
    fn scan(&mut self, block: &[u8; 32]) -> bool {
        for candidate in query_words(block) {
            if self.accepted_len == QUERY_COUNT || self.draws == QUERY_MAX_DRAWS {
                return true;
            }
            self.draws += 1;
            if !self.accepted[..self.accepted_len].contains(&candidate) {
                self.accepted[self.accepted_len] = candidate;
                self.accepted_len += 1;
            }
        }
        false
    }

    fn finish(self) -> Result<[u32; QUERY_COUNT], QuerySampleError> {
        if self.accepted_len == QUERY_COUNT {
            Ok(self.accepted)
        } else {
            Err(QuerySampleError::DrawLimitExhausted {
                accepted: self.accepted_len,
                max_draws: QUERY_MAX_DRAWS,
            })
        }
    }
}
/// SPEC §2 adapter for callers that materialize all eight squeeze/advance
/// pairs before scanning. Returns scanOut's selected state, which can precede
/// the eighth advance. The sampler and its stop test are shared with R-B.

pub fn scan_entry(accepted: [u32; QUERY_COUNT], accepted_len: usize, draws: usize, block: &[u8; 32]) -> ([u32; QUERY_COUNT], usize, usize, bool) {
    let mut scan = QueryScan { accepted, accepted_len, draws };
    let stopped = scan.scan(block);
    (scan.accepted, scan.accepted_len, scan.draws, stopped)
}

fn feed(
    mut scan: QueryScan,
    blocks: &[[u8; 32]; 8],
    advances: &[[u8; 32]; 8],
    k: usize,
    mut state: [u8; 32],
    stopped: bool,
) -> Result<(QueryScan, [u8; 32], bool), QuerySampleError> {
    if stopped {
        return Ok((scan, state, true));
    }
    let (accepted, accepted_len, draws, stop) =
        scan_entry(scan.accepted, scan.accepted_len, scan.draws, &blocks[k]);
    scan = QueryScan { accepted, accepted_len, draws };
    if stop {
        state = advances[k];
    }
    Ok((scan, state, stop))
}

pub fn queries_from_pairs(
    blocks: &[[u8; 32]; 8],
    advances: &[[u8; 32]; 8],
) -> Result<([u32; QUERY_COUNT], [u8; 32]), QuerySampleError> {
    let mut scan = QueryScan::default();
    let mut state = advances[7];
    let mut stopped = false;
    let (s, st, done) = feed(scan, blocks, advances, 0, state, stopped)?;
    scan = s; state = st; stopped = done;
    let (s, st, done) = feed(scan, blocks, advances, 1, state, stopped)?;
    scan = s; state = st; stopped = done;
    let (s, st, done) = feed(scan, blocks, advances, 2, state, stopped)?;
    scan = s; state = st; stopped = done;
    let (s, st, done) = feed(scan, blocks, advances, 3, state, stopped)?;
    scan = s; state = st; stopped = done;
    let (s, st, done) = feed(scan, blocks, advances, 4, state, stopped)?;
    scan = s; state = st; stopped = done;
    let (s, st, done) = feed(scan, blocks, advances, 5, state, stopped)?;
    scan = s; state = st; stopped = done;
    let (s, st, done) = feed(scan, blocks, advances, 6, state, stopped)?;
    scan = s; state = st; stopped = done;
    let (s, st, _done) = feed(scan, blocks, advances, 7, state, stopped)?;
    scan = s; state = st;
    Ok((scan.finish()?, state))
}
}
