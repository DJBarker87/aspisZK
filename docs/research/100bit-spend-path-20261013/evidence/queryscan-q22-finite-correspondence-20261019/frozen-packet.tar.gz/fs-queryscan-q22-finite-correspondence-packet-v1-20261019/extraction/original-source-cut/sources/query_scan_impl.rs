impl QueryScan {
    /// Checks before each word, with no check after the last word. In
    /// particular, success on word 8 is detected in the next block.
    fn scan(&mut self, block: &[u8; 32]) -> bool {
        for candidate in query_words(block) {
            if self.accepted_len == QUERY_COUNT || self.draws == QUERY_MAX_DRAWS {
                return true;
            }
            self.draws += 1;
            if !self.accepted[..self.accepted_len].contains(&candidate) {
                self.accepted[self.accepted_len] = candidate;
                self.accepted_len += 1;
            }
        }
        false
    }

    fn finish(self) -> Result<[u32; QUERY_COUNT], QuerySampleError> {
        if self.accepted_len == QUERY_COUNT {
            Ok(self.accepted)
        } else {
            Err(QuerySampleError::DrawLimitExhausted {
                accepted: self.accepted_len,
                max_draws: QUERY_MAX_DRAWS,
            })
        }
    }
}