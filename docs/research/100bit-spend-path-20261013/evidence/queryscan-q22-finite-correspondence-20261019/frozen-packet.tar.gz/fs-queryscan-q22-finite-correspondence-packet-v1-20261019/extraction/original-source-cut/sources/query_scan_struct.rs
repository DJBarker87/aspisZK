// Fixed-capacity implementation of Q22WordScan.ScanState. Private fields
// preserve accepted_len <= 22 and draws <= 64 without public preconditions.
#[derive(Default)]
struct QueryScan {
    accepted: [u32; QUERY_COUNT],
    accepted_len: usize,
    draws: usize,
}