fn query_words(block: &[u8; 32]) -> [u32; 8] {
    block_rank(block).map(|word| word & (QUERY_BOUND - 1))
}