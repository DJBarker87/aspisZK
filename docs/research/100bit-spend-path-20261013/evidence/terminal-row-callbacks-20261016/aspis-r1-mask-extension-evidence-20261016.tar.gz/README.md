# RawPoseidon extension conversion evidence

Two focused Lean 4.32 targets are green. `RawPoseidonExtensionSlice` retains the exact generated declarations named in the source kit manifest; its imports and namespace framing are supplied around unchanged declaration blocks. `RawPoseidonExtensionWords` takes a fixed-size four-limb U64 array, derives the indexed-read successes from its dimensions, and proves that the words pass through the existing reducer into canonical QM31 component words using the pinned `current_reduce_mod` result.

The source Funs file from the G extraction is included as an input pin, and the old selected-mask Funs source is also included to document that these names are absent there. Direct-import output hashes, receipts, cgroup details, runner and environment hashes, and axiom reports are in `manifest.json` and each attempt directory. The archived objects include two target outputs and their direct imports; transitive dependencies remain pinned through the prior callback and arithmetic evidence bundles.

Scope ends at the isolated conversion and conditional word model. No enclosing generated callback, Rust-source refinement, or ideal-mask equality is claimed.
