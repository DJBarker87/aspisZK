# RawPoseidon generated callback bridge evidence

This add-on preserves the focused 4.32 attempts for `RawPoseidonExternalRowClosure`, `RawPoseidonExternalRowReads`, `RawPoseidonExternalRowLanes`, `RawPoseidonExternalRowCalls`, and `RawPoseidonExternalAllRows`. Every attempt directory includes its exact source snapshot, receipt, direct-import pins, reservation/preflight, Lean log, time log, and axiom report; failures are retained.

The closure, lane, and call targets retain their explicit successful-read equations and limb bounds. `AllRows` instead takes a fixed-size `Input` array and a limb index below four, and derives all eight row/limb read equations from the array dimensions before applying the `call_mut` output theorem. This remains a local callback result: it does not prove the enclosing generated `from_fn`/`Array.map` composition, Rust/source refinement, or a protocol/security theorem.

Direct-import source/object pins are included. The preceding generated-slice and reducer-operations bridge outputs remain in the frozen parent evidence archive recorded in `manifest.json`; this add-on does not duplicate that full dependency archive. `WideTower` source/receipt/object provenance is separately reconciled in the root review message and prior `lean-reuse-checkpoint-20261013` evidence.

The successful attempt receipts report Lean 4.32.0 with `MemoryHigh=4G`, `MemoryMax=6G`, `MemorySwapMax=0`, and `TasksMax=128`; the exact environment and runner hashes are in the manifest.

A separate `WideTower` provenance reconciliation is recorded in `manifest.json`: the prior successful target receipt and source/output hashes are from `lean-reuse-checkpoint-20261013`; the object resolved by the active bridge has the same hash. The historical receipt has no explicit Lean-version pin, so the archive does not claim the old compile itself used Lean 4.32.
