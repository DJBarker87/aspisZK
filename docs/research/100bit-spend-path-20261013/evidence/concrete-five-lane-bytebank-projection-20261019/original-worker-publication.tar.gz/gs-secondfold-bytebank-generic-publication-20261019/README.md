# Second-fold byte-bank focused evidence

This packet contains three focused Lean checks on the `research` branch: the generic nonfailure-to-five-roots lemma, the actual byte-bank second-fold projection consumer, and the `fromWords` point-array adapter. Each source, native object, command/preflight record, raw log, receipt, and hash is retained. This is working evidence only; it does not claim a clean unified-manifest release.

The failed helper/projection attempts in `diagnostics/` document the proof split and are not accepted artifacts.
