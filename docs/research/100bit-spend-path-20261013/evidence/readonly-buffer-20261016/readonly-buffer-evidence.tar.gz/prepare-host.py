from pathlib import Path
import hashlib,json,os
p=Path("/home/dombarker/project-offloads/aspis-r1-readonly-buffer-worker-b-20261016")
revision="6fb788cbda2ce9dba9831e533260026f56b2796b"
for f in (p/"source").rglob("*"):
 if f.is_file() and "target" not in f.parts: os.utime(f,None)
def sha(f):return hashlib.sha256(f.read_bytes()).hexdigest()
inputs=json.loads((p/"inputs.json").read_text());inputs["source_revision"]=revision
(p/"inputs.json").write_text(json.dumps(inputs,indent=2)+"\n")
setup=json.loads((p/"setup.json").read_text());setup["source_revision"]=revision;setup["source_mtimes_refreshed_after_cache_copy"]=True
(p/"setup.json").write_text(json.dumps(setup,indent=2)+"\n")
