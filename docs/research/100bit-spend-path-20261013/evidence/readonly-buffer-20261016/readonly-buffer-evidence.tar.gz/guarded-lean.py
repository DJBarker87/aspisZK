from pathlib import Path
from datetime import datetime,timezone
import subprocess,time,json,sys
root=Path("/home/dombarker/project-offloads/aspis-r1-readonly-buffer-worker-b-20261016")
module,attempt=sys.argv[1:]
unit="r16-buffer-"+attempt+"-20261016"
def lean_processes():
 found=[]
 for p in Path("/proc").iterdir():
  if not p.name.isdigit():continue
  try:
   if (p/"comm").read_text().strip()=="lean":found.append({"pid":int(p.name),"command":(p/"cmdline").read_bytes().replace(b"\0",b" ").decode(),"cgroup":(p/"cgroup").read_text()})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return found
begin=datetime.now(timezone.utc).isoformat()
existing=lean_processes()
if existing:
 print(json.dumps({"launch_blocked":True,"at":begin,"existing":existing}),flush=True)
 sys.exit(77)
cmd=["systemd-run","--user","--scope","--quiet","--unit="+unit,"-p","MemoryHigh=6G","-p","MemoryMax=8G","-p","MemorySwapMax=0","python3",str(root/"proofs/runner.py"),str(root/"proofs"),module,"--attempt",attempt,"--revision","6fb788cbda2ce9dba9831e533260026f56b2796b"]
proc=subprocess.Popen(cmd)
events=[]
while proc.poll() is None:
 external=[p for p in lean_processes() if unit+".scope" not in p["cgroup"]]
 if external:
  events.append({"at":datetime.now(timezone.utc).isoformat(),"external":external,"action":"stop own scope only"})
  subprocess.run(["systemctl","--user","stop",unit+".scope"],check=False)
  proc.wait()
  break
 time.sleep(.05)
receipt={"module":module,"attempt":attempt,"started_utc":begin,"finished_utc":datetime.now(timezone.utc).isoformat(),"initial_lean_processes":existing,"external_events":events,"command":cmd,"exit_status":proc.wait()}
(root/(attempt+"-concurrency.json")).write_text(json.dumps(receipt,indent=2)+"\n")
print(json.dumps(receipt),flush=True)
sys.exit(receipt["exit_status"])
