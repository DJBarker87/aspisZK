from pathlib import Path
import hashlib,json
w=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-verify-c16-20261016');p=w/'source/crates/aspis-r1-cost-probe/src/lib.rs';raw=p.read_bytes();(w/'original-lib.rs').write_bytes(raw)
wrapper=b'''\n// Extraction-only one-call root; actual Prepared::new body is unchanged.\npub fn prepared_entry<H: aspis_core::Digest32>(\n    sem: &r1_semantic::Verified<H>, view: &verifier::View<'_>, hash: H,\n) -> Result<alloc::boxed::Box<verifier::Prepared>, verifier::Error> {\n    verifier::Prepared::new(sem, view, hash)\n}\n'''
p.write_bytes(raw+wrapper)
sha=lambda b:hashlib.sha256(b).hexdigest()
(w/'wrapper-overlay.json').write_text(json.dumps(dict(path=str(p.relative_to(w/'source')),source_revision='c16ab4d76619cf2cf80ece9d7e60e47975957af0',original_sha256=sha(raw),augmented_sha256=sha(raw+wrapper),wrapper_sha256=sha(wrapper),actual_body_changes=False),indent=2)+'\n')
r=(w/'run-charon.py').read_text().replace("out=w/'charon-a'","out=w/'charon-b'").replace("w/'VerifiedSemantic.llbc'","w/'VerifiedOpening.llbc'")
r=r.replace("'--start-from','crate::r1_semantic::verify_observed'", "'--opaque','crate::r1_wire::_::decode_k','--opaque','crate::r1_semantic::claims','--opaque','aspis_statement::pool_v1::pair_forest_semantic_terminal::r0::_::terminal_qm31','--opaque','aspis_core::state_only_hiding::state_only_selected_mask_value','--opaque','crate::fast_pairing','--opaque','crate::weights','--start-from','crate::r1_semantic::verify_observed','--start-from','crate::prepared_entry'")
r=r.replace("'source-manifest.json'","'source-manifest-b.json'").replace("'actual crate::r1_semantic::verify_observed full native crate dependency cone'","'actual verify_observed and Prepared::new with named universal function boundaries'")
(w/'run-charon-b.py').write_text(r)
