from pathlib import Path
import hashlib,json,os,re,signal,subprocess,time
w=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-verify-c16-20261016');root=w/'source';out=w/'charon-a';out.mkdir(exist_ok=False)
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
cg=Path('/sys/fs/cgroup')/next(x.split(':',2)[2] for x in Path('/proc/self/cgroup').read_text().splitlines() if x.startswith('0::')).lstrip('/')
read=lambda n:(cg/n).read_text().strip()
limits={n:read(n) for n in ['memory.high','memory.max','memory.swap.max']};assert limits=={'memory.high':str(6*2**30),'memory.max':str(8*2**30),'memory.swap.max':'0'}
tools=Path('/home/dombarker/project-offloads/aspis-r1-r18-tools-20261016');pins={x:sha(tools/x) for x in ['charon-target/release/charon','charon-target/release/charon-driver']}
assert pins['charon-target/release/charon']=='daad69bea1114042a2d2fbd3dfde99922b152d4f57023bf8edb83e5a6f336af8'
manifest={str(p.relative_to(root)):sha(p) for p in sorted(root.rglob('*')) if p.is_file()};(w/'source-manifest.json').write_text(json.dumps(dict(source_revision='c16ab4d76619cf2cf80ece9d7e60e47975957af0',archive_sha256=sha(w/'source.tar'),files=manifest),indent=2)+'\n')
cmd=[str(tools/'charon-target/release/charon'),'cargo','--preset','aeneas','--mir','built','--sysroot','default','--include','core::option::Option','--include','core::result::Result','--include','core::result::_::map_err','--include','aspis_core','--include','aspis_statement','--start-from','crate::r1_semantic::verify_observed','--dest-file',str(w/'VerifiedSemantic.llbc'),'--','--locked','--offline','--release','-p','aspis-r1-cost-probe','--lib','--no-default-features','--features','optimized-terminal,private-leaf-salts','--jobs','1']
env=dict(os.environ);env.update(PATH='/home/dombarker/.cargo/bin:/usr/bin:/bin',RUSTUP_TOOLCHAIN='nightly-2026-06-01',CARGO_BUILD_JOBS='1',CARGO_NET_OFFLINE='true',CARGO_TARGET_DIR=str(w/'cargo-target'),CARGO_PROFILE_RELEASE_OVERFLOW_CHECKS='true')
for key in ['RUSTFLAGS','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER','CARGO_ENCODED_RUSTFLAGS','CHARON_TOOLCHAIN_IS_IN_PATH']:env.pop(key,None)
started=time.monotonic();peak=0;before=read('memory.events');timeout=False
with (out/'stdout.log').open('w') as log:
 proc=subprocess.Popen(['/usr/bin/time','-v','-o',str(out/'time.log'),*cmd],cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
 while proc.poll() is None:
  peak=max(peak,int(read('memory.current')))
  if time.monotonic()-started>180:
   os.killpg(proc.pid,signal.SIGKILL);timeout=True;break
  time.sleep(.2)
 rc=proc.wait()
metric=(out/'time.log').read_text();num=lambda label: int(re.search(re.escape(label)+r':\s*(\d+)',metric)[1]) if re.search(re.escape(label)+r':\s*(\d+)',metric) else None
receipt=dict(target='actual crate::r1_semantic::verify_observed full native crate dependency cone',source_revision='c16ab4d76619cf2cf80ece9d7e60e47975957af0',source_manifest_sha256=sha(w/'source-manifest.json'),command=cmd,tool_pins=pins,runner_sha256=sha(Path(__file__)),time_expected='Native optimized dependency compilation and Charon lowering; no proof generation or arithmetic release gate',cwd=str(root),exit_status=rc,wall_seconds=time.monotonic()-started,peak_process_rss_kib=num('Maximum resident set size (kbytes)'),process_swaps=num('Swaps'),cgroup_peak=read('memory.peak'),sampled_cgroup_peak_bytes=peak,cgroup_swap=read('memory.swap.current'),limits=limits,memory_events_before=before,memory_events_after=read('memory.events'),timeout180=timeout)
if (w/'VerifiedSemantic.llbc').is_file():
 receipt['llbc_sha256']=sha(w/'VerifiedSemantic.llbc');d=json.loads((w/'VerifiedSemantic.llbc').read_text());receipt['has_errors']=d['has_errors'];receipt['declaration_counts']={k:sum(x is not None for x in d['translated'][k]) for k in ['type_decls','fun_decls','global_decls','trait_decls','trait_impls']}
(out/'receipt.json').write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt,indent=2));print((out/'stdout.log').read_text()[-12000:]);raise SystemExit(rc)
