from pathlib import Path
import hashlib,json,os
w=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-callers-c16-20261016/lean');old=Path('/home/dombarker/project-offloads/aspis-r1-r18-sampler-20261016/correct');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
d=json.loads((old/'external-inputs-correct.json').read_text());roots=set();pins={}
for name,q in d['modules'].items():
 source=Path(q['source']);assert sha(source)==q['source_sha256'],name
 obj=q['objects'].get('.olean');
 if not obj:continue
 p=Path(obj['path']);assert sha(p)==obj['sha256'],name
 suffix=name.replace('.','/')+'.olean';assert str(p).endswith(suffix);roots.add(str(p)[:-len(suffix)].rstrip('/'))
 pins[name]=q
r=old/'successful-targets/ExtractedQM31SamplerCorrect.json';q=json.loads(r.read_text());p=Path(q['objects']['.olean']['path']);assert sha(p)==q['objects']['.olean']['sha256'];source=old/'sources/ExtractedQM31SamplerCorrect.lean';assert sha(source)==q['key']['source_sha256'];roots.add(str(old/'objects'));pins['ExtractedQM31SamplerCorrect']=dict(source=str(source),source_sha256=sha(source),object=str(p),object_sha256=sha(p),receipt=str(r),receipt_sha256=sha(r))
(w/'external-sampler-pins.json').write_text(json.dumps(dict(modules=pins,object_roots=sorted(roots)),indent=2)+'\n')
print('verified sampler closure',len(pins),'roots',len(roots))
