from pathlib import Path
import json,hashlib,shutil
w=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-callers-c16-20261016/lean');c=Path('/home/dombarker/project-offloads/aspis-r1-public-binding-joint-c16-20261016');sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest();pins={}
archive=w/'raw-import-objects';archive.mkdir(exist_ok=True)
for module in ['AspisR1PublicPreparation.Types','AspisR1PublicPreparation.Funs']:
 suffix=module.replace('.','/');receipt=c/'successful-targets'/(module+'.json');r=json.loads(receipt.read_text());assert r['exit_status']==0
 source=c/'sources'/(suffix+'.lean');obj=Path(r['objects']['.olean']['path']);assert sha(source)==r['key']['source_sha256'] and sha(obj)==r['objects']['.olean']['sha256']
 old=w/'objects'/(suffix+'.olean');oldsrc=w/'sources'/(suffix+'.lean');(archive/(suffix+'.olean')).parent.mkdir(parents=True,exist_ok=True);shutil.copy2(old,archive/(suffix+'.olean'));shutil.copy2(oldsrc,archive/(suffix+'.lean'))
 shutil.copy2(source,w/'sources'/(suffix+'.lean'));shutil.copy2(obj,w/'objects'/(suffix+'.olean'))
 pins[module]=dict(source=str(source),source_sha256=sha(source),object=str(obj),object_sha256=sha(obj),receipt=str(receipt),receipt_sha256=sha(receipt))
for module in ['ExtractedDigest32Transcript','ExtractedDigest32Callers']:
 old=w/'objects'/(module+'.olean')
 if old.exists():shutil.move(old,archive/(module+'.olean'))
(w/'named-current-import-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
# The next checks rebuild only A's reverse dependents, on the coherent named pair.
p=w.parent/'stage-lean.py';s=p.read_text();s=s.replace("dependency_rebuild=False)","dependency_rebuild=False,named_current_import_pins=json.loads((w/'named-current-import-pins.json').read_text()),external_sampler_pins_sha256=sha(w/'external-sampler-pins.json'))")
p.write_text(s)
print('coherent named pair imported',pins)
