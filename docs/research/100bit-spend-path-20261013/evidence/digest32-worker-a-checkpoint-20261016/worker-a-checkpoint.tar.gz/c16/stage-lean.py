from pathlib import Path
import hashlib,json
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
w=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-callers-c16-20261016/lean');port=Path('/home/dombarker/project-offloads/aspis-r1-j17-port-20261015');pins={}
for receipt in sorted((port/'successful-targets').glob('*.json')):
 d=json.loads(receipt.read_text());assert d['exit_status']==0
 source=port/'backend'/(d['target'].replace('.','/')+'.lean');obj=port/'backend/.lake/build/lib/lean'/(d['target'].replace('.','/')+'.olean')
 assert sha(source)==d['key']['source'] and sha(obj)==d['olean_sha256']
 pins[d['target']]=dict(source=str(source),source_sha256=sha(source),object=str(obj),object_sha256=sha(obj),receipt=str(receipt),receipt_sha256=sha(receipt))
manifest=dict(source_revision='c16ab4d76619cf2cf80ece9d7e60e47975957af0',backend_object_pins=pins,sources={str(p.relative_to(w/'sources')):sha(p) for p in sorted((w/'sources').rglob('*.lean'))},dependency_rebuild=False,named_current_import_pins=json.loads((w/'named-current-import-pins.json').read_text()),external_sampler_pins_sha256=sha(w/'external-sampler-pins.json'))
(w/'input-manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('pinned backend',len(pins),'sources',len(manifest['sources']))
