from pathlib import Path
import hashlib,json
w=Path('/home/dombarker/project-offloads/aspis-r1-worker-a-callers-c16-20261016/lean');d=json.loads((w/'external-sampler-pins.json').read_text());root=w/'sampler-import-objects';root.mkdir(exist_ok=True)
for name,item in d['modules'].items():
 objs=item.get('objects', {'.olean':{'path':item.get('object'),'sha256':item.get('object_sha256')}})
 for ext,obj in objs.items():
  target=Path(obj['path']);assert hashlib.sha256(target.read_bytes()).hexdigest()==obj['sha256']
  dest=root/(name.replace('.','/')+ext);dest.parent.mkdir(parents=True,exist_ok=True)
  if dest.is_symlink():assert dest.resolve()==target
  else:dest.symlink_to(target)
p=w/'run-lean-host.py';s=p.read_text();old='":".join(json.loads(extra_file.read_text())["object_roots"])';assert old in s;s=s.replace(old,repr(str(root)));p.write_text(s)
(w/'sampler-import-overlay.json').write_text(json.dumps({'pinned_input_sha256':hashlib.sha256((w/'external-sampler-pins.json').read_bytes()).hexdigest(),'overlay':str(root),'modules':len(d['modules']),'reason':'Lean namespace-directory shadowing across split pinned object roots; every overlay entry links to the exact audited producing object.'},indent=2)+'\n')
print('overlay',len(d['modules']))
