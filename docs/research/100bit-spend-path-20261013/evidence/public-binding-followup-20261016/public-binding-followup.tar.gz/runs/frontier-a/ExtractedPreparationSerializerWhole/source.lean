import ExtractedPreparationSerializerLoop
import ExtractedDecoderPublicBinding

/-! All-outcome transport of the actual preparation serializer into the checked
serializer carrier. This supplies the serializer success witness from helper
success; no custody premise is involved. -/
set_option autoImplicit false
open Aeneas Aeneas.Std Result

namespace AspisR1PublicPreparation.SerializerWhole
open SerializerFields SerializerLoop

def mapOutcome {α : Type} : Result (core.result.Result α NewError) →
    Result (core.result.Result α OldError)
  | .ok r => .ok (mapStatus r)
  | .fail e => .fail e
  | .div => .div

private theorem map_bind {α β : Type} (m : Result α)
    (k : α → Result (core.result.Result β NewError)) :
    mapOutcome (do let x ← m; k x) = (do let x ← m; mapOutcome (k x)) := by
  cases m <;> rfl

private theorem map_pair_bind {α : Type} (m : Result α)
    (k : α → Result (core.result.Result Unit NewError × ByteVec)) :
    mapPairOutcome (do let x ← m; k x) = (do let x ← m; mapPairOutcome (k x)) := by
  cases m <;> rfl

private theorem map_pair_ok {α : Type} (r : core.result.Result α NewError) (out : ByteVec) :
    mapPairOutcome (ok (r, out)) = ok (mapStatus r, out) := rfl

private theorem map_outcome_ok {α : Type} (r : core.result.Result α NewError) :
    mapOutcome (ok r) = ok (mapStatus r) := rfl

private theorem bind_map_pair {α β : Type}
    (m : Result (core.result.Result α NewError × ByteVec))
    (k : core.result.Result α OldError × ByteVec → Result β) :
    (do let x ← mapPairOutcome m; k x) =
      (do let x ← m; k (mapStatus x.1, x.2)) := by
  cases m with
  | fail e => rfl
  | div => rfl
  | ok pair => cases pair; rfl

private theorem bind_congr {α β : Type} (m : Result α) (k l : α → Result β)
    (h : ∀ x, k x = l x) :
    (do let x ← m; k x) = (do let x ← m; l x) := by
  cases m with
  | ok x => exact h x
  | fail e => rfl
  | div => rfl

private theorem bind_pair_congr {α β γ : Type} (m : Result (α × β))
    (k l : α × β → Result γ) (h : ∀ a b, k (a, b) = l (a, b)) :
    (do let x ← m; k x) = (do let x ← m; l x) := by
  apply bind_congr
  intro x
  cases x with
  | mk a b => exact h a b

macro "transport_serializer" : tactic => `(tactic|
  repeat' first
    | rfl
    | progress simp only [fields_eq, bind_map_pair, map_pair_bind, map_bind,
        uncurry_apply_pair, mapStatus, map_pair_ok, map_outcome_ok,
        core.result.Result.Insts.CoreOpsTry.branch,
        core.result.Result.Insts.CoreOpsTryTraitFromResidualResultInfallible.from_residual,
        core.convert.FromSame.from, bind_tc_ok]
    | (apply bind_pair_congr; intro status out; cases status)
    | (apply bind_congr; intro x))

theorem frontier_eq (out : ByteVec)
    (values : Array (Array U32 8#usize) 20#usize) :
    AspisR1PublicSerializer.pool_v1.pair_forest_semantic_terminal.r0.Public.public_bytes.frontier out values =
      mapPairOutcome (pool_v1.pair_forest_semantic_terminal.r0.Public.public_bytes.frontier out values) := by
  unfold AspisR1PublicSerializer.pool_v1.pair_forest_semantic_terminal.r0.Public.public_bytes.frontier
    pool_v1.pair_forest_semantic_terminal.r0.Public.public_bytes.frontier
  transport_serializer

#print axioms frontier_eq
end AspisR1PublicPreparation.SerializerWhole
